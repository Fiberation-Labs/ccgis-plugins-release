# -*- coding: utf-8 -*-
"""Dock-Panel des GIS-NB Check: Projektauswahl nach GIS-NB Vertragsnummer (Layergruppe)."""
import traceback

from qgis.core import (
    Qgis, QgsCategorizedSymbolRenderer, QgsLayerTreeGroup, QgsMapLayer, QgsMapLayerProxyModel,
    QgsMessageLog, QgsProcessingContext, QgsProcessingFeedback, QgsProcessingUtils, QgsProject,
    QgsRendererCategory, QgsSymbol, QgsWkbTypes,
)
from qgis.gui import QgsMapLayerComboBox
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor
from qgis.PyQt.QtWidgets import (
    QApplication, QComboBox, QDockWidget, QFormLayout, QGroupBox, QHBoxLayout, QLabel,
    QMessageBox, QPushButton, QVBoxLayout, QWidget,
)

from .algorithm import CheckGisNb

LOG_TAG = 'GIS-NB Check'

# Layer-Erkennung ueber den Layernamen (lowercase). "netztechnik_bauten" ist Netztechnik.
_KEYWORDS = [
    ('nt', 'netztechnik'),
    ('mv', 'mitverleg'),
    ('vb', 'verbindung'),
    ('lr', 'leerrohr'),
    ('tr', 'trassenbau'),
    ('ba', 'bauten'),
]

# Optionale Layer und die Versionen, in denen es sie gibt
_OPTIONAL = {'ba': ('3.1',), 'mv': ('3.1', '4.1')}

_FARBEN = {'FEHLER': '#e31a1c', 'HINWEIS': '#ff9900'}


def match_layers(layers):
    """{rolle: layer} fuer eine Liste von Layern anhand der Layernamen."""
    out = {}
    for lyr in layers:
        name = lyr.name().lower()
        for role, kw in _KEYWORDS:
            if kw in name:
                out.setdefault(role, lyr)
                break
    return out


def detect_version(layers):
    """'3.1', '4.1', '4.0' oder None anhand der Felder bzw. Netztechnik-Codes."""
    nt = layers.get('nt')
    lr = layers.get('lr')
    names = {f.name().lower() for lyr in (nt, lr) if lyr is not None for f in lyr.fields()}
    if not names:
        return None
    if 'art_nt' in names:
        return '3.1'
    if nt is not None and 'art' in names:
        idx = nt.fields().lookupField('Art')
        if idx >= 0:
            arten = {v for v in nt.uniqueValues(idx) if isinstance(v, int)}
            if arten & set(range(11, 20)):
                return '4.1'
    return '4.0'


class _LogFeedback(QgsProcessingFeedback):
    """Protokoll in das Log-Fenster (Reiter "GIS-NB Check")."""

    def pushInfo(self, info):
        super().pushInfo(info)
        QgsMessageLog.logMessage(info, LOG_TAG, Qgis.Info)

    def reportError(self, error, fatalError=False):
        super().reportError(error, fatalError)
        QgsMessageLog.logMessage(error, LOG_TAG, Qgis.Critical)


class GisNbCheckPanel(QDockWidget):

    def __init__(self, iface, parent=None):
        super().__init__('GIS-NB Check', parent)
        self.iface = iface
        self.setObjectName('GisNbCheckPanel')
        self.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable |
                         QDockWidget.DockWidgetClosable)
        self._group_data = {}
        self._build_ui()

    # ── UI ───────────────────────────────────────────────────────────────────

    def _build_ui(self):
        container = QWidget()
        outer = QVBoxLayout(container)
        outer.setContentsMargins(6, 6, 6, 6)
        outer.setSpacing(8)

        grp_proj = QGroupBox('Projekt (GIS-NB Vertragsnummer)')
        proj = QHBoxLayout()
        proj.setSpacing(4)
        self.combo_group = QComboBox()
        self.combo_group.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLength)
        self.combo_group.setMinimumContentsLength(18)
        self.combo_group.currentIndexChanged.connect(self._on_group_selected)
        proj.addWidget(self.combo_group, 1)
        btn_refresh = QPushButton('↺')
        btn_refresh.setFixedWidth(28)
        btn_refresh.setToolTip('Gruppen neu laden')
        btn_refresh.clicked.connect(self._refresh_groups)
        proj.addWidget(btn_refresh)
        grp_proj.setLayout(proj)
        outer.addWidget(grp_proj)

        grp_layer = QGroupBox('Eingabe')
        self.form = QFormLayout()
        self.form.setSpacing(5)
        self.combo_version = QComboBox()
        for k in CheckGisNb.VERSION_KEYS:
            self.combo_version.addItem('GIS-NB ' + k, k)
        self.combo_version.setCurrentIndex(CheckGisNb.VERSION_DEFAULT)
        self.combo_version.currentIndexChanged.connect(self._on_version_changed)
        self.form.addRow('Version:', self.combo_version)

        # Reihenfolge wie in der Layergruppe
        self.combos = {}
        for role, label, filt in [
            ('nt', 'Netztechnik / Bauten:', QgsMapLayerProxyModel.PointLayer),
            ('ba', 'Bauten:',               QgsMapLayerProxyModel.VectorLayer),
            ('mv', 'Mitverlegung:',         QgsMapLayerProxyModel.VectorLayer),
            ('vb', 'Verbindungen:',         QgsMapLayerProxyModel.LineLayer),
            ('lr', 'Leerrohre:',            QgsMapLayerProxyModel.LineLayer),
            ('tr', 'Trassenbau:',           QgsMapLayerProxyModel.LineLayer),
        ]:
            cb = QgsMapLayerComboBox()
            cb.setFilters(filt)
            cb.setAllowEmptyLayer(role in _OPTIONAL)
            if role in _OPTIONAL:
                cb.setLayer(None)
            lbl = QLabel(label)
            self.form.addRow(lbl, cb)
            self.combos[role] = (lbl, cb)
        grp_layer.setLayout(self.form)
        outer.addWidget(grp_layer)

        btn_run = QPushButton('Pruefung starten')
        btn_run.setMinimumHeight(30)
        btn_run.clicked.connect(self._on_run)
        outer.addWidget(btn_run)
        outer.addStretch()

        self.setWidget(container)
        self.setMinimumWidth(260)
        self._on_version_changed()
        self._refresh_groups()

    def showEvent(self, event):
        super().showEvent(event)
        self._refresh_groups()

    def version(self):
        return self.combo_version.currentData()

    def _on_version_changed(self, *_):
        version = self.version()
        for role, versionen in _OPTIONAL.items():
            lbl, cb = self.combos[role]
            lbl.setVisible(version in versionen)
            cb.setVisible(version in versionen)
        # 3.1: Bauten ist ein eigener Layer, in 4.x steckt er in "Bauten und Netztechnik"
        self.combos['nt'][0].setText('Netztechnik:' if version == '3.1' else 'Netztechnik / Bauten:')

    # ── Gruppen ──────────────────────────────────────────────────────────────

    def _scan_groups(self):
        """{Anzeigename: {rolle: layer}} fuer alle Gruppen (auch verschachtelt) mit GIS-NB-Layern."""
        result = {}

        def walk(group, prefix):
            for child in group.children():
                if not isinstance(child, QgsLayerTreeGroup):
                    continue
                name = f'{prefix}{child.name()}'
                layers = [n.layer() for n in child.children() if hasattr(n, 'layer') and n.layer() is not None]
                matched = match_layers(layers)
                if len(set(matched) & {'lr', 'tr', 'vb', 'nt'}) >= 2:
                    result[name] = matched
                walk(child, name + ' / ')

        walk(QgsProject.instance().layerTreeRoot(), '')
        return result

    def _refresh_groups(self):
        prev = self.combo_group.currentText()
        self.combo_group.blockSignals(True)
        self.combo_group.clear()
        self.combo_group.addItem('— Gruppe waehlen —', None)
        self._group_data = self._scan_groups()
        for name in sorted(self._group_data):
            self.combo_group.addItem(name, name)
        idx = self.combo_group.findText(prev)
        self.combo_group.setCurrentIndex(idx if idx >= 0 else 0)
        self.combo_group.blockSignals(False)
        if self.combo_group.currentIndex() > 0:
            self._on_group_selected(self.combo_group.currentIndex())

    def _on_group_selected(self, index):
        name = self.combo_group.itemData(index)
        if not name or name not in self._group_data:
            return
        layers = self._group_data[name]
        for role, (_, cb) in self.combos.items():
            if role in layers:
                cb.setLayer(layers[role])
            elif role in _OPTIONAL:
                cb.setLayer(None)
        v = detect_version(layers)
        if v is not None:
            self.combo_version.setCurrentIndex(CheckGisNb.VERSION_KEYS.index(v))

    # ── Lauf ─────────────────────────────────────────────────────────────────

    def _on_run(self):
        version = self.version()
        lyr = {role: cb.currentLayer() for role, (_, cb) in self.combos.items()}
        missing = [r for r in ('lr', 'tr', 'vb', 'nt') if lyr[r] is None]
        if missing:
            names = {'lr': 'Leerrohre', 'tr': 'Trassenbau', 'vb': 'Verbindungen', 'nt': 'Netztechnik'}
            QMessageBox.warning(self, 'GIS-NB Check', 'Bitte Layer auswaehlen: ' + ', '.join(names[m] for m in missing))
            return
        projekt = self.combo_group.currentText() if self.combo_group.currentIndex() > 0 else lyr['lr'].name()

        alg = CheckGisNb
        params = {
            alg.LR: lyr['lr'], alg.TR: lyr['tr'], alg.VB: lyr['vb'], alg.NT: lyr['nt'],
            alg.BA: lyr['ba'] if version in _OPTIONAL['ba'] else None,
            alg.MV: lyr['mv'] if version in _OPTIONAL['mv'] else None,
            alg.VERSION: alg.VERSION_KEYS.index(version),
            alg.OUT_L: 'TEMPORARY_OUTPUT', alg.OUT_P: 'TEMPORARY_OUTPUT',
        }
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            from qgis import processing
            context = QgsProcessingContext()
            context.setProject(QgsProject.instance())
            QgsMessageLog.logMessage(f'--- {projekt} (GIS-NB {version}) ---', LOG_TAG, Qgis.Info)
            res = processing.run('gisnbcheck:check_gis_nb', params, context=context, feedback=_LogFeedback())
            outputs = [(alg.OUT_L, 'Fehler/Hinweise (Linien)'), (alg.OUT_P, 'Fehler/Hinweise (Punkte)')]
            layers = []
            for key, title in outputs:
                out = res.get(key)
                layer = out if isinstance(out, QgsMapLayer) else QgsProcessingUtils.mapLayerFromString(out, context)
                if layer is None:
                    continue
                layer.setName(title)
                self._style(layer)
                layers.append(layer)
            self._add_to_group(f'GIS-NB Check {projekt}', layers)
        except Exception as ex:
            QMessageBox.critical(self, 'GIS-NB Check - Fehler',
                                 f'Unerwarteter Fehler:\n{ex}\n\n{traceback.format_exc()[:1500]}')
        finally:
            QApplication.restoreOverrideCursor()

    @staticmethod
    def _style(layer):
        cats = []
        for sev, color in _FARBEN.items():
            sym = QgsSymbol.defaultSymbol(layer.geometryType())
            sym.setColor(QColor(color))
            if layer.geometryType() == QgsWkbTypes.LineGeometry:
                sym.setWidth(1.2)
            else:
                sym.setSize(3.0)
            cats.append(QgsRendererCategory(sev, sym, sev))
        layer.setRenderer(QgsCategorizedSymbolRenderer('schwere', cats))

    @staticmethod
    def _add_to_group(name, layers):
        """Ergebnis-Layer in eine Gruppe oben im Layerbaum; ein frueheres Ergebnis gleichen Namens wird ersetzt."""
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        old = root.findGroup(name)
        if old is not None:
            project.removeMapLayers([lyr.layerId() for lyr in old.findLayers()])
            root.removeChildNode(old)
        group = root.insertGroup(0, name)
        for layer in layers:
            project.addMapLayer(layer, False)
            group.addLayer(layer)

# -*- coding: utf-8 -*-
"""
Kernlogik des GIS-NB Check (v4.0 / 4.1; v3.1 siehe checks_v31.py).

Prueft die Netzplan-Layer Netztechnik, Verbindungen, Leerrohre, Trassenbau
(und optional Mitverlegung, nur allgemeine Pruefungen) auf die im Leitfaden Bearbeitung CCGIS und in
der Telekom-Interpretation der GIS-NB beschriebenen typischen Fehler.
Die Geometrie-Lage (parallel zu Megaplan) wird NICHT geprueft, nur
Geometrie-Grundregeln (leer, ungueltig, Multipart).

Zusaetzlich: Reserven-Abgleich je Streckenabschnitt - belegte Neubaurohre
laut Leerrohr-Layer (LR_Anzahl * Anzahl - LR_Reserv, ohne Aussenrohre) gegen
Anzahl der Neubaukabel laut Verbindungs-Layer. Ausgegeben werden nur
Abweichungen.

Lage-Vergleiche zwischen den Layern (Kabel auf Rohr, Punkt auf Linie, ...)
sind exakt; EPS_M faengt nur Rundungsrauschen der Koordinaten ab.

Ohne Processing-Abhaengigkeit, damit headless testbar.
"""
import bisect
import math
import re
from collections import Counter, defaultdict

from qgis.core import (
    NULL, QgsCoordinateTransformContext, QgsDistanceArea, QgsFeature,
    QgsGeometry, QgsPointXY, QgsSpatialIndex, QgsWkbTypes,
)

FEHLER  = 'FEHLER'
HINWEIS = 'HINWEIS'

# ── Codetabellen ─────────────────────────────────────────────────────────────

LR_ART_VALID      = {1, 2, 3, 4, 5, 6, 11, 12, 13, 14, 15, 16, 21, 22, 23, 24, 25, 99}
LR_ART_EINZEL     = {2, 3, 4, 5, 6}
LR_ART_VERBAND    = {11, 12, 13, 14, 15, 16}
LR_ART_MR         = 21
LR_ART_KSR        = {1, 22, 23, 24, 25}
LR_ART_AUSSENROHR = LR_ART_KSR | {LR_ART_MR}
LR_ART_SONSTIGE   = 99

VERB_ART_VALID  = {1, 3, 4, 5, 6, 7, 8, 9, 10, 11, 99}
VERB_ART_KUPFER = 1
VERB_ART_FUNK   = 4
VERB_ART_FASERN = {5: 6, 6: 12, 7: 24, 8: 48, 9: 72, 10: 96, 11: 144}

# LR_Art 99 / LR_Sonst: SNR 10/8 (Megaplan: "SNR 10x1 bl/ /8/1.0/10/...") und
# Aussenrohre, die als Sonstige gefuehrt werden ("KR/...", "KSR", "KKR", KKF, Dueker)
SNR108_RE     = re.compile(r'(snr\w*|speed\s*net[- ]?rohr\w*)\s*10\s*[x/×]', re.I)
AUSSENROHR_RE = re.compile(r'^\s*(kr|ksr|kkr|kkf|mr\d?)\b|kabelschutz|schutzrohr|kabelkanal|formstein|'
                           r'd(ü|ue|u)ker', re.I)

OBERIRDISCH_KW = ('oberirdisch', 'o.i.', 'o. i.')
VERFAHREN_OBERIRDISCH = 10

EPS_M = 0.001   # Meter: nur Koordinaten-Rundung, keine fachliche Lagetoleranz

VERSIONEN = {
    '4.0': dict(
        lr_neu=1, lr_bestand=2,          # Zustand Leerrohre
        neu=1, bestand=2,                # Zustand Verbindungen / Netztechnik
        nt_valid={1, 2, 3, 4, 5, 6, 99},
        nt_hvt={1}, nt_vt={2}, nt_muffe={3}, nt_gfap={4}, nt_msan={6}, nt_sonst={99},
    ),
    '4.1': dict(
        lr_neu=2, lr_bestand=1,          # laut Interpretation 4.1 vertauscht
        neu=1, bestand=2,
        nt_valid=set(range(11, 20)) | {30, 31, 99},
        nt_hvt={11, 12}, nt_vt={14}, nt_muffe={15}, nt_gfap={16}, nt_msan={13}, nt_sonst={99},
    ),
}

BEZEICHNER_MUSTER = {
    'hvt':      re.compile(r'^\d{4,6}[AR]?$'),
    'vt':       re.compile(r'^\d{4,6}(V|A)\d+$'),
    'msan':     re.compile(r'^\d{4,6}A\d+$'),
    'gfap':     re.compile(r'^\d{4,6}P\d+$'),
    'rohrende': re.compile(r'^Rohrende_\d+$'),
    'mast':     re.compile(r'^Mast_\d+$'),
}


# ── kleine Helfer ────────────────────────────────────────────────────────────

def isnull(v):
    if v is None or v == NULL:
        return True
    if isinstance(v, str) and v.strip() == '':
        return True
    if isinstance(v, float) and math.isnan(v):
        return True
    return False


def to_int(v):
    if isnull(v):
        return None
    try:
        return int(float(str(v).strip().replace(',', '.')))
    except (TypeError, ValueError):
        return None


def to_float(v):
    if isnull(v):
        return None
    try:
        return float(str(v).strip().replace(',', '.'))
    except (TypeError, ValueError):
        return None


def to_text(v):
    return '' if isnull(v) else str(v).strip()


def decimals(v):
    """Anzahl Nachkommastellen eines Zahlenwerts (fuer 'viele Nachkommastellen')."""
    if isnull(v):
        return 0
    s = repr(float(v)) if not isinstance(v, str) else v.strip().replace(',', '.')
    if 'e' in s or 'E' in s:
        return 10
    return len(s.split('.')[1].rstrip('0')) if '.' in s else 0


def parse_id_list(v):
    """'1, 8, 7' -> {1, 8, 7}"""
    out = set()
    for part in to_text(v).replace(';', ',').split(','):
        i = to_int(part)
        if i is not None:
            out.add(i)
    return out


def line_endpoints(geom):
    """(erster, letzter) Vertex als QgsPointXY oder (None, None)."""
    if geom is None or geom.isNull() or geom.isEmpty():
        return None, None
    if geom.isMultipart():
        parts = [p for p in geom.asMultiPolyline() if p]
        if not parts:
            return None, None
        return parts[0][0], parts[-1][-1]
    pts = geom.asPolyline()
    if len(pts) < 1:
        return None, None
    return pts[0], pts[-1]


def line_vertices(geom):
    if geom.isMultipart():
        out = []
        for p in geom.asMultiPolyline():
            out.extend(p)
        return out
    return geom.asPolyline()


class Rec:
    """Leichtgewichtiger Feature-Datensatz."""
    __slots__ = ('fid', 'id', 'geom', 'feat', 'layer', 'key')

    def __init__(self, layer, feat, id_val, has_id_field=True):
        self.layer = layer
        self.feat  = feat
        self.fid   = feat.id()
        self.geom  = feat.geometry()
        if has_id_field:
            self.id  = id_val
            self.key = f'ID={id_val}'
        else:                       # z.B. Verbindungen in GIS-NB 4.0 (kein ID-Attribut)
            self.id  = self.fid
            self.key = f'fid={self.fid}'


class Layer:
    """Layer-Huelle mit case-insensitivem Attributzugriff und Spatial Index."""

    def __init__(self, name, qgs_layer):
        self.name  = name
        self.qgs   = qgs_layer
        self.crs   = qgs_layer.sourceCrs() if qgs_layer is not None else None
        self._idx  = {}
        self.recs  = []
        self.by_fid = {}
        self.index = QgsSpatialIndex()
        self.buf   = {}
        if qgs_layer is None:
            return
        for f in qgs_layer.fields():
            self._idx.setdefault(f.name().lower(), qgs_layer.fields().indexOf(f.name()))
        for feat in qgs_layer.getFeatures():
            rec = Rec(name, feat, to_int(self.val_feat(feat, 'ID')), self.has_field('ID'))
            self.recs.append(rec)
            self.by_fid[rec.fid] = rec
            g = rec.geom
            if g is not None and not g.isNull() and not g.isEmpty():
                self.index.addFeature(feat)

    def has_field(self, name):
        return name.lower() in self._idx

    def val_feat(self, feat, name):
        i = self._idx.get(name.lower())
        if i is None:
            return None
        v = feat.attribute(i)
        return None if isnull(v) else v

    def val(self, rec, name):
        return self.val_feat(rec.feat, name)

    def candidates(self, geom, grow=0.0):
        bb = geom.boundingBox()
        if grow:
            bb.grow(grow)
        return [self.by_fid[i] for i in self.index.intersects(bb) if i in self.by_fid]


def split_polyline(pts, cuts, eps):
    """Polyline an Schnittpunkten teilen.

    cuts: Liste (Abstand entlang der Linie, Punkt). Liegt ein Schnitt naeher als
    eps an einem Vertex, wird dort geteilt; sonst wird der Punkt (der Knoten
    selbst, nicht interpoliert) als neuer Vertex eingefuegt.
    """
    cum = [0.0]
    for a, b in zip(pts, pts[1:]):
        cum.append(cum[-1] + math.hypot(b.x() - a.x(), b.y() - a.y()))
    nodes = [[c, QgsPointXY(p), False] for c, p in zip(cum, pts)]
    extra = []
    for d, pt in cuts:
        j = bisect.bisect_left(cum, d)
        near = [k for k in (j - 1, j) if 0 <= k < len(cum) and abs(cum[k] - d) <= eps]
        if near:
            nodes[near[0]][2] = True
        else:
            extra.append([d, QgsPointXY(pt), True])
    nodes = sorted(nodes + extra, key=lambda n: n[0])
    pieces, cur = [], [nodes[0][1]]
    for _, p, cut in nodes[1:]:
        cur.append(p)
        if cut:
            pieces.append(cur)
            cur = [p]
    if len(cur) >= 2:
        pieces.append(cur)
    return [pc for pc in pieces if len(pc) >= 2]


def line_parts(geom):
    """Linienanteile einer (Multi-/Collection-)Geometrie als Liste einteiliger Geometrien."""
    if geom is None or geom.isNull() or geom.isEmpty():
        return []
    if geom.type() == QgsWkbTypes.LineGeometry and not geom.isMultipart():
        return [geom]
    return [p for p in geom.asGeometryCollection() if p.type() == QgsWkbTypes.LineGeometry and not p.isEmpty()]


# ── Basisklasse (Infrastruktur fuer alle Versionen) ─────────────────────────

class CheckerBase:

    def __init__(self, lr, tr, vb, nt, mv=None, tol_m=0.0, feedback=None):
        self.tol_m    = max(tol_m or 0.0, EPS_M)
        self.feedback = feedback

        self.lr = Layer('Leerrohre',    lr)
        self.tr = Layer('Trassenbau',   tr)
        self.vb = Layer('Verbindungen', vb)
        self.nt = Layer('Netztechnik',  nt)
        self.mv = Layer('Mitverlegung', mv) if mv is not None else None

        self.findings = []      # dicts: schwere, code, layer, feat_id, geom, meldung, hinweis
        self.notes    = []      # layer-weite Hinweise ohne Geometrie
        self.reserve_rows = []  # Reserven-Abgleich: nur abweichende Abschnitte
        self.reserve_total = 0  # Anzahl verglichener Abschnitte

        # Einheiten: Toleranz in Layer-Einheiten
        crs = self.lr.crs
        self.geographic = bool(crs and crs.isGeographic())
        if self.geographic:
            ext = lr.extent()
            lat = (ext.yMinimum() + ext.yMaximum()) / 2.0 if not ext.isEmpty() else 50.0
            self.m_lat = 111_320.0
            self.m_lon = 111_320.0 * max(math.cos(math.radians(lat)), 0.2)
            self.tol = self.tol_m / self.m_lon     # konservativ: groesserer Wert
        else:
            self.m_lat = self.m_lon = 1.0
            self.tol = self.tol_m

        self.da = QgsDistanceArea()
        if crs is not None and crs.isValid():
            self.da.setSourceCrs(crs, QgsCoordinateTransformContext())
            self.da.setEllipsoid('GRS80')

        self.min_len = 0.5   # Meter: kleinere Luecken/Ueberstaende ignorieren

    # ── Infrastruktur ────────────────────────────────────────────────────────

    def info(self, msg):
        if self.feedback is not None:
            self.feedback.pushInfo(msg)

    def add(self, schwere, code, rec_or_layer, geom, meldung, hinweis='', feat_id=None):
        if isinstance(rec_or_layer, Rec):
            layer   = rec_or_layer.layer
            feat_id = rec_or_layer.id if feat_id is None else feat_id
            geom    = rec_or_layer.geom if geom is None else geom
        else:
            layer = rec_or_layer
        self.findings.append({
            'schwere': schwere, 'code': code, 'layer': layer,
            'feat_id': feat_id, 'geom': geom,
            'meldung': meldung, 'hinweis': hinweis,
        })

    def fehler(self, code, rec, meldung, hinweis='', geom=None, feat_id=None):
        self.add(FEHLER, code, rec, geom, meldung, hinweis, feat_id)

    def hinweis(self, code, rec, meldung, hinweis='', geom=None, feat_id=None):
        self.add(HINWEIS, code, rec, geom, meldung, hinweis, feat_id)

    def length_m(self, geom):
        try:
            return float(self.da.measureLength(geom))
        except Exception:
            return geom.length()

    def buffered(self, layer, rec):
        b = layer.buf.get(rec.fid)
        if b is None:
            b = rec.geom.buffer(self.tol, 4)
            layer.buf[rec.fid] = b
        return b

    def covering(self, geom, layer, pred=None):
        """Features aus layer, die geom einzeln vollstaendig (mit Toleranz) ueberdecken."""
        out = []
        for c in layer.candidates(geom, self.tol):
            if pred is not None and not pred(c):
                continue
            if self.buffered(layer, c).contains(geom):
                out.append(c)
        return out

    def uncovered(self, geom, layer, pred=None):
        """Teil von geom, der von keinem Feature aus layer ueberdeckt wird (Geometrie, Laenge m)."""
        if geom is None:
            return None, 0.0
        cands = [c for c in layer.candidates(geom, self.tol)
                 if (pred is None or pred(c)) and self.buffered(layer, c).intersects(geom)]
        if not cands:
            return geom, self.length_m(geom)
        union = QgsGeometry.unaryUnion([self.buffered(layer, c) for c in cands])
        rest  = geom.difference(union)
        if rest is None or rest.isNull() or rest.isEmpty():
            return None, 0.0
        return rest, self.length_m(rest)

    def touching(self, geom, layer, pred=None):
        """Features aus layer, die geom beruehren/schneiden (mit Toleranz)."""
        return [c for c in layer.candidates(geom, self.tol)
                if (pred is None or pred(c)) and c.geom.distance(geom) <= self.tol]

    def near_point(self, pt, layer, pred=None):
        g = QgsGeometry.fromPointXY(pt)
        return self.touching(g, layer, pred)

    def pt_key(self, pt):
        return (round(pt.x(), 7), round(pt.y(), 7))

    def same_pt(self, a, b):
        return math.hypot((a.x() - b.x()) * self.m_lon, (a.y() - b.y()) * self.m_lat) <= self.tol_m

    def covered_part(self, geom, layer, pred=None):
        """Teil von geom, der von Features aus layer ueberdeckt wird (oder None)."""
        cands = [c for c in layer.candidates(geom, self.tol)
                 if (pred is None or pred(c)) and self.buffered(layer, c).intersects(geom)]
        if not cands:
            return None
        part = geom.intersection(QgsGeometry.unaryUnion([self.buffered(layer, c) for c in cands]))
        return None if part is None or part.isNull() or part.isEmpty() else part

    def haus_rest(self, rec, rest):
        """Kabelstueck im Gebaeude aus rest entfernen.

        SNR 12 enden bei Hauszufuehrungen oft an der Hauskante, im Haus liegt nur
        noch das Kabel bis zum Gf-AP. Ein Teil von rest, der am Gf-AP-Ende des
        Kabels haengt und nicht auf Trassenbau liegt, ist deshalb kein Fehler.
        Liegt dort Trassenbau, bleibt der Trassenbau-Anteil als Rest erhalten.
        """
        if rest is None:
            return None, 0.0
        ends = [p for p in line_endpoints(rec.geom) if p is not None and self.near_point(p, self.nt, self.is_gfap)]
        if not ends:
            return rest, self.length_m(rest)
        merged = rest.mergeLines() if rest.type() == QgsWkbTypes.LineGeometry else rest
        keep = []
        for part in line_parts(merged):
            if any(part.distance(QgsGeometry.fromPointXY(e)) <= self.tol for e in ends):
                part = self.covered_part(part, self.tr)
                if part is None:
                    continue
            keep.extend(line_parts(part))
        if not keep:
            return None, 0.0
        out = QgsGeometry.collectGeometry(keep)
        return out, self.length_m(out)

    def ohne_haus_teile(self, rest):
        """Teile von rest entfernen, die an einem Gf-AP liegen (Stueck im Gebaeude)."""
        merged = rest.mergeLines() if rest.type() == QgsWkbTypes.LineGeometry else rest
        keep = [p for p in line_parts(merged) if not self.touching(p, self.nt, self.is_gfap)]
        if not keep:
            return None, 0.0
        out = QgsGeometry.collectGeometry(keep)
        return out, self.length_m(out)

    def is_gfap(self, rec):
        raise NotImplementedError

    def vb_oberirdisch(self, rec):
        s = to_text(self.vb.val(rec, 'V_A_Sonst')).lower()
        return any(k in s for k in OBERIRDISCH_KW) or s in ('oi', 'o.i')

    # ── Allgemein ────────────────────────────────────────────────────────────

    def check_allgemein(self, layer):
        if layer.qgs is None:
            return
        crs = layer.crs
        if crs is not None and crs.isValid() and crs.authid().upper() != 'EPSG:4258':
            self.notes.append((HINWEIS, 'CRS', layer.name,
                               f'{layer.name}: CRS ist {crs.authid()}, Abgabe erfordert EPSG:4258 (ETRS89).'))
        for name in ('ID',) if layer.name in ('Leerrohre', 'Trassenbau', 'Netztechnik') else ():
            if not layer.has_field(name):
                self.notes.append((FEHLER, 'FELD_FEHLT', layer.name,
                                   f'{layer.name}: Pflichtfeld "{name}" fehlt.'))

        ids = Counter(r.id for r in layer.recs if r.id is not None)
        is_line = layer.qgs.geometryType() == QgsWkbTypes.LineGeometry
        for r in layer.recs:
            g = r.geom
            if g is None or g.isNull() or g.isEmpty():
                self.fehler('GEOM_LEER', r, f'{layer.name} fid={r.fid}: Geometrie leer.',
                            'Feature loeschen oder Geometrie nachdigitalisieren.',
                            geom=QgsGeometry())
                continue
            if not g.isGeosValid():
                self.fehler('GEOM_UNGUELTIG', r, f'{layer.name} {r.key}: Geometrie ungueltig.',
                            'Geometrie reparieren (Vektor > Geometrie-Werkzeuge).')
            if g.isMultipart() and g.constGet().partCount() > 1:
                self.hinweis('GEOM_MULTIPART', r,
                             f'{layer.name} {r.key}: Multi-Geometrie mit {g.constGet().partCount()} Teilen.',
                             'Mehrteilig zu einteilig (Multipart to Singleparts).')
            if is_line and self.length_m(g) < 0.05:
                self.fehler('GEOM_NULLLAENGE', r,
                            f'{layer.name} {r.key}: Linie nur {self.length_m(g) * 100:.0f} cm lang.',
                            'Splitterstueck loeschen bzw. an das Nachbarstueck anhaengen.')
            if layer.has_field('ID'):
                if r.id is None:
                    self.fehler('ID_FEHLT', r, f'{layer.name} fid={r.fid}: ID fehlt.',
                                'Naechsthoehere freie ID vergeben ($id + 1).')
                elif ids[r.id] > 1:
                    self.fehler('ID_DOPPELT', r, f'{layer.name} {r.key}: ID {ids[r.id]}x vergeben.',
                                'IDs muessen eindeutig sein - fortlaufend neu nummerieren.')

    # ── Zusammenfassung ──────────────────────────────────────────────────────

    def summary(self):
        by_code = Counter((f['schwere'], f['code']) for f in self.findings)
        n_f = sum(1 for f in self.findings if f['schwere'] == FEHLER)
        n_h = sum(1 for f in self.findings if f['schwere'] == HINWEIS)
        return {
            'fehler': n_f, 'hinweise': n_h,
            'by_code': sorted(by_code.items(), key=lambda kv: (kv[0][0] != FEHLER, -kv[1], kv[0][1])),
            'notes': list(self.notes),
            'reserve_abweichungen': len(self.reserve_rows),
            'reserve_abschnitte': self.reserve_total,
        }


# ── GIS-NB 4.0 / 4.1 ─────────────────────────────────────────────────────────

class GisNbChecker(CheckerBase):

    def __init__(self, lr, tr, vb, nt, mv=None, version='4.0', tol_m=0.0, feedback=None):
        super().__init__(lr, tr, vb, nt, mv, tol_m, feedback)
        self.V       = VERSIONEN[version]
        self.version = version

    # ── Attribut-Kurzformen ──────────────────────────────────────────────────

    def lr_zustand_neu(self, rec):
        return to_int(self.lr.val(rec, 'Zustand')) == self.V['lr_neu']

    def lr_zustand_bestand(self, rec):
        return to_int(self.lr.val(rec, 'Zustand')) == self.V['lr_bestand']

    def lr_art(self, rec):
        return to_int(self.lr.val(rec, 'LR_Art'))

    def lr_is_aussenrohr(self, rec):
        art = self.lr_art(rec)
        if art in LR_ART_AUSSENROHR:
            return True
        return art == LR_ART_SONSTIGE and bool(AUSSENROHR_RE.search(to_text(self.lr.val(rec, 'LR_Sonst'))))

    def lr_is_snr108(self, rec):
        return (not self.lr_is_aussenrohr(rec)
                and bool(SNR108_RE.search(to_text(self.lr.val(rec, 'LR_Sonst')))))

    def tr_oberirdisch(self, rec):
        return to_int(self.tr.val(rec, 'VERFAHREN')) == VERFAHREN_OBERIRDISCH

    def vb_zustand_bestand(self, rec):
        return to_int(self.vb.val(rec, 'Zustand')) == self.V['bestand']

    def vb_zustand_neu(self, rec):
        return to_int(self.vb.val(rec, 'Zustand')) == self.V['neu']

    def nt_art(self, rec):
        return to_int(self.nt.val(rec, 'Art'))

    def nt_kind(self, rec):
        a = self.nt_art(rec)
        s = to_text(self.nt.val(rec, 'Art_Sonst')).lower()
        b = to_text(self.nt.val(rec, 'Bezeichner')).lower()
        if a in self.V['nt_hvt']:
            return 'hvt'
        if a in self.V['nt_vt']:
            return 'vt'
        if a in self.V['nt_msan']:
            return 'msan'
        if a in self.V['nt_gfap']:
            return 'gfap'
        if a in self.V['nt_muffe']:
            return 'muffe'
        if a in self.V['nt_sonst']:
            if 'rohrende' in s or b.startswith('rohrende'):
                return 'rohrende'
            if 'mastbox' in s:
                return 'mastbox'
            if 'mast' in s:
                return 'mast'
            if 'nvt' in s or 'kvz' in s:
                return 'vt'
            if 'msan' in s:
                return 'msan'
            return 'sonst'
        return None

    def nt_is_rohrende(self, rec):
        return self.nt_kind(rec) == 'rohrende'

    def nt_is_gfap(self, rec):
        return self.nt_kind(rec) == 'gfap'

    is_gfap = nt_is_gfap

    # ── Lauf ─────────────────────────────────────────────────────────────────

    def run(self):
        self.info(f'GIS-NB Check {self.version}  |  Lage exakt (Rundung {EPS_M * 1000:.0f} mm)  |  '
                  f'LR={len(self.lr.recs)} TR={len(self.tr.recs)} VB={len(self.vb.recs)} '
                  f'NT={len(self.nt.recs)}' + (f' MV={len(self.mv.recs)}' if self.mv else ''))
        self._nt_by_id = {r.id: r for r in self.nt.recs if r.id is not None}

        for layer in [self.nt, self.vb, self.lr, self.tr] + ([self.mv] if self.mv else []):
            self.check_allgemein(layer)
        self.check_leerrohre()
        self.check_trassenbau()
        self.check_verbindungen()
        self.check_netztechnik()
        self.check_reserven_abgleich()
        return self.findings

    # ── Leerrohre ────────────────────────────────────────────────────────────

    def check_leerrohre(self):
        L = self.lr
        V = self.V
        for r in L.recs:
            if r.geom is None or r.geom.isNull() or r.geom.isEmpty():
                continue
            art      = self.lr_art(r)
            sonst    = to_text(L.val(r, 'LR_Sonst'))
            zustand  = to_int(L.val(r, 'Zustand'))
            lr_anz   = to_int(L.val(r, 'LR_Anzahl'))
            anz      = to_int(L.val(r, 'Anzahl'))
            reserv   = to_int(L.val(r, 'LR_Reserv'))
            lae      = to_float(L.val(r, 'Lae_LR'))
            geo_len  = self.length_m(r.geom)
            neu      = zustand == V['lr_neu']
            bestand  = zustand == V['lr_bestand']

            # LR_Art
            if art is None or art not in LR_ART_VALID:
                self.fehler('LR_ART_UNGUELTIG', r, f'Leerrohr {r.key}: LR_Art={art} ist kein gueltiger Code.',
                            'Codes siehe GIS-NB 3.2.2.2 (2-6, 11-16, 21-25, 99).')
            elif art == 1:
                self.fehler('LR_ART_KSR_UNSPEZIFISCH', r, f'Leerrohr {r.key}: LR_Art=1 (KSR) ist nicht zulaessig.',
                            'Kabelschutzrohr spezifizieren: 22 DN50, 23 DN40, 24 DN32, 25 DN100.')
            if art == LR_ART_SONSTIGE and not sonst:
                self.fehler('LR_SONST_FEHLT', r, f'Leerrohr {r.key}: LR_Art=99 ohne LR_Sonst.',
                            'z.B. "SNR 10/8" oder "SNRV 10/8".')
            if any(k in sonst.lower() for k in ('düker', 'dueker', 'duker')):
                self.hinweis('LR_DUEKER', r, f'Leerrohr {r.key}: Dueker "{sonst}".',
                             'Dueker als KR40 (23), KR50 (22) oder KR100 (25) fuehren; 90-170 -> KR100.')

            # Zustand
            if zustand not in (V['lr_neu'], V['lr_bestand']):
                self.fehler('LR_ZUSTAND_UNGUELTIG', r, f'Leerrohr {r.key}: Zustand={zustand}.',
                            f'Nur {V["lr_neu"]} (Neu) oder {V["lr_bestand"]} (Bestand) verwenden.')

            # LR_Anzahl / Anzahl
            if lr_anz is None or lr_anz < 1:
                self.fehler('LR_ANZAHL_FEHLT', r, f'Leerrohr {r.key}: LR_Anzahl={lr_anz}.',
                            'Einzelrohr/KR = 1, Verband = Anzahl Einzelrohre (z.B. 7, 12), MR = 1-4.')
            else:
                if art in LR_ART_VERBAND and lr_anz == 1:
                    self.hinweis('LR_ANZAHL_VERBAND', r, f'Leerrohr {r.key}: Rohrverband (LR_Art={art}) mit LR_Anzahl=1.',
                                 'Anzahl der Einzelrohre im Verband eintragen.')
                # LR_Art 99 kann auch ein Verband sein (z.B. "SNRV 10/8"), nur Einzelrohre pruefen
                if (art in LR_ART_EINZEL or (art == LR_ART_SONSTIGE and self.lr_is_snr108(r)
                                             and 'snrv' not in sonst.lower())) and lr_anz != 1:
                    self.hinweis('LR_ANZAHL_EINZEL', r, f'Leerrohr {r.key}: Einzelrohr (LR_Art={art}) mit LR_Anzahl={lr_anz}.',
                                 'Einzelrohre haben LR_Anzahl=1; mehrere identische Rohre ueber "Anzahl".')
                if art == LR_ART_MR and not 1 <= lr_anz <= 4:
                    self.fehler('LR_ANZAHL_MR', r, f'Leerrohr {r.key}: MR mit LR_Anzahl={lr_anz}.',
                                'MR-Verband: LR_Anzahl 1-4, Anzahl = Zahl der MR-Verbaende.')
            if anz is None or anz < 1:
                self.fehler('LR_ANZAHL_ROHRE_FEHLT', r, f'Leerrohr {r.key}: Anzahl={anz}.',
                            'Anzahl identischer Verbaende/Rohre im Abschnitt (mind. 1).')

            # LR_Reserv
            kap = (lr_anz or 1) * (anz or 1)
            if reserv is None:
                self.fehler('LR_RESERV_FEHLT', r, f'Leerrohr {r.key}: LR_Reserv leer.',
                            'Freie Rohre direkt nach Ausbau eintragen (Bestand: 0).')
            else:
                if reserv < 0 or reserv > kap:
                    self.fehler('LR_RESERV_UNPLAUSIBEL', r,
                                f'Leerrohr {r.key}: LR_Reserv={reserv} bei Kapazitaet {kap} (LR_Anzahl x Anzahl).',
                                'Reserve muss zwischen 0 und LR_Anzahl x Anzahl liegen.')
                if bestand and reserv != 0:
                    self.fehler('LR_RESERV_BESTAND', r, f'Leerrohr {r.key}: Bestandsrohr mit LR_Reserv={reserv}.',
                                'Bei Bestandsrohren immer 0.')
                if neu and reserv == 0 and art not in LR_ART_AUSSENROHR and art != LR_ART_SONSTIGE and kap > 1:
                    self.hinweis('LR_RESERV_NEU_NULL', r, f'Leerrohr {r.key}: Neubau-Verband ohne Reserve (LR_Reserv=0).',
                                 'Neue Rohre sollten Reserven > 0 haben (Ausnahme: neue SNR 10/8 mit Kabel).')

            # Lae_LR
            if lae is None or lae <= 0:
                self.fehler('LR_LAENGE_FEHLT', r, f'Leerrohr {r.key}: Lae_LR={lae}.',
                            'Einzellaenge laut Megaplan (Feld "Laenge", nicht Rohrzuglaenge) eintragen.')
            else:
                # Lae_LR kuerzer als die Linie wird erst beim finalen Export korrigiert, hier nicht pruefen
                if decimals(L.val(r, 'Lae_LR')) > 2:
                    self.hinweis('LR_LAENGE_NACHKOMMA', r, f'Leerrohr {r.key}: Lae_LR={lae} mit vielen Nachkommastellen.',
                                 'Deutet auf ueberlagerte Geometrien beim Export hin - Abschnitt pruefen.')
                if geo_len > 10 and lae > 2.0 * geo_len:
                    self.hinweis('LR_LAENGE_ABWEICHUNG', r,
                                 f'Leerrohr {r.key}: Lae_LR={lae} m ist mehr als doppelt so lang wie die Linie ({geo_len:.1f} m).',
                                 'Gesamtlauf statt Einzellaenge? Wert in Megaplan (Feld Laenge) pruefen.')

            # SNR 10/8 braucht Aussenrohr
            if self.lr_is_snr108(r):
                aussen = self.covering(r.geom, L, lambda c, rr=r: c.fid != rr.fid and self.lr_is_aussenrohr(c))
                rest, rest_len = self.uncovered(r.geom, L, lambda c, rr=r: c.fid != rr.fid and self.lr_is_aussenrohr(c))
                if rest_len > self.min_len:
                    self.fehler('SNR_OHNE_AUSSENROHR', r,
                                f'Leerrohr {r.key} ({sonst}): auf {rest_len:.1f} m ohne Aussenrohr (KSR/KR).',
                                'Aussenrohr ergaenzen: SNR kopieren, LR_Art 22/23/25, Attribute laut Megaplan, '
                                'Geometrie auf den Rohrverlauf kuerzen/splitten.', geom=rest)
                elif aussen and all(self.lr_art(a) == LR_ART_MR and self.lr_zustand_bestand(a) for a in aussen):
                    self.fehler('SNR_IN_BESTANDS_MR', r,
                                f'Leerrohr {r.key} ({sonst}): Aussenrohr ist nur ein Bestands-MR (ID={[a.id for a in aussen]}).',
                                'Bestands-MR durch Aussenrohr (KR/KKF) ersetzen; Ausnahme neu gebaute MR4.')

            # ID_TRASSEN / Trassenbau
            if neu and not self.lr_is_snr108(r) and art not in LR_ART_AUSSENROHR | {LR_ART_SONSTIGE}:
                rest, rest_len = self.uncovered(r.geom, self.tr)
                if rest_len > self.min_len:
                    # Einzug in Bestands-Aussenrohr braucht keinen Trassenbau
                    rest2, rest2_len = self.uncovered(rest, L, lambda c, rr=r: c.fid != rr.fid and self.lr_is_aussenrohr(c) and self.lr_zustand_bestand(c))
                    # Rohr im Gebaeude bis zum Gf-AP: Trassenbau endet an der Hauskante
                    if rest2_len > self.min_len:
                        rest2, rest2_len = self.ohne_haus_teile(rest2)
                    if rest2_len > self.min_len:
                        self.hinweis('LR_NEU_OHNE_TRASSENBAU', r,
                                     f'Leerrohr {r.key}: Neubaurohr auf {rest2_len:.1f} m ohne Trassenbau und ohne Bestands-Aussenrohr.',
                                     'Fehlt Trassenbau (z.B. nur fuer eine AG exportiert)? Ggf. nachdigitalisieren. '
                                     'Bei Einzug/Mitverlegung OK.', geom=rest2)
            if neu and self.lr_is_snr108(r):
                # neue SNR 10/8 im Neubau-KR: ok; im Bestands-KR: ok (Einzug). Nichts zu tun.
                pass

    # ── Trassenbau ───────────────────────────────────────────────────────────

    def check_trassenbau(self):
        T = self.tr
        for r in T.recs:
            if r.geom is None or r.geom.isNull() or r.geom.isEmpty():
                continue
            mitv = to_int(T.val(r, 'Mitverleg'))
            if T.has_field('Mitverleg') and mitv not in (0, 1):
                self.fehler('TB_MITVERLEG_UNGUELTIG', r, f'Trassenbau {r.key}: Mitverleg={mitv}.',
                            '0 = nein, 1 = ja (nur bei Eigenmitverlegung / Grabenteilung mit Dritten).')
            if mitv == 1 and not to_text(T.val(r, 'E_FName')):
                self.hinweis('TB_MITVERLEG_OHNE_PARTNER', r, f'Trassenbau {r.key}: Mitverlegung ohne E_FName.',
                             'Name des Partners (z.B. Stadtwerke) eintragen.')

            # Trassenbau muss von Neubau-Leerrohr belegt sein
            rest, rest_len = self.uncovered(r.geom, self.lr, self.lr_zustand_neu)
            if rest_len <= self.min_len:
                continue
            verf = to_int(T.val(r, 'VERFAHREN'))

            # Verfahren 10 (oberirdisch): Kabel ohne Leerrohr zulaessig, Kabel muss aber da sein
            if verf == VERFAHREN_OBERIRDISCH:
                rest2, rest2_len = self.uncovered(rest, self.vb)
                if rest2_len > self.min_len:
                    self.fehler('TB_OBERIRDISCH_OHNE_KABEL', r,
                                f'Trassenbau {r.key} (Verfahren 10, oberirdisch): {rest2_len:.1f} m ohne '
                                f'Leerrohr und ohne Verbindung.',
                                'Oberirdisches Kabel fehlt oder Trassenbau loeschen/kuerzen.', geom=rest2)
                continue

            # Nur oberirdisches Kabel (V_A_Sonst) ohne Leerrohr -> Verfahren muss 10 sein
            ober = self.covered_part(rest, self.vb, self.vb_oberirdisch)
            if ober is not None and self.length_m(ober) > self.min_len:
                self.fehler('TB_VERFAHREN_NICHT_10', r,
                            f'Trassenbau {r.key}: {self.length_m(ober):.1f} m nur mit oberirdischem Kabel '
                            f'(V_A_Sonst), aber VERFAHREN={verf}.',
                            'VERFAHREN = 10 (oberirdische Verlegung) setzen oder Trassenbau an der Stelle teilen.',
                            geom=ober)
                rest, rest_len = self.uncovered(rest, self.vb, self.vb_oberirdisch)
                if rest_len <= self.min_len:
                    continue

            bestand_hier = self.touching(rest, self.lr, self.lr_zustand_bestand)
            kabel_hier = self.covered_part(rest, self.vb)
            if bestand_hier:
                self.fehler('TB_UEBER_BESTANDSROHR', r,
                            f'Trassenbau {r.key}: {rest_len:.1f} m nur ueber Bestandsrohren '
                            f'(ID={[b.id for b in bestand_hier][:6]}), kein Neubaurohr.',
                            'Kein Tiefbau -> Trassenbau loeschen (z.B. SNR in bestehendes KR eingezogen), '
                            'sonst fehlt das Neubaurohr.', geom=rest)
            elif kabel_hier is not None and self.length_m(kabel_hier) > self.min_len:
                self.fehler('TB_NUR_KABEL', r,
                            f'Trassenbau {r.key}: {rest_len:.1f} m nur mit Verbindung, ohne Leerrohr.',
                            'Oberirdisch? Dann VERFAHREN = 10 und V_A_Sonst "oberirdisch ...". '
                            'Sonst fehlt das Leerrohr.', geom=rest)
            else:
                self.fehler('TB_OHNE_LEERROHR', r,
                            f'Trassenbau {r.key}: {rest_len:.1f} m ohne Leerrohr.',
                            'Leerrohr fehlt oder Trassenbau liegt falsch (z.B. innerhalb Gebaeude -> loeschen).',
                            geom=rest)

    # ── Verbindungen ─────────────────────────────────────────────────────────

    def check_verbindungen(self):
        Vb = self.vb
        V  = self.V
        nt_by_id = self._nt_by_id

        # Endpunkt-Register aller Verbindungen (fuer "Kabelstuecke ohne Muffe")
        vb_ends = []
        for r in Vb.recs:
            a, b = line_endpoints(r.geom)
            if a is not None:
                vb_ends.append((a, r)); vb_ends.append((b, r))

        for r in Vb.recs:
            if r.geom is None or r.geom.isNull() or r.geom.isEmpty():
                continue
            art     = to_int(Vb.val(r, 'Verb_Art'))
            sonst   = to_text(Vb.val(r, 'V_A_Sonst'))
            zustand = to_int(Vb.val(r, 'Zustand'))
            fasern  = to_int(Vb.val(r, 'Anzahl_F_A'))
            reserv  = to_int(Vb.val(r, 'F_A_Reserv'))
            lae     = to_float(Vb.val(r, 'Lae_Kabel'))
            geo_len = self.length_m(r.geom)
            neu     = zustand == V['neu']
            bestand = zustand == V['bestand']
            ober    = self.vb_oberirdisch(r)
            funk    = art == VERB_ART_FUNK
            kupfer  = art == VERB_ART_KUPFER
            a_pt, e_pt = line_endpoints(r.geom)

            if art is None or art not in VERB_ART_VALID:
                self.fehler('VB_ART_UNGUELTIG', r, f'Verbindung {r.key}: Verb_Art={art} ist kein gueltiger Code.',
                            '1 Kupfer, 3 Koax, 4 Richtfunk, 5-11 Gf 6..144 Fasern, 99 Sonstige.')
            elif art in VERB_ART_FASERN:
                soll = VERB_ART_FASERN[art]
                if fasern is None:
                    self.fehler('VB_FASERN_FEHLT', r, f'Verbindung {r.key}: Anzahl_F_A leer (Verb_Art={art} -> {soll}).',
                                f'Anzahl_F_A = {soll} eintragen.')
                elif fasern != soll:
                    self.fehler('VB_ART_FASERN_ABWEICHUNG', r,
                                f'Verbindung {r.key}: Verb_Art={art} entspricht {soll} Fasern, Anzahl_F_A={fasern}.',
                                'Verb_Art oder Anzahl_F_A korrigieren (Zuordnung laut GIS-NB).')
            elif art == 99 and not sonst:
                self.fehler('VB_SONST_FEHLT', r, f'Verbindung {r.key}: Verb_Art=99 ohne V_A_Sonst.',
                            'z.B. "Gf-Kabel 36 Fasern", "Fernspeisekabel", "oberirdisch Gf 36 Fs".')

            if zustand not in (V['neu'], V['bestand']):
                self.fehler('VB_ZUSTAND_UNGUELTIG', r, f'Verbindung {r.key}: Zustand={zustand}.',
                            f'Nur {V["neu"]} (Neu) oder {V["bestand"]} (Bestand).')
            if kupfer and bestand:
                self.hinweis('VB_KUPFER_BESTAND', r, f'Verbindung {r.key}: Bestands-Kupferkabel.',
                             'Loeschen, sofern es nicht der Mitversorgung eines weiteren KVz dient (inkl. zugehoerigem KVz).')

            # Faserreserve
            hausanschluss = False
            if a_pt is not None:
                hausanschluss = bool(self.near_point(a_pt, self.nt, self.nt_is_gfap) or
                                     self.near_point(e_pt, self.nt, self.nt_is_gfap))
            if not funk:
                if reserv is None or fasern is None:
                    if reserv is None:
                        self.fehler('VB_RESERV_FEHLT', r, f'Verbindung {r.key}: F_A_Reserv leer.',
                                    'Freie Fasern eintragen (Bestand/Kupfer: 0; Hausanschluss: Anzahl/2).')
                else:
                    if reserv < 0 or reserv > fasern:
                        self.fehler('VB_RESERV_UNPLAUSIBEL', r,
                                    f'Verbindung {r.key}: F_A_Reserv={reserv} bei Anzahl_F_A={fasern}.',
                                    'Reserve zwischen 0 und Anzahl_F_A-1.')
                    elif reserv == fasern and fasern > 0 and neu:
                        self.fehler('VB_RESERV_ALLE_FREI', r,
                                    f'Verbindung {r.key}: F_A_Reserv = Anzahl_F_A = {fasern} (keine Faser belegt).',
                                    'Belegte Fasern von NVt Richtung HVt zurueckrechnen; Formel: '
                                    'case when "F_A_Reserv" < 0 OR "F_A_Reserv" > "Anzahl_F_A" OR "Anzahl_F_A" = "F_A_Reserv" '
                                    'OR "F_A_Reserv" = 0 then "Anzahl_F_A"/2 else "F_A_Reserv" end')
                    if (bestand or kupfer) and reserv != 0:
                        self.fehler('VB_RESERV_BESTAND', r,
                                    f'Verbindung {r.key}: {"Bestands" if bestand else "Kupfer"}kabel mit F_A_Reserv={reserv}.',
                                    'Bei Bestands- und Kupferkabeln immer 0.')
                    if neu and hausanschluss and reserv == 0 and not kupfer:
                        self.fehler('VB_HAUSANSCHLUSS_OHNE_RESERVE', r,
                                    f'Verbindung {r.key}: Hausanschluss (am Gf-AP) mit F_A_Reserv=0.',
                                    f'Hausanschluesse muessen Reserven haben -> {fasern // 2 if fasern else "Anzahl/2"}.')

            # Laenge
            if not funk:
                if lae is None or lae < 0.1:
                    self.fehler('VB_LAENGE_FEHLT', r, f'Verbindung {r.key}: Lae_Kabel={lae}.',
                                'Gemessene Laenge eintragen, mindestens 0.1 m.')
                else:
                    # Lae_Kabel kuerzer als die Linie wird erst beim finalen Export korrigiert, hier nicht pruefen
                    if decimals(Vb.val(r, 'Lae_Kabel')) > 2:
                        self.hinweis('VB_LAENGE_NACHKOMMA', r,
                                     f'Verbindung {r.key}: Lae_Kabel={lae} mit vielen Nachkommastellen.',
                                     'Deutet auf ueberlagerte Geometrien beim Export hin. < 15 m: umlegen; '
                                     'ab 15 m: Muffe nachdokumentieren.')

            # Oberirdisch <-> Trassenbau Verfahren 10
            tr_hier = self.touching(r.geom, self.tr)
            tr_ober = [t for t in tr_hier if self.tr_oberirdisch(t)
                       and self.buffered(self.tr, t).intersects(r.geom)]
            if tr_ober and not ober:
                ln = sum(self.length_m(self.buffered(self.tr, t).intersection(r.geom)) for t in tr_ober)
                if ln > self.min_len:
                    self.fehler('VB_OBERIRDISCH_NICHT_MARKIERT', r,
                                f'Verbindung {r.key}: liegt auf oberirdischem Trassenbau (Verfahren 10, ID={[t.id for t in tr_ober][:5]}), '
                                f'V_A_Sonst="{sonst}".',
                                'V_A_Sonst mit "oberirdisch" voranstellen (z.B. "oberirdisch Gf 12 Fs").')

            # Verbindung muss auf Leerrohr liegen (ausser oberirdisch / Funk / im Gebaeude bis Gf-AP)
            if not ober and not funk:
                rest, _ = self.uncovered(r.geom, self.lr)
                rest, rest_len = self.haus_rest(r, rest)
                if rest_len > self.min_len and tr_ober:
                    # Anteil auf Verfahren 10 ist schon als VB_OBERIRDISCH_NICHT_MARKIERT gemeldet
                    rest, rest_len = self.uncovered(rest, self.tr, self.tr_oberirdisch)
                if rest_len > self.min_len:
                    self.fehler('VB_OHNE_LEERROHR', r,
                                f'Verbindung {r.key}: {rest_len:.1f} m ohne Leerrohr.',
                                'Leerrohr fehlt (Megaplan: fehlende Rohre?) oder Kabel ist oberirdisch '
                                '(V_A_Sonst "oberirdisch ..." + Trassenbau VERFAHREN 10).',
                                geom=rest)

            # Oberirdischer Neubau braucht Trassenbau (Verfahren 10), soweit nicht im Leerrohr.
            # Trassenbau mit anderem Verfahren meldet die Trassenbau-Pruefung (TB_VERFAHREN_NICHT_10).
            if ober and neu:
                rest, _ = self.uncovered(r.geom, self.lr)
                rest, _ = self.haus_rest(r, rest)
                rest, rest_len = self.uncovered(rest, self.tr)
                if rest_len > self.min_len:
                    self.fehler('VB_OBERIRDISCH_OHNE_TRASSENBAU', r,
                                f'Verbindung {r.key}: oberirdisches Neubaukabel auf {rest_len:.1f} m ohne Trassenbau '
                                f'und ohne Leerrohr.',
                                'Trassenbau mit VERFAHREN = 10 (oberirdische Verlegung) ergaenzen.', geom=rest)

            # Kabelendpunkte: Netztechnik an beiden Enden
            if a_pt is not None:
                for label, pt in (('Start', a_pt), ('Ende', e_pt)):
                    if self.near_point(pt, self.nt):
                        continue
                    andere = [o for (p, o) in vb_ends if o.fid != r.fid and self.same_pt(p, pt)]
                    if andere:
                        self.fehler('VB_ENDE_OHNE_MUFFE', r,
                                    f'Verbindung {r.key}: {label}punkt ohne Netztechnik, dort beginnt Kabel '
                                    f'ID={[o.id for o in andere][:4]}.',
                                    'Muffe (Art 3) setzen oder Kabelstuecke zusammenfuehren.',
                                    geom=QgsGeometry.fromPointXY(pt))
                    else:
                        self.fehler('VB_ENDE_OHNE_NETZTECHNIK', r,
                                    f'Verbindung {r.key}: {label}punkt ohne Netztechnik.',
                                    'Netztechnik setzen; nicht gebauter Gf-AP: Kabelende mit Art=3, Art_Sonst="Kabelende".',
                                    geom=QgsGeometry.fromPointXY(pt))

            # ID_START / ID_ENDE
            for fld, pt in (('ID_START', a_pt), ('ID_ENDE', e_pt)):
                if not Vb.has_field(fld):
                    continue
                ref = to_int(Vb.val(r, fld))
                if ref is None:
                    self.fehler('VB_ID_START_ENDE_FEHLT', r, f'Verbindung {r.key}: {fld} leer.',
                                'ID der Netztechnik am Kabelende eintragen.')
                    continue
                ntr = nt_by_id.get(ref)
                if ntr is None:
                    self.fehler('VB_ID_START_ENDE_UNBEKANNT', r, f'Verbindung {r.key}: {fld}={ref} nicht in Netztechnik.',
                                'Referenz korrigieren.')
                elif pt is not None and ntr.geom is not None and \
                        not (self.same_pt(ntr.geom.asPoint(), a_pt) or self.same_pt(ntr.geom.asPoint(), e_pt)):
                    self.fehler('VB_ID_START_ENDE_NICHT_AM_ENDE', r,
                                f'Verbindung {r.key}: Netztechnik {fld}={ref} liegt an keinem Kabelende.',
                                'Referenz oder Geometrie pruefen.')

    # ── Netztechnik ──────────────────────────────────────────────────────────

    def check_netztechnik(self):
        N = self.nt
        V = self.V
        nt_by_id = self._nt_by_id
        bez_count = Counter(to_text(N.val(r, 'Bezeichner')) for r in N.recs)

        for r in N.recs:
            if r.geom is None or r.geom.isNull() or r.geom.isEmpty():
                continue
            art     = self.nt_art(r)
            sonst   = to_text(N.val(r, 'Art_Sonst'))
            bez     = to_text(N.val(r, 'Bezeichner'))
            zustand = to_int(N.val(r, 'Zustand'))
            id_tech = to_int(N.val(r, 'ID_Tech'))
            kind    = self.nt_kind(r)

            if art is None or art not in V['nt_valid']:
                self.fehler('NT_ART_UNGUELTIG', r, f'Netztechnik {r.key}: Art={art} ist kein gueltiger Code.',
                            'Codes siehe GIS-NB / Interpretation (HVt, NVt/KVz, Muffe, Gf-AP, MSAN, 99 Sonstige).')
            if art in V['nt_sonst'] and not sonst:
                self.fehler('NT_SONST_FEHLT', r, f'Netztechnik {r.key}: Art=99 ohne Art_Sonst.',
                            'z.B. "Mastbox", "Mini-MSAN", "Mast", "Rohrende homes passed Ausbau", "NVt in Muffe".')
            if zustand not in (V['neu'], V['bestand']):
                self.fehler('NT_ZUSTAND_UNGUELTIG', r, f'Netztechnik {r.key}: Zustand={zustand}.',
                            f'Nur {V["neu"]} (Neu) oder {V["bestand"]} (Bestand).')
            if ('mastbox' in sonst.lower() or 'mastbox' in bez.lower()) and art not in V['nt_sonst']:
                self.fehler('NT_MASTBOX_ART', r, f'Netztechnik {r.key}: Mastbox mit Art={art}.',
                            'Mastbox: Art = 99, Art_Sonst = "Mastbox" (nicht 3 Muffe).')

            # Bezeichner
            if not bez:
                self.fehler('NT_BEZEICHNER_FEHLT', r, f'Netztechnik {r.key}: Bezeichner leer.',
                            'Eindeutigen Bezeichner vergeben (Schema siehe Interpretation).')
            else:
                if bez_count[bez] > 1 and kind not in ('muffe',):
                    self.hinweis('NT_BEZEICHNER_DOPPELT', r, f'Netztechnik {r.key}: Bezeichner "{bez}" {bez_count[bez]}x.',
                                 'Bezeichner sollte eindeutig sein.')
                muster = BEZEICHNER_MUSTER.get(kind)
                if muster and not muster.match(bez):
                    self.hinweis('NT_BEZEICHNER_MUSTER', r,
                                 f'Netztechnik {r.key} ({kind}): Bezeichner "{bez}" passt nicht zum Schema.',
                                 {'hvt': 'ONKZ+AsB, z.B. 51135', 'vt': 'ONKZ+AsB+"V"+Nr, z.B. 22834V1100',
                                  'msan': 'ONKZ+AsB+"A"+Nr, z.B. 22834A11', 'gfap': 'ONKZ+AsB+"P"+Nr, z.B. 22834P1100734',
                                  'rohrende': 'Rohrende_1, Rohrende_2, ...', 'mast': 'Mast_1, Mast_2, ...'}.get(kind, ''))

            # ID_Tech
            if N.has_field('ID_Tech'):
                if kind == 'gfap':
                    self._check_id_tech(r, id_tech, ('vt',), 'ID des versorgenden NVt')
                elif kind in ('vt', 'msan'):
                    self._check_id_tech(r, id_tech, ('hvt', 'msan'), 'ID des HVt (mitversorgter KVz: ID des MSAN)')
                elif kind in ('muffe', 'hvt', 'rohrende', 'mast', 'mastbox', 'sonst'):
                    if id_tech is not None and id_tech != -1:
                        self.fehler('NT_ID_TECH_MUSS_MINUS1', r,
                                    f'Netztechnik {r.key} ({kind}): ID_Tech={id_tech}.',
                                    'Muffen, HVt, Mast, Mastbox und Rohrende erhalten ID_Tech = -1.')

            # Lage: auf Leerrohr oder Verbindung
            on_lr = self.touching(r.geom, self.lr)
            on_vb = self.touching(r.geom, self.vb)
            if not on_lr and not on_vb:
                self.fehler('NT_NICHT_AUF_LINIE', r, f'Netztechnik {r.key} ({kind}): liegt auf keinem Leerrohr/Kabel.',
                            'Punkt exakt auf die Linie snappen (Fangen auf Stuetzpunkt/Segment).')
            elif kind in ('muffe', 'gfap', 'vt', 'hvt', 'msan') and not on_vb and kind != 'gfap':
                self.hinweis('NT_OHNE_KABEL', r, f'Netztechnik {r.key} ({kind}): kein Kabel an diesem Punkt.',
                             'Verbindung endet nicht an der Netztechnik? Geometrie/Kabelende pruefen.')

            # Rohrende
            if kind == 'rohrende':
                if zustand != V['neu']:
                    self.fehler('NT_ROHRENDE_ZUSTAND', r, f'Netztechnik {r.key}: Rohrende mit Zustand={zustand}.',
                                'Rohrende: Zustand = 1.')
                if id_tech != -1:
                    self.fehler('NT_ROHRENDE_ID_TECH', r, f'Netztechnik {r.key}: Rohrende mit ID_Tech={id_tech}.',
                                'Rohrende: ID_Tech = -1.')
                pt = r.geom.asPoint()
                am_ende = any(self.same_pt(pt, p) for lr in on_lr for p in line_endpoints(lr.geom) if p is not None)
                if on_lr and not am_ende:
                    self.fehler('NT_ROHRENDE_LINIENMITTE', r, f'Netztechnik {r.key}: Rohrende liegt nicht am Ende eines Leerrohrs.',
                                'Rohrende an den letzten Vertex des Rohres setzen.')
                durchlaufend = [lr for lr in on_lr if not any(self.same_pt(pt, p) for p in line_endpoints(lr.geom) if p is not None)]
                if durchlaufend:
                    self.fehler('NT_ROHRENDE_AN_KREUZUNG', r,
                                f'Netztechnik {r.key}: Rohrende, aber Leerrohr ID={[d.id for d in durchlaufend][:4]} laeuft weiter.',
                                'Rohrende nur setzen, wo an derselben Stelle kein anderes Rohr weiterfuehrt.')
                if on_vb:
                    self.hinweis('NT_ROHRENDE_AUF_KABEL', r, f'Netztechnik {r.key}: Rohrende auf einem Kabel.',
                                 'Liegt hier ein Kabel, ist eher eine Muffe / ein Kabelende gemeint.')

        # Rohrende fehlt: Netzenden neuer Leerrohre ohne Netztechnik
        for lr in self.lr.recs:
            if lr.geom is None or lr.geom.isNull() or lr.geom.isEmpty() or not self.lr_zustand_neu(lr):
                continue
            for label, pt in zip(('Start', 'Ende'), line_endpoints(lr.geom)):
                if pt is None:
                    continue
                if self.near_point(pt, self.nt):
                    continue
                if self.near_point(pt, self.vb):
                    continue
                andere = self.near_point(pt, self.lr, lambda c, cur=lr: c.fid != cur.fid)
                if andere:
                    continue
                self.fehler('LR_ROHRENDE_FEHLT', lr,
                            f'Leerrohr {lr.key}: Netzende am {label}punkt ohne Rohrende/Netztechnik.',
                            'Rohrende setzen: Art 99, Art_Sonst "Rohrende Homes Passed Ausbau", Zustand 1, '
                            'Bezeichner Rohrende_n, ID_Tech -1.' + (' Linie ggf. umkehren (Ende = letzter Vertex).' if label == 'Start' else ''),
                            geom=QgsGeometry.fromPointXY(pt))

    def _check_id_tech(self, r, id_tech, parent_kinds, soll_text):
        kind = self.nt_kind(r)
        if id_tech is None or id_tech == -1:
            sev = self.fehler if kind == 'gfap' else self.hinweis
            sev('NT_ID_TECH_FEHLT', r, f'Netztechnik {r.key} ({kind}): ID_Tech={id_tech}.',
                f'{soll_text} eintragen.')
            return
        parent = self._nt_by_id.get(id_tech)
        if parent is None:
            self.hinweis('NT_ID_TECH_UNBEKANNT', r, f'Netztechnik {r.key} ({kind}): ID_Tech={id_tech} nicht im Layer.',
                         f'{soll_text}; liegt die uebergeordnete Technik ausserhalb des Projekts, ist das OK.')
        elif self.nt_kind(parent) not in parent_kinds:
            self.fehler('NT_ID_TECH_FALSCHE_ART', r,
                        f'Netztechnik {r.key} ({kind}): ID_Tech={id_tech} verweist auf {self.nt_kind(parent)} '
                        f'(Art={self.nt_art(parent)}).', f'{soll_text}.')
        elif parent.fid == r.fid:
            self.fehler('NT_ID_TECH_SELBST', r, f'Netztechnik {r.key}: ID_Tech verweist auf sich selbst.', soll_text)

    # ── Reserven-Abgleich je Streckenabschnitt ───────────────────────────────

    def reserve_abschnitte(self):
        """Leerrohre an allen Knoten (Linienenden von Leerrohren und Verbindungen) in
        Abschnitte teilen; deckungsgleiche Abschnitte nur einmal.

        Knoten werden auch geteilt, wenn sie nicht als Vertex im Leerrohr liegen
        (z.B. Kabelende mitten auf einem geraden Rohrstueck)."""
        L, Vb = self.lr, self.vb
        nidx, npts = QgsSpatialIndex(), {}
        for layer in (L, Vb):
            for r in layer.recs:
                for g in line_parts(r.geom):
                    for p in line_endpoints(g):
                        if p is None:
                            continue
                        k = self.pt_key(p)
                        if k not in npts:
                            f = QgsFeature(len(npts))
                            f.setGeometry(QgsGeometry.fromPointXY(p))
                            npts[k] = p
                            nidx.addFeature(f)
        nlist = list(npts.values())

        segments = {}   # key -> QgsGeometry
        for r in L.recs:
            for g in line_parts(r.geom):
                pts = g.asPolyline()
                if len(pts) < 2:
                    continue
                total = g.length()
                bb = g.boundingBox()
                bb.grow(self.tol)
                cuts = []
                for i in nidx.intersects(bb):
                    pg = QgsGeometry.fromPointXY(nlist[i])
                    if g.distance(pg) > self.tol:
                        continue
                    d = g.lineLocatePoint(pg)
                    if self.tol < d < total - self.tol:
                        cuts.append((d, nlist[i]))
                for piece in split_polyline(pts, cuts, self.tol):
                    key = tuple(self.pt_key(p) for p in piece)
                    key = min(key, tuple(reversed(key)))
                    if key not in segments:
                        segments[key] = QgsGeometry.fromPolylineXY(piece)

        # Abschnitte mit gleichen Endpunkten und gegenseitiger Ueberdeckung zusammenfassen
        by_ends = defaultdict(list)
        for key, g in segments.items():
            by_ends[(key[0], key[-1])].append((key, g))
        unique = []
        for ends, lst in by_ends.items():
            kept = []
            for key, g in lst:
                gb = g.buffer(self.tol, 4)
                if not any(gb.contains(g2) and g2b.contains(g) for g2, g2b in kept):
                    kept.append((g, gb))
            unique.extend(g for g, _ in kept)
        return unique

    def check_reserven_abgleich(self):
        """Nur auf neu gebauten Trassen (Abschnittsteil unter Trassenbau): belegte Neubaurohre (LR_Anzahl x Anzahl - LR_Reserv, ohne Aussenrohre) gegen
        Neubaukabel je Abschnitt. Bestandsrohre haben immer LR_Reserv 0 und werden nicht
        verglichen; Bestandskabel zaehlen nicht mit (sie liegen in Bestandsrohren).
        Mehr Neubaukabel als belegte Neubaurohre ist nur dann ein Fehler, wenn im
        Abschnitt kein Bestandsrohr liegt, in das die Kabel eingezogen sein koennten.
        Ausgegeben werden nur Abweichungen."""
        L, Vb = self.lr, self.vb
        n_total = 0
        for seg in self.reserve_abschnitte():
            seg_len = self.length_m(seg)
            if seg_len < self.min_len:
                continue
            seg = self.covered_part(seg, self.tr)          # nur neu gebaute Trasse
            if seg is None:
                continue
            seg_len = self.length_m(seg)
            if seg_len <= self.min_len:
                continue
            lrs   = self.covering(seg, L)
            rohre = [x for x in lrs if not self.lr_is_aussenrohr(x)]
            if not rohre:
                continue
            n_total += 1
            neu_rohre     = [x for x in rohre if self.lr_zustand_neu(x)]
            bestand_rohre = [x for x in rohre if self.lr_zustand_bestand(x)]
            kabel = [v for v in self.covering(seg, Vb, lambda c: not self.vb_oberirdisch(c)
                                              and to_int(Vb.val(c, 'Verb_Art')) != VERB_ART_FUNK)
                     if not self.vb_zustand_bestand(v)]
            belegt = 0
            for x in neu_rohre:
                kap = (to_int(L.val(x, 'LR_Anzahl')) or 1) * (to_int(L.val(x, 'Anzahl')) or 1)
                res = to_int(L.val(x, 'LR_Reserv')) or 0
                belegt += max(kap - res, 0)
            diff = len(kabel) - belegt
            if diff == 0 or (diff > 0 and bestand_rohre):
                continue

            row = {
                'geom': seg, 'laenge_m': round(seg_len, 1), 'status': 'ABWEICHUNG',
                'rohre_belegt': belegt, 'kabel': len(kabel), 'differenz': diff,
                'leerrohre': ', '.join(str(x.id) for x in lrs),
                'kabel_ids': ', '.join(str(v.id) for v in kabel),
            }
            if diff > 0:
                row['meldung'] = (f'{len(kabel)} Neubaukabel, aber nur {belegt} belegte Neubaurohre laut LR_Reserv '
                                  f'(Reserve zu hoch oder Rohr fehlt).')
            else:
                row['meldung'] = (f'{belegt} belegte Neubaurohre laut LR_Reserv, aber nur {len(kabel)} Neubaukabel '
                                  f'(Reserve zu niedrig, Kabel fehlt oder SNRe loeschen).')
            self.reserve_rows.append(row)
            self.fehler('RESERVE_ABWEICHUNG', 'Leerrohre',
                        f'Abschnitt ({seg_len:.0f} m), Leerrohre {", ".join(str(x.id) for x in rohre)}: ' + row['meldung'],
                        'LR_Reserv je Rohr = LR_Anzahl x Anzahl - Kabel im Rohr; SNR 10/8 mit Kabel = 0. '
                        f'Kabel hier: {row["kabel_ids"] or "keine"}.',
                        geom=seg, feat_id=rohre[0].id)
        self.reserve_total = n_total
        self.info(f'Reserven-Abgleich: {n_total} Abschnitte, {len(self.reserve_rows)} Abweichung(en)')

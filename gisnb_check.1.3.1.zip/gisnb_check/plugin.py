# -*- coding: utf-8 -*-
import os
from qgis.core import QgsApplication
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QAction
from qgis.PyQt.QtGui import QIcon
from .provider import GisNbCheckProvider


class GisNbCheckPlugin:

    def __init__(self, iface):
        self.iface    = iface
        self.provider = None
        self.action   = None
        self.panel    = None

    def initProcessing(self):
        self.provider = GisNbCheckProvider()
        QgsApplication.processingRegistry().addProvider(self.provider)

    def initGui(self):
        from .panel import GisNbCheckPanel

        self.initProcessing()
        icon = QIcon(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icon.png'))
        self.action = QAction(icon, 'GIS-NB Check', self.iface.mainWindow())
        self.action.setToolTip('GIS-NB Netzplan pruefen (3.1 / 4.0 / 4.1, Leitfaden CCGIS)')
        self.action.setCheckable(True)
        self.action.triggered.connect(self._toggle_panel)
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToVectorMenu('GIS-NB Tools', self.action)

        self.panel = GisNbCheckPanel(self.iface, self.iface.mainWindow())
        self.iface.mainWindow().addDockWidget(Qt.RightDockWidgetArea, self.panel)
        self.panel.hide()
        self.panel.visibilityChanged.connect(self.action.setChecked)

    def _toggle_panel(self, checked):
        if self.panel:
            if checked:
                self.panel.show()
                self.panel.raise_()
            else:
                self.panel.hide()

    def unload(self):
        if self.action:
            self.iface.removeToolBarIcon(self.action)
            self.iface.removePluginVectorMenu('GIS-NB Tools', self.action)
        if self.panel:
            self.iface.mainWindow().removeDockWidget(self.panel)
            self.panel.deleteLater()
            self.panel = None
        if self.provider:
            QgsApplication.processingRegistry().removeProvider(self.provider)

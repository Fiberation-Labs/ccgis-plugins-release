# -*- coding: utf-8 -*-
"""
GIS-NB 3.1: Pruefungen des frueheren Plugins "GIS-NB Validator" (gis_nb_validator),
uebernommen in den GIS-NB Check.

In 3.1 verweisen Leerrohre und Verbindungen per ID_TRASSEN / ID_LR auf Trassenbau
bzw. Leerrohre, Verbindungen per ID_START / ID_ENDE auf Netztechnik und
Netztechnik per ID_BAU auf Bauten. Geprueft werden diese Referenzen, die
Ueberdeckung der referenzierten Geometrien, Kabelketten und Rohrenden.

Lage-Vergleiche sind wie in 4.x exakt (EPS_M nur fuer Rundungsrauschen).
"""
from collections import Counter, defaultdict

from qgis.core import QgsGeometry

from .checks import (
    AUSSENROHR_RE, FEHLER, HINWEIS, CheckerBase, Layer, line_endpoints, to_int, to_text,
)

ART_NT_GFAP       = 4
ART_NT_ROHRENDE   = 99
ID_BAU_KEIN_BAU   = -99
VERFAHREN_OBERIRD = 10
ZUSTAND_BESTAND   = 1
ZUSTAND_NEU       = 2
LR_ART_AUSSENROHR = 1
SNAP_M            = 1.0     # GF-AP neben der Linie: als Snap-Fehler melden


class GisNb31Checker(CheckerBase):

    version = '3.1'

    def __init__(self, lr, tr, vb, nt, ba=None, mv=None, tol_m=0.0, feedback=None):
        super().__init__(lr, tr, vb, nt, mv, tol_m, feedback)
        self.ba   = Layer('Bauten', ba) if ba is not None else None
        self.snap = SNAP_M / self.m_lon if self.geographic else SNAP_M

    # ── Attribut-Kurzformen ──────────────────────────────────────────────────

    def art_nt(self, rec):
        return to_int(self.nt.val(rec, 'ART_NT'))

    def is_gfap(self, rec):
        return self.art_nt(rec) == ART_NT_GFAP

    def is_rohrende(self, rec):
        return self.art_nt(rec) == ART_NT_ROHRENDE

    def lr_neu(self, rec):
        return to_int(self.lr.val(rec, 'ZUSTAND')) == ZUSTAND_NEU

    def lr_is_aussenrohr(self, rec):
        art = to_int(self.lr.val(rec, 'LR_ART'))
        return art == LR_ART_AUSSENROHR or (art == 99 and bool(AUSSENROHR_RE.search(to_text(self.lr.val(rec, 'LR_SONST')))))

    def within(self, geom, layer, rec):
        """geom liegt vollstaendig auf rec (exakt, bis auf Rundung)."""
        return self.buffered(layer, rec).contains(geom)

    def is_interior(self, pt, geom):
        """pt ist weder erster noch letzter Vertex von geom."""
        a, b = line_endpoints(geom)
        return not ((a is not None and self.same_pt(pt, a)) or (b is not None and self.same_pt(pt, b)))

    def nur_im_haus(self, rec, geom):
        """Kabel(-stueck) liegt nur im Gebaeude: am Gf-AP-Ende, ohne Leerrohr und Trassenbau."""
        rest, _ = self.uncovered(geom, self.lr)
        rest, rest_len = self.haus_rest(rec, rest)
        return rest_len <= self.min_len

    # ── Lauf ─────────────────────────────────────────────────────────────────

    def run(self):
        self.info(f'GIS-NB Check 3.1 (Validator)  |  LR={len(self.lr.recs)} TR={len(self.tr.recs)} '
                  f'VB={len(self.vb.recs)} NT={len(self.nt.recs)}'
                  + (f' BA={len(self.ba.recs)}' if self.ba else '')
                  + (f' MV={len(self.mv.recs)}' if self.mv else ''))
        self.lr_by_id = {r.id: r for r in self.lr.recs if r.id is not None}
        self.tr_by_id = {r.id: r for r in self.tr.recs if r.id is not None}
        self.nt_by_id = {r.id: r for r in self.nt.recs if r.id is not None}

        for layer in [self.nt, self.vb, self.lr, self.tr] + ([self.mv] if self.mv else []):
            self.check_allgemein(layer)
        self.check_netztechnik_lage()
        self.check_leerrohre_trassenbau()
        self.check_verbindungen_leerrohre()
        self.check_verbindungen_trassenbau()
        self.check_kabelketten()
        self.check_bauten()
        self.check_rohrenden()
        return self.findings

    def ok(self, rec):
        g = rec.geom
        return g is not None and not g.isNull() and not g.isEmpty()

    # ── Block 0: Netztechnik auf Linienlayern ────────────────────────────────

    def check_netztechnik_lage(self):
        for r in self.nt.recs:
            if not self.ok(r):
                continue
            if self.touching(r.geom, self.lr) or self.touching(r.geom, self.vb):
                continue
            nahe = any(c.geom.distance(r.geom) < self.snap
                       for layer in (self.lr, self.vb) for c in layer.candidates(r.geom, self.snap))
            art = self.art_nt(r)
            zusatz = ' Snap-Fehler (~1 m Abstand).' if nahe else ' Vollstaendig isoliert.'
            if art == ART_NT_GFAP:
                zusatz += ' Hauseinfuehrungs-Ausnahme fuer anschliessende Rohre greift nicht.'
            self.fehler('NT_NICHT_AUF_LINIE', r,
                        f'Netztechnik {r.key} (ART_NT={art}) liegt auf keinem Leerrohr/Kabel.' + zusatz,
                        'Punkt exakt auf die Linie snappen.')

    # ── Block 1: Leerrohre -> Trassenbau ─────────────────────────────────────

    def check_leerrohre_trassenbau(self):
        L, T = self.lr, self.tr
        for r in L.recs:
            if not self.ok(r):
                continue
            id_tr   = to_int(L.val(r, 'ID_TRASSEN'))
            bestand = to_int(L.val(r, 'ZUSTAND')) == ZUSTAND_BESTAND

            if id_tr is None:
                if bestand:
                    continue        # Zustand wird nicht hinterfragt
                if self.touching(r.geom, self.nt, self.is_gfap):
                    continue        # Hauseinfuehrung, kein Trassenbau noetig
                nahe = [g for g in self.nt.candidates(r.geom, self.snap)
                        if self.is_gfap(g) and self.tol < r.geom.distance(g.geom) < self.snap]
                if nahe:
                    self.fehler('SNAP_GFAP_NICHT_AUF_LINIE', r,
                                f'Neubaurohr {r.key} ohne ID_TRASSEN: GF-AP liegt nahe (~1 m), aber nicht auf der Linie.',
                                'GF-AP bzw. Rohrende exakt snappen.')
                    continue
                einzug = self.covering(r.geom, L, lambda c, rr=r: c.fid != rr.fid and self.lr_is_aussenrohr(c)
                                       and to_int(L.val(c, 'ZUSTAND')) in (ZUSTAND_BESTAND, ZUSTAND_NEU))
                if einzug:
                    continue        # Einzug in Aussen-/Schutzrohr, kein Trassenbau noetig
                tbs = self.covering(r.geom, T)
                if tbs:
                    self.fehler('FEHLENDE_ID_TRASSEN', r,
                                f'Neubaurohr {r.key} ohne ID_TRASSEN, Trassenbau {[t.id for t in tbs]} liegt darueber.',
                                'ID_TRASSEN eintragen.')
                else:
                    self.hinweis('NEUBAU_OHNE_TRASSENBAU', r,
                                 f'Neubaurohr {r.key} ohne ID_TRASSEN, ohne Trassenbau und ohne GF-AP.',
                                 'HDD/Mitverlegung? Bitte pruefen.')
                continue

            tb = self.tr_by_id.get(id_tr)
            if tb is None:
                self.fehler('ID_NICHT_GEFUNDEN', r, f'Leerrohr {r.key}: ID_TRASSEN={id_tr} existiert nicht in Trassenbau.',
                            'Referenz korrigieren.')
                continue
            if not self.within(r.geom, T, tb):
                self.fehler('GEOMETRIE_ABWEICHUNG', r,
                            f'Leerrohr {r.key}: liegt nicht vollstaendig auf Trassenbau ID_TRASSEN={id_tr}.',
                            'Geometrie oder Referenz pruefen.')
                continue
            if not bestand:
                verl_lr = to_text(L.val(r, 'VERL_TIEFE'))
                verl_tr = to_text(T.val(tb, 'VERL_TIEFE'))
                if not verl_lr:
                    self.fehler('VERL_TIEFE_FEHLT', r, f'Neubaurohr {r.key} mit ID_TRASSEN={id_tr}, VERL_TIEFE leer.',
                                f'VERL_TIEFE des Trassenbaus uebernehmen ({verl_tr or "?"}).')
                elif verl_tr and verl_lr != verl_tr:
                    self.fehler('VERL_TIEFE_ABWEICHUNG', r,
                                f'Leerrohr {r.key}: VERL_TIEFE={verl_lr} <> Trassenbau VERL_TIEFE={verl_tr} '
                                f'(ID_TRASSEN={id_tr}).', 'VERL_TIEFE angleichen.')

    # ── Block 2: Verbindungen -> Leerrohre (ID_LR) ───────────────────────────

    def check_verbindungen_leerrohre(self):
        Vb = self.vb
        for r in Vb.recs:
            if not self.ok(r):
                continue
            id_lr = to_int(Vb.val(r, 'ID_LR'))
            if id_lr is None:
                if not self.vb_oberirdisch(r):
                    if self.nur_im_haus(r, r.geom) and not self.covered_part(r.geom, self.lr):
                        continue    # Kabelstueck im Gebaeude bis zum Gf-AP
                    self.fehler('ID_LR_FEHLT', r,
                                f'Verbindung {r.key}: ID_LR leer und V_A_SONST ohne oberirdisch-Hinweis '
                                f'(V_A_SONST="{to_text(Vb.val(r, "V_A_SONST"))}").',
                                'ID_LR eintragen oder V_A_SONST "oberirdisch ..." setzen.')
                    continue
                if to_int(Vb.val(r, 'ZUSTAND')) != ZUSTAND_BESTAND and to_int(Vb.val(r, 'ID_TRASSEN')) is None:
                    self.fehler('ID_TRASSEN_FEHLT_OBERIRDISCH', r,
                                f'Verbindung {r.key}: oberirdischer Neubau ohne ID_TRASSEN.',
                                'Trassenbau (VERFAHREN 10) referenzieren.')
                continue
            lr = self.lr_by_id.get(id_lr)
            if lr is None:
                self.fehler('ID_NICHT_GEFUNDEN', r, f'Verbindung {r.key}: ID_LR={id_lr} existiert nicht in Leerrohre.',
                            'Referenz korrigieren.')
                continue
            if not self.within(r.geom, self.lr, lr):
                rest = r.geom.difference(self.buffered(self.lr, lr))
                rest, rest_len = self.haus_rest(r, None if rest.isEmpty() else rest)
                if rest_len > self.min_len:
                    self.fehler('GEOMETRIE_ABWEICHUNG', r,
                                f'Verbindung {r.key}: liegt auf {rest_len:.1f} m nicht auf Leerrohr ID_LR={id_lr}.',
                                'Geometrie oder Referenz pruefen.', geom=rest)

    # ── Block 3: Verbindungen -> Trassenbau (ID_TRASSEN, falls befuellt) ─────

    def check_verbindungen_trassenbau(self):
        Vb, T = self.vb, self.tr
        for r in Vb.recs:
            if not self.ok(r):
                continue
            id_tr = to_int(Vb.val(r, 'ID_TRASSEN'))
            if id_tr is None:
                continue
            tb = self.tr_by_id.get(id_tr)
            if tb is None:
                self.fehler('ID_NICHT_GEFUNDEN', r, f'Verbindung {r.key}: ID_TRASSEN={id_tr} existiert nicht in Trassenbau.',
                            'Referenz korrigieren.')
                continue
            if not self.within(r.geom, T, tb):
                self.fehler('GEOMETRIE_ABWEICHUNG', r,
                            f'Verbindung {r.key}: liegt nicht vollstaendig auf Trassenbau ID_TRASSEN={id_tr}.',
                            'Geometrie oder Referenz pruefen.')
                continue
            verf  = to_int(T.val(tb, 'VERFAHREN'))
            ob    = self.vb_oberirdisch(r)
            tb_ob = verf == VERFAHREN_OBERIRD
            if ob and not tb_ob:
                self.fehler('VERFAHREN_NICHT_OBERIRDISCH', r,
                            f'Verbindung {r.key}: oberirdisch (V_A_SONST), Trassenbau ID={id_tr} hat VERFAHREN={verf}.',
                            f'VERFAHREN = {VERFAHREN_OBERIRD} setzen.')
            elif not ob and tb_ob:
                self.fehler('VERBINDUNG_NICHT_OBERIRDISCH_MARKIERT', r,
                            f'Verbindung {r.key}: Trassenbau ID={id_tr} hat VERFAHREN={VERFAHREN_OBERIRD} (oberirdisch), '
                            f'V_A_SONST ohne oberirdisch-Kennzeichen.', 'V_A_SONST "oberirdisch ..." setzen.')

    # ── Block 4: Verbindungen -> Netztechnik (Kabelketten) ───────────────────

    def check_kabelketten(self):
        Vb = self.vb
        groups = defaultdict(list)
        for r in Vb.recs:
            id_s, id_e = to_int(Vb.val(r, 'ID_START')), to_int(Vb.val(r, 'ID_ENDE'))
            if id_s is None or id_e is None:
                self.fehler('ID_START_ENDE_FEHLT', r, f'Verbindung {r.key}: ID_START={id_s} oder ID_ENDE={id_e} leer.',
                            'IDs der Netztechnik an Kabelanfang und -ende eintragen.')
                continue
            if self.ok(r):
                groups[(id_s, id_e)].append(r)

        for (id_s, id_e), segs in groups.items():
            errs = []
            nt_s, nt_e = self.nt_by_id.get(id_s), self.nt_by_id.get(id_e)
            if nt_s is None:
                errs.append(('ID_START_NICHT_GEFUNDEN', f'ID_START={id_s} existiert nicht in Netztechnik (-> ID_ENDE={id_e}).'))
            if nt_e is None:
                errs.append(('ID_ENDE_NICHT_GEFUNDEN', f'ID_ENDE={id_e} existiert nicht in Netztechnik (von ID_START={id_s}).'))

            ends = []
            for s in segs:
                a, b = line_endpoints(s.geom)
                ends.extend(self.pt_key(p) for p in (a, b) if p is not None)
            count = Counter(ends)
            true_ends = {k for k, n in count.items() if n == 1}
            known = {self.pt_key(n.geom.asPoint()) for n in (nt_s, nt_e) if n is not None and self.ok(n)}

            if true_ends - known:
                errs.append(('KABEL_KETTE_UNTERBROCHEN',
                             f'Kabel {id_s}->{id_e}: {len(true_ends - known)} isolierte(r) Zwischenendpunkt(e), '
                             f'Segmente nicht durchgehend verbunden ({len(segs)} Segment(e)).'))
            forks = [k for k, n in count.items() if n > 2]
            if forks:
                errs.append(('KABEL_VERZWEIGUNG',
                             f'Kabel {id_s}->{id_e}: {len(forks)} Punkt(e) von 3+ Segmenten geteilt, keine einfache Linie.'))
            for label, n, nid in (('ID_START', nt_s, id_s), ('ID_ENDE', nt_e, id_e)):
                if n is not None and self.ok(n) and self.pt_key(n.geom.asPoint()) not in true_ends:
                    errs.append((f'{label}_NICHT_AM_KABELENDE',
                                 f'Netztechnik {label}={nid} liegt nicht am Endpunkt des Kabels {id_s}->{id_e} '
                                 f'({len(segs)} Segment(e)).'))
            if errs:
                merged = QgsGeometry.unaryUnion([s.geom for s in segs])
                for code, msg in errs:
                    self.fehler(code, 'Verbindungen', msg, 'Kabelsegmente, ID_START/ID_ENDE und Netztechnik pruefen.',
                                geom=merged, feat_id=id_s)

    # ── Block 5: Netztechnik.ID_BAU -> Bauten ────────────────────────────────

    def check_bauten(self):
        N = self.nt
        if self.ba is None:
            self.notes.append((HINWEIS, 'BAUTEN_FEHLT', 'Bauten',
                               'Bauten-Layer nicht gewaehlt: ID_BAU-Pruefung uebersprungen.'))
        for r in N.recs:
            if not self.ok(r):
                continue
            id_bau = to_int(N.val(r, 'ID_BAU'))
            if id_bau is None:
                self.hinweis('ID_BAU_NULL', r, f'Netztechnik {r.key}: ID_BAU leer (erwartet Bauten-ID oder -99).',
                             'ID_BAU eintragen.')
                continue
            if id_bau == ID_BAU_KEIN_BAU or self.ba is None:
                continue
            hier = [b for b in self.ba.candidates(r.geom, self.tol) if self.buffered(self.ba, b).contains(r.geom)]
            if not hier:
                self.fehler('NT_NICHT_IN_BAUTEN', r,
                            f'Netztechnik {r.key} liegt in keinem Bauten-Feature (ID_BAU={id_bau}).',
                            'Punkt oder Bauten-Geometrie pruefen, ohne Bauwerk ID_BAU = -99.')
            elif hier[0].id != id_bau:
                self.fehler('ID_BAU_FALSCH', r,
                            f'Netztechnik {r.key}: ID_BAU={id_bau}, liegt aber in Bauten ID={hier[0].id}.',
                            'ID_BAU korrigieren.')

    # ── Block 6: Rohrenden ───────────────────────────────────────────────────

    def netzende(self, pt, rec):
        """Neubaurohr endet an pt, ohne dass das Netz weiterlaeuft."""
        for c in self.near_point(pt, self.lr, lambda c, rr=rec: c.fid != rr.fid):
            if self.is_interior(pt, c.geom):
                return False            # anderes Rohr laeuft durch
            if not (self.within(c.geom, self.lr, rec) or self.within(rec.geom, self.lr, c)):
                return False            # Knoten mit abzweigendem Rohr
        return not self.near_point(pt, self.vb)

    def check_rohrenden(self):
        for r in self.lr.recs:
            if not self.ok(r) or not self.lr_neu(r):
                continue
            a, e = line_endpoints(r.geom)
            if e is None:
                continue
            if self.netzende(e, r) and not self.near_point(e, self.nt, self.is_rohrende):
                self.fehler('ROHRENDE_FEHLT', r, f'Leerrohr {r.key}: Netzende am letzten Vertex ohne Rohrende (ART_NT=99).',
                            'Rohrende setzen.', geom=QgsGeometry.fromPointXY(e))
            if self.netzende(a, r):
                if self.near_point(a, self.nt, self.is_rohrende):
                    self.fehler('ROHRENDE_AM_FALSCHEN_ENDE', r,
                                f'Leerrohr {r.key}: Rohrende am Startpunkt (erster Vertex) statt am Endpunkt.',
                                'Linienrichtung umkehren.', geom=QgsGeometry.fromPointXY(a))
                else:
                    self.fehler('ROHRENDE_FEHLT', r, f'Leerrohr {r.key}: Netzende am ersten Vertex ohne Rohrende (ART_NT=99).',
                                'Rohrende setzen und Linie umkehren (Ende = letzter Vertex).',
                                geom=QgsGeometry.fromPointXY(a))

        for r in self.nt.recs:
            if not self.ok(r) or not self.is_rohrende(r):
                continue
            pt = r.geom.asPoint()
            lrs = self.near_point(pt, self.lr)
            if len(lrs) > 1:
                if any(self.is_interior(pt, c.geom) for c in lrs):
                    self.fehler('ROHRENDE_AN_KREUZUNG', r,
                                f'Rohrende {r.key} liegt an einem Kreuzungspunkt: {len(lrs)} Leerrohre, das Netz laeuft weiter.',
                                'Rohrende entfernen oder verschieben.')
            elif len(lrs) == 1 and self.is_interior(pt, lrs[0].geom):
                self.fehler('ROHRENDE_IN_LINIENMITTE', r,
                            f'Rohrende {r.key} liegt nicht am Vertex-Ende von Leerrohr ID={lrs[0].id}, sondern in der Linienmitte.',
                            'Rohrende an den letzten Vertex setzen.')

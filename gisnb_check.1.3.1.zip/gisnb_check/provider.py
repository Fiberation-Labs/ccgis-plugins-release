# -*- coding: utf-8 -*-
import os
from qgis.core import QgsProcessingProvider
from qgis.PyQt.QtGui import QIcon
from .algorithm import CheckGisNb


class GisNbCheckProvider(QgsProcessingProvider):

    def loadAlgorithms(self):
        self.addAlgorithm(CheckGisNb())

    def id(self):
        return 'gisnbcheck'

    def name(self):
        return 'GIS-NB Check'

    def longName(self):
        return 'GIS-NB Check (fiberation)'

    def icon(self):
        return QIcon(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icon.png'))

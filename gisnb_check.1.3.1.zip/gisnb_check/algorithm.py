# -*- coding: utf-8 -*-
import os

from qgis.core import (
    QgsFeature, QgsFeatureSink, QgsField, QgsFields, QgsProcessing,
    QgsProcessingAlgorithm, QgsProcessingParameterEnum,
    QgsProcessingParameterFeatureSink, QgsProcessingParameterVectorLayer,
    QgsWkbTypes,
)
from qgis.PyQt.QtCore import QVariant
from qgis.PyQt.QtGui import QIcon

from .checks import FEHLER, GisNbChecker
from .checks_v31 import GisNb31Checker


class CheckGisNb(QgsProcessingAlgorithm):
    """Prueft GIS-NB Netzplan-Layer auf typische Fehler (Leitfaden CCGIS)."""

    LR, TR, VB, NT, MV = 'LEERROHRE', 'TRASSENBAU', 'VERBINDUNGEN', 'NETZTECHNIK', 'MITVERLEGUNG'
    BA       = 'BAUTEN'
    VERSION  = 'VERSION'
    OUT_L    = 'ERGEBNIS_LINIEN'
    OUT_P    = 'ERGEBNIS_PUNKTE'

    VERSION_KEYS = ['3.1', '4.0', '4.1']
    VERSION_DEFAULT = 1

    def name(self):
        return 'check_gis_nb'

    def displayName(self):
        return 'GIS-NB Check (typische Fehler + Reserven-Abgleich)'

    def group(self):
        return 'GIS-NB Tools'

    def groupId(self):
        return 'gisnbtools'

    def icon(self):
        return QIcon(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'icon.png'))

    def createInstance(self):
        return CheckGisNb()

    def shortHelpString(self):
        return (
            '<b>Prueft die Netzplan-Layer auf die typischen Fehler aus dem '
            'Leitfaden Bearbeitung CCGIS und der Telekom-Interpretation der GIS-NB.</b><br>'
            'Die Lage der Geometrie (parallel zu Megaplan) wird nicht geprueft, '
            'nur leere/ungueltige/mehrteilige Geometrien. Lage-Vergleiche zwischen den Layern '
            '(Kabel auf Rohr, Punkt auf Linie) sind exakt, ohne Toleranz.<br><br>'
            '<b>GIS-NB 4.0 / 4.1</b><br>'
            '<b>Leerrohre:</b> Codes, LR_Art=1 unzulaessig, LR_Sonst bei 99, Dueker, '
            'LR_Anzahl/Anzahl-Plausibilitaet, LR_Reserv (Bestand = 0, Kapazitaet, Neubau > 0), '
            'Lae_LR (Nachkommastellen, mehr als doppelt so lang wie die Linie), SNR 10/8 ohne Aussenrohr, '
            'Bestands-MR als Aussenrohr, Neubaurohr ohne Trassenbau '
            '(Rohrstueck im Gebaeude am Gf-AP ausgenommen), '
            'Netzende ohne Rohrende. Lae_LR/Lae_Kabel kuerzer als die Linie wird nicht geprueft '
            '(Korrektur beim finalen Export).<br>'
            '<b>Trassenbau:</b> Mitverleg, Trassenbau ueber Bestandsrohren / ohne Leerrohr. '
            'Verfahren 10 (oberirdisch) braucht kein Leerrohr, aber ein Kabel; Trassenbau nur mit '
            'oberirdischem Kabel muss Verfahren 10 haben.<br>'
            '<b>Verbindungen:</b> Verb_Art zu Anzahl_F_A, 99 ohne V_A_Sonst, F_A_Reserv '
            '(unplausibel, Bestand/Kupfer = 0, Hausanschluss > 0), Lae_Kabel (Nachkommastellen), oberirdisch (V_A_Sonst) vs. '
            'Verfahren 10, Kabel ohne Leerrohr (Kabel im Gebaeude bis zum Gf-AP ist zulaessig), '
            'Kabelenden ohne Netztechnik, ID_START/ID_ENDE.<br>'
            '<b>Netztechnik:</b> Art/Art_Sonst/Zustand, Mastbox, Bezeichner-Schema, ID_Tech-Hierarchie '
            '(Gf-AP -> NVt -> HVt, Rest -1), Lage auf Linie, Rohrende-Regeln.<br>'
            '<b>Mitverlegung (optional, GIS-NB 3.1 / 4.1):</b> nur Geometrie und ID.<br>'
            '<b>Reserven-Abgleich je Streckenabschnitt (nur unter Trassenbau):</b> belegte Neubaurohre '
            '(LR_Anzahl x Anzahl - LR_Reserv, ohne KSR/KR/MR) gegen Anzahl Neubaukabel. '
            'Ausgegeben werden nur Abweichungen.<br><br>'
            '<b>GIS-NB 3.1</b> (frueherer GIS-NB Validator): ID_TRASSEN/ID_LR-Referenzen und '
            'Ueberdeckung, VERL_TIEFE, oberirdisch vs. Verfahren 10, Kabelketten ID_START/ID_ENDE, '
            'ID_BAU gegen Bauten (optionaler Layer), Rohrenden.<br><br>'
            'Ergebnis: Linien- und Punkt-Layer mit Schwere (FEHLER/HINWEIS), Pruefcode, '
            'Meldung und Korrekturhinweis; Reserven-Abweichungen stehen im Linien-Layer (RESERVE_ABWEICHUNG).'
        )

    def initAlgorithm(self, config=None):
        # Reihenfolge wie in der Layergruppe: Netztechnik/Bauten, Mitverlegung, Verbindungen, Leerrohre, Trassenbau
        self.addParameter(QgsProcessingParameterEnum(
            self.VERSION, 'GIS-NB Version', options=['GIS-NB ' + k for k in self.VERSION_KEYS],
            defaultValue=self.VERSION_DEFAULT))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.NT, 'Netztechnik / Bauten', [QgsProcessing.TypeVectorPoint]))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.BA, 'Bauten (optional, GIS-NB 3.1)', [QgsProcessing.TypeVectorAnyGeometry], optional=True))
        self.addParameter(QgsProcessingParameterVectorLayer(
            self.MV, 'Mitverlegung (optional, GIS-NB 3.1 / 4.1)', [QgsProcessing.TypeVectorAnyGeometry], optional=True))
        for key, label in [(self.VB, 'Verbindungen'), (self.LR, 'Leerrohre'), (self.TR, 'Trassenbau')]:
            self.addParameter(QgsProcessingParameterVectorLayer(key, label, [QgsProcessing.TypeVectorLine]))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUT_L, 'GIS-NB Check - Linien'))
        self.addParameter(QgsProcessingParameterFeatureSink(self.OUT_P, 'GIS-NB Check - Punkte'))

    # ── Felder ───────────────────────────────────────────────────────────────

    @staticmethod
    def result_fields():
        f = QgsFields()
        f.append(QgsField('schwere',  QVariant.String, 'String', 8))
        f.append(QgsField('pruefung', QVariant.String, 'String', 40))
        f.append(QgsField('layer',    QVariant.String, 'String', 20))
        f.append(QgsField('feat_id',  QVariant.Int))
        f.append(QgsField('meldung',  QVariant.String, 'String', 254))
        f.append(QgsField('hinweis',  QVariant.String, 'String', 254))
        return f

    # ── Lauf ─────────────────────────────────────────────────────────────────

    def processAlgorithm(self, parameters, context, feedback):
        lr = self.parameterAsVectorLayer(parameters, self.LR, context)
        tr = self.parameterAsVectorLayer(parameters, self.TR, context)
        vb = self.parameterAsVectorLayer(parameters, self.VB, context)
        nt = self.parameterAsVectorLayer(parameters, self.NT, context)
        ba = self.parameterAsVectorLayer(parameters, self.BA, context)
        mv = self.parameterAsVectorLayer(parameters, self.MV, context)
        version = self.VERSION_KEYS[self.parameterAsEnum(parameters, self.VERSION, context)]

        if version == '3.1':
            checker = GisNb31Checker(lr, tr, vb, nt, ba, mv, feedback=feedback)
        else:
            checker = GisNbChecker(lr, tr, vb, nt, mv, version=version, feedback=feedback)
        checker.run()
        summ = checker.summary()

        crs = lr.sourceCrs()
        rf  = self.result_fields()
        sink_l, dest_l = self.parameterAsSink(parameters, self.OUT_L, context, rf, QgsWkbTypes.MultiLineString, crs)
        sink_p, dest_p = self.parameterAsSink(parameters, self.OUT_P, context, rf, QgsWkbTypes.Point, crs)
        if sink_l is None or sink_p is None:
            feedback.reportError('Ergebnis-Layer konnten nicht erstellt werden.')
            return {}

        n_l = n_p = 0
        for f in checker.findings:
            g = f['geom']
            if g is None or g.isNull() or g.isEmpty():
                continue
            feat = QgsFeature(rf)
            feat.setAttributes([f['schwere'], f['code'], f['layer'], f['feat_id'],
                                f['meldung'][:254], f['hinweis'][:254]])
            if g.type() == QgsWkbTypes.PointGeometry:
                if g.isMultipart():
                    g = g.asGeometryCollection()[0]
                feat.setGeometry(g)
                sink_p.addFeature(feat, QgsFeatureSink.FastInsert); n_p += 1
            elif g.type() == QgsWkbTypes.LineGeometry:
                g2 = QgsFeature(rf)
                g2.setAttributes(feat.attributes())
                gm = g if g.isMultipart() else g.coerceToType(QgsWkbTypes.MultiLineString)[0]
                g2.setGeometry(gm)
                sink_l.addFeature(g2, QgsFeatureSink.FastInsert); n_l += 1
            else:
                # Geometry collection nach difference(): nur Linienanteile behalten
                parts = [p for p in g.asGeometryCollection() if p.type() == QgsWkbTypes.LineGeometry]
                if parts:
                    gm = QgsFeature(rf); gm.setAttributes(feat.attributes())
                    gm.setGeometry(QgsGeometryCollectionToMulti(parts))
                    sink_l.addFeature(gm, QgsFeatureSink.FastInsert); n_l += 1

        # Protokoll
        feedback.pushInfo('')
        feedback.pushInfo(f'Ergebnis: {summ["fehler"]} Fehler, {summ["hinweise"]} Hinweise '
                          f'({n_l} Linien, {n_p} Punkte)')
        for (sev, code), n in summ['by_code']:
            feedback.pushInfo(f'  {sev:<7} {code:<34} {n:5}')
        for sev, code, layer, msg in summ['notes']:
            feedback.pushInfo(f'  {sev:<7} {code:<34}       {msg}')
        if version != '3.1':
            feedback.pushInfo(f'Reserven-Abgleich: {summ["reserve_abschnitte"]} Abschnitte, '
                              f'{summ["reserve_abweichungen"]} Abweichung(en)')

        self._summary = summ
        return {self.OUT_L: dest_l, self.OUT_P: dest_p}

    # ── Banner ───────────────────────────────────────────────────────────────

    @staticmethod
    def banner_text(summ):
        title = f'GIS-NB Check: {summ["fehler"]} Fehler, {summ["hinweise"]} Hinweise'
        top = [f'{code} ({n})' for (sev, code), n in summ['by_code'] if sev == FEHLER][:5]
        text = 'Haeufigste Fehler: ' + (', '.join(top) if top else 'keine')
        if summ['reserve_abschnitte']:
            text += f'  |  Reserven-Abgleich: {summ["reserve_abweichungen"]} von {summ["reserve_abschnitte"]} Abschnitten abweichend'
        if summ['notes']:
            text += f'  |  {len(summ["notes"])} Layer-Hinweis(e) im Protokoll'
        return title, text

    def postProcessAlgorithm(self, context, feedback):
        summ = getattr(self, '_summary', None)
        if summ is None:
            return {}
        try:
            from qgis.utils import iface
            from qgis.core import Qgis
        except ImportError:
            return {}
        if iface is None:
            return {}
        title, text = self.banner_text(summ)
        level = Qgis.Warning if summ['fehler'] else Qgis.Success
        iface.messageBar().pushMessage(title, text, level=level, duration=0)
        return {}


def QgsGeometryCollectionToMulti(parts):
    """Liste von Linien-Geometrien zu einer MultiLineString-Geometrie."""
    from qgis.core import QgsGeometry
    return QgsGeometry.collectGeometry(parts)

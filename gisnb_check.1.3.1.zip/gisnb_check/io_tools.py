# -*- coding: utf-8 -*-
"""
Import und Export der GIS-NB Netzplan-Layer (ohne GUI, headless testbar).

Import: alle Quelldateien eines Ordners (Megaplan-Export) laden, nach Dateinamen
der Rolle zuordnen, den CCGIS-Style der gewaehlten GIS-NB-Version anwenden
(Styles liegen im Plugin unter styles/<Version>/), Layer in
"<Vertragsnummer>_<Layername>" umbenennen und in einer Gruppe <Vertragsnummer>
ablegen. Optional ein Hinweiselayer mit eigenem Style.

Export (Abgabe): GeoJSON in EPSG:4258, Mitverlegung als Shapefile, ohne fid-Feld;
die exportierten Layer kommen ohne Style in die Untergruppe "Abgabe". Arbeitslayer
wie der Fortschritt-Layer werden nicht exportiert. Dazu die Gesamtlaenge
des Netzes: Leerrohre und Verbindungen zusammen dissolved.
"""
import os
import re

from qgis.core import (
    QgsCoordinateReferenceSystem, QgsCoordinateTransform, QgsDataProvider, QgsDistanceArea,
    QgsGeometry, QgsLayerTreeGroup, QgsProject, QgsVectorFileWriter, QgsVectorLayer,
)
from qgis.PyQt.QtCore import QCoreApplication, QEvent

STYLE_DIR      = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'styles')
HINWEIS_STYLE  = os.path.join(STYLE_DIR, 'Hinweiselayer', 'Hinweise an CC GIS oder Firma.qml')
HINWEIS_NAME   = 'Hinweise an CC GIS oder Firma'
ABGABE_GROUP   = 'Abgabe'
ABGABE_CRS     = 'EPSG:4258'
QUELL_ENDUNGEN = ('.gpkg', '.shp', '.geojson', '.json')
NICHT_ABGEBEN  = ('fortschritt',)      # Arbeitslayer, nie Teil der Abgabe

# Rollen aus Datei- bzw. Style-Namen (lowercase, erste Uebereinstimmung gewinnt).
# "netztechnik_bauten" und "Bauten und Netztechnik" sind Netztechnik, nicht Bauten.
_ROLLEN = [
    ('hw', ('hinweis',)),
    ('nt', ('netztechnik',)),
    ('ba', ('bauten',)),
    ('mv', ('mitverleg',)),
    ('vb', ('verbindung',)),
    ('lr', ('leerrohr',)),
    ('tr', ('trassenbau',)),
    ('ev', ('endverbraucher',)),
    ('vg', ('versorgungsgebiet',)),
]

# Reihenfolge in der Layergruppe (oben -> unten)
ROLLEN_REIHENFOLGE = ['hw', 'ev', 'nt', 'ba', 'mv', 'vb', 'lr', 'tr', 'vg']


def rolle(name):
    n = name.lower()
    for key, kws in _ROLLEN:
        if any(k in n for k in kws):
            return key
    return None


def vertragsnummer_aus_pfad(path):
    """MBfD-Vertragsnummer (5-12 Ziffern) aus dem tiefsten Pfadteil, der eine enthaelt."""
    teile = re.split(r'[\\/]+', os.path.normpath(path))
    for teil in reversed(teile):
        m = re.search(r'(?<!\d)(\d{5,12})(?!\d)', teil)
        if m:
            return m.group(1)
    return None


def style_versionen():
    """GIS-NB-Versionen, fuer die das Plugin Styles mitbringt (z.B. ['3.1', '4.0', '4.1', '5.0'])."""
    if not os.path.isdir(STYLE_DIR):
        return []
    out = [d for d in os.listdir(STYLE_DIR)
           if re.fullmatch(r'\d+\.\d+\w*', d) and any(f.endswith('.qml') for f in os.listdir(os.path.join(STYLE_DIR, d)))]
    return sorted(out, key=lambda v: [int(x) if x.isdigit() else x for x in re.findall(r'\d+|\D+', v)])


def version_aus_namen(*namen):
    """'4.1' aus z.B. 'MP-Export_1307100071_v 4.1' oder 'leerrohre_megaplan_v4.1'."""
    for name in namen:
        m = re.search(r'v\s*(\d+)[._](\d+)', name or '', re.I)
        if m:
            return f'{m.group(1)}.{m.group(2)}'
    return None


def styles(version):
    """{rolle: qml-Pfad} fuer eine Version."""
    d = os.path.join(STYLE_DIR, version)
    out = {}
    if os.path.isdir(d):
        for f in sorted(os.listdir(d)):
            if f.lower().endswith('.qml'):
                r = rolle(f)
                if r is not None:
                    out.setdefault(r, os.path.join(d, f))
    return out


def layer_name(vnr, basis):
    """'trassenbau_megaplan_v4.1' -> '<vnr>_Trassenbau_megaplan_v4.1' (Vertragsnummer nicht doppelt)."""
    if vnr and basis.startswith(f'{vnr}_'):
        basis = basis[len(vnr) + 1:]
    basis = basis[:1].upper() + basis[1:]
    return f'{vnr}_{basis}' if vnr else basis


def quell_dateien(ordner):
    """Liste (Pfad, Basisname) aller Vektordateien im Ordner (nicht rekursiv), ohne Hinweiselayer."""
    out = []
    for f in sorted(os.listdir(ordner)):
        p = os.path.join(ordner, f)
        stem, ext = os.path.splitext(f)
        if os.path.isfile(p) and ext.lower() in QUELL_ENDUNGEN:
            out.append((p, stem))
    return out


def hinweis_vorschlag(ordner):
    """Hinweiselayer im Quellordner oder dessen Elternordner (z.B. 'Hinweise an CC GIS oder Firma.gpkg')."""
    for d in (ordner, os.path.dirname(ordner)):
        if not os.path.isdir(d):
            continue
        for f in sorted(os.listdir(d)):
            if rolle(f) == 'hw' and os.path.splitext(f)[1].lower() in QUELL_ENDUNGEN:
                return os.path.join(d, f)
    return None


def _lade(pfad, basis):
    """Vektorlayer laden; bei GeoPackages mit mehreren Layern jeden einzeln (Basis = Layername)."""
    lyr = QgsVectorLayer(pfad, basis, 'ogr')
    if not lyr.isValid():
        return []
    subs = lyr.dataProvider().subLayers()
    if pfad.lower().endswith('.gpkg') and len(subs) > 1:
        out = []
        sep = QgsDataProvider.sublayerSeparator()
        for s in subs:
            name = s.split(sep)[1]
            sub = QgsVectorLayer(f'{pfad}|layername={name}', name, 'ogr')
            if sub.isValid():
                out.append((sub, name))
        return out
    return [(lyr, basis)]


def stil_anwenden(layer, qml):
    if qml and os.path.exists(qml):
        _, ok = layer.loadNamedStyle(qml)
        return bool(ok)
    return False


def gruppe(project, name):
    root = project.layerTreeRoot()
    g = root.findGroup(name)
    if g is None:
        g = root.insertGroup(0, name)
    return g


def importieren(ordner, vnr, version, hinweis=None, project=None):
    """Quelldateien laden, stylen, umbenennen und in der Gruppe <vnr> ablegen.

    Rueckgabe: (Gruppe, [(Layer, Rolle, Style-Pfad oder None)], [Meldungen]).
    Layer, deren Name in der Gruppe schon existiert, werden uebersprungen.
    """
    project = project or QgsProject.instance()
    st = styles(version)
    geladen, meldungen = [], []
    quellen = [(p, b) for p, b in quell_dateien(ordner) if rolle(b) != 'hw']
    if hinweis:
        quellen.append((hinweis, HINWEIS_NAME))
    for pfad, basis in quellen:
        layers = _lade(pfad, basis)
        if not layers:
            meldungen.append(f'{os.path.basename(pfad)}: konnte nicht geladen werden.')
        for lyr, name in layers:
            r = 'hw' if pfad == hinweis else rolle(name)
            qml = HINWEIS_STYLE if r == 'hw' else st.get(r)
            lyr.setName(layer_name(vnr, HINWEIS_NAME if r == 'hw' else name))
            if qml:
                stil_anwenden(lyr, qml)
            else:
                meldungen.append(f'{os.path.basename(pfad)}: kein Style fuer GIS-NB {version} gefunden.')
            geladen.append((lyr, r, qml))

    g = gruppe(project, vnr)
    vorhanden = {n.name() for n in g.findLayers()}
    rang = {r: i for i, r in enumerate(ROLLEN_REIHENFOLGE)}
    geladen.sort(key=lambda t: rang.get(t[1], len(rang)))
    neu = []
    for lyr, r, qml in geladen:
        if lyr.name() in vorhanden:
            meldungen.append(f'{lyr.name()}: in der Gruppe schon vorhanden, uebersprungen.')
            continue
        project.addMapLayer(lyr, False)
        g.addLayer(lyr)
        neu.append((lyr, r, qml))
    return g, neu, meldungen


# ── Export ───────────────────────────────────────────────────────────────────

def abgabe_dateiname(layer, rolle_):
    return layer.name() + ('.shp' if rolle_ == 'mv' else '.geojson')


def exportieren(layers, ordner, vnr, project=None):
    """Layer als Abgabe schreiben (GeoJSON, Mitverlegung als Shapefile; EPSG:4258, ohne fid)
    und ohne Style in die Untergruppe "Abgabe" der Gruppe <vnr> laden.

    Eine fruehere Abgabe-Gruppe wird vorher entfernt, damit die Dateien nicht gesperrt sind.
    Rueckgabe: ([neue Layer], [Fehlermeldungen]).
    """
    project = project or QgsProject.instance()
    ziel_crs = QgsCoordinateReferenceSystem(ABGABE_CRS)
    g = gruppe(project, vnr)
    alt = g.findGroup(ABGABE_GROUP)
    if alt is not None:
        project.removeMapLayers([n.layerId() for n in alt.findLayers()])
        g.removeChildNode(alt)
        # Layer werden verzoegert geloescht und halten bis dahin die Dateien offen (Windows-Sperre)
        QCoreApplication.sendPostedEvents(None, QEvent.DeferredDelete)

    os.makedirs(ordner, exist_ok=True)
    geschrieben, fehler = [], []
    for layer in layers:
        r = rolle(layer.name())
        pfad = os.path.join(ordner, abgabe_dateiname(layer, r))
        opts = QgsVectorFileWriter.SaveVectorOptions()
        opts.driverName = 'ESRI Shapefile' if r == 'mv' else 'GeoJSON'
        opts.fileEncoding = 'UTF-8'
        opts.ct = QgsCoordinateTransform(layer.crs(), ziel_crs, project.transformContext())
        opts.attributes = [i for i, f in enumerate(layer.fields()) if f.name().lower() != 'fid']
        if r == 'mv':
            opts.saveMetadata = True
            opts.layerMetadata = layer.metadata()
        res = QgsVectorFileWriter.writeAsVectorFormatV3(layer, pfad, project.transformContext(), opts)
        if res[0] != QgsVectorFileWriter.NoError:
            fehler.append(f'{layer.name()}: {res[1]}')
            continue
        neu = QgsVectorLayer(pfad, layer.name(), 'ogr')
        if not neu.isValid():
            fehler.append(f'{layer.name()}: exportiert, aber nicht ladbar ({pfad}).')
            continue
        geschrieben.append(neu)

    if geschrieben:
        ag = g.insertGroup(0, ABGABE_GROUP)
        for lyr in geschrieben:
            project.addMapLayer(lyr, False)
            ag.addLayer(lyr)
    return geschrieben, fehler


def gesamtlaenge(*layers):
    """Laenge in Metern: Leerrohre und Verbindungen dissolved, gemerged, dissolved.

    Dissolve von Linien = Vereinigung (unaryUnion) aller Geometrien; Strecken, auf
    denen Rohr und Kabel uebereinander liegen, zaehlen dadurch nur einmal.
    Gemessen ellipsoidisch (GRS80) in EPSG:4258.
    """
    crs = QgsCoordinateReferenceSystem(ABGABE_CRS)
    geoms = []
    for layer in layers:
        if layer is None:
            continue
        ct = QgsCoordinateTransform(layer.crs(), crs, QgsProject.instance().transformContext())
        teil = []
        for f in layer.getFeatures():
            g = f.geometry()
            if g is None or g.isNull() or g.isEmpty():
                continue
            g = QgsGeometry(g)
            if layer.crs() != crs:
                g.transform(ct)
            teil.append(g)
        if teil:
            geoms.append(QgsGeometry.unaryUnion(teil))        # dissolve je Layer
    if not geoms:
        return 0.0
    gesamt = QgsGeometry.unaryUnion(geoms)                   # merge + dissolve
    da = QgsDistanceArea()
    da.setSourceCrs(crs, QgsProject.instance().transformContext())
    da.setEllipsoid('GRS80')
    return float(da.measureLength(gesamt))


def abgabe_layer(group):
    """Layer der Projektgruppe, die zur Abgabe gehoeren (ohne Fortschritt-Layer o.ae.)."""
    return [lyr for lyr in projekt_layer(group) if not any(k in lyr.name().lower() for k in NICHT_ABGEBEN)]


def projekt_layer(group):
    """Direkte Layer einer Projektgruppe (ohne Untergruppen wie Abgabe oder Pruefergebnisse)."""
    if group is None:
        return []
    return [n.layer() for n in group.children()
            if not isinstance(n, QgsLayerTreeGroup) and hasattr(n, 'layer') and isinstance(n.layer(), QgsVectorLayer)]

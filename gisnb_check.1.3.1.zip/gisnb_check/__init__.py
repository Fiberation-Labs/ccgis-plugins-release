# -*- coding: utf-8 -*-


def classFactory(iface):
    from .plugin import GisNbCheckPlugin
    return GisNbCheckPlugin(iface)

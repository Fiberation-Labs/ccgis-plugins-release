<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis hasScaleBasedVisibilityFlag="0" labelsEnabled="1" simplifyDrawingTol="1" simplifyMaxScale="1" styleCategories="AllStyleCategories" simplifyAlgorithm="0" maxScale="0" simplifyDrawingHints="1" simplifyLocal="1" version="3.22.16-Białowieża" readOnly="0" minScale="100000000" symbologyReferenceScale="-1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal startField="" durationUnit="min" mode="0" enabled="0" startExpression="" endExpression="" endField="" accumulate="0" durationField="" fixedDuration="0" limitMode="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <renderer-v2 forceraster="0" type="RuleRenderer" referencescale="-1" enableorderby="0" symbollevels="1">
    <rules key="{328a3896-5baf-49ed-bd2d-852bef429599}">
      <rule key="{97f38250-127d-4224-8f83-67df66f927a9}" label="Struktur">
        <rule key="{90d3d8a4-d612-45e5-a9dc-8d1b79953e90}" filter="&quot;VERB_ART&quot; = 2 OR &quot;VERB_ART&quot; = 99" label="Gf-Kabel">
          <rule key="{7acc9bd1-5c09-425c-9810-c114d4fd56dd}" filter=" &quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )" label="Gf-Kabel u.i.">
            <rule key="{aae4b628-a799-4a65-a494-5427a0839956}" symbol="0" filter="&quot;ZUSTAND&quot; = 2" label="Gf-Kabel u.i. neu"/>
            <rule key="{54990205-e4fb-45c8-946b-041af9d10862}" symbol="1" filter="&quot;ZUSTAND&quot; = 1" label="Gf-Kabel u.i. Bestand"/>
          </rule>
          <rule key="{0167fd80-2075-4147-90dd-f8904f2199d9}" filter="&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%'" label="Gf-Kabel o.i.">
            <rule key="{9e2f560e-aea2-4b69-ab03-288f9e19b7b3}" symbol="2" filter="&quot;ZUSTAND&quot; = 2" label="Gf-Kabel o.i. neu"/>
            <rule key="{b8e7a4ad-1e25-43de-aac6-d471408ce69b}" symbol="3" filter="&quot;ZUSTAND&quot; = 1" label="Gf-Kabel o.i. Bestand"/>
          </rule>
        </rule>
        <rule key="{9d89bde2-3da6-475b-808f-4b86304e38a7}" filter="&quot;VERB_ART&quot; = 1" label="Cu-Kabel">
          <rule key="{e70a2411-8a0b-4802-9d74-2b158b49f2b5}" filter=" &quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )" label="Cu-Kabel u.i.">
            <rule key="{653eb6ca-2721-4f5e-a489-2d6d834430db}" symbol="4" filter="&quot;ZUSTAND&quot; = 2" label="Cu-Kabel u.i. in neu"/>
            <rule key="{fc69f629-8a6e-4dfc-a37a-c2b5d68b752e}" symbol="5" filter="&quot;ZUSTAND&quot; = 1" label="Cu-Kabel u.i. in Bestand"/>
          </rule>
          <rule key="{fcde73aa-f14b-4d26-ab55-81401002b96d}" filter="&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%'" label="Cu-Kabel o.i.">
            <rule key="{4224a82e-5c80-4354-a999-cc0a8d7962b3}" symbol="6" filter="&quot;ZUSTAND&quot; = 2" label="Cu-Kabel o.i. neu"/>
            <rule key="{3b4522ed-4471-414b-a3cd-26d373604330}" symbol="7" filter="&quot;ZUSTAND&quot; = 1" label="Cu-Kabel o.i. Bestand"/>
          </rule>
        </rule>
        <rule key="{eb2925b4-cce7-4914-9172-c56cf21c81a3}" filter="&quot;VERB_ART&quot; = 99 AND (&quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )" label="FSP-Kabel">
          <rule key="{5fe9aa6e-3501-4000-bc0d-1fa2f6c08a22}" symbol="8" filter="&quot;ZUSTAND&quot; = 2 " label="FSP-Kabel in neu"/>
          <rule key="{336b2347-356b-4793-95e4-2d2d459a06e4}" symbol="9" filter="&quot;ZUSTAND&quot; = 1" label="FSP-Kabel in Bestand"/>
        </rule>
      </rule>
      <rule checkstate="0" key="{57b75004-b607-49ae-9957-c59ffcee56da}" symbol="10" label="alle Kabel"/>
      <rule checkstate="0" key="{9cc29061-a230-444c-a4ee-57e24173ce04}" label="Prüfung">
        <rule checkstate="0" key="{4b5eedb8-78e5-41ae-8fdf-bf788a13c3f7}" symbol="11" filter=" &quot;VERB_ART&quot; NOT IN (1,2,99)" label="Verb_Art unplausibel"/>
        <rule checkstate="0" key="{4b44de46-0851-49a9-a5ed-40534f747fa0}" symbol="12" filter="&quot;ID_START&quot; IS NULL OR &quot;ID_ENDE&quot; IS NULL" label="ID_Start oder ID_Ende fehlt"/>
        <rule checkstate="0" key="{87f65930-6933-465f-ac23-73d2bc40a419}" symbol="13" filter="((&quot;Verb_Art&quot; = 2 AND &quot;Anzahl_F_A&quot; NOT IN (2,4,6,8,12,16,24,36,48,60,72,96,132,144,192))) OR ((&quot;Verb_Art&quot; != 2 AND &quot;Anzahl_F_A&quot; &#xa;IN (2,4,6,8,12,16,24,36,48,60,72,96,132,144,192))) AND NOT ((&quot;Verb_Art&quot; = 99 AND &quot;Anzahl_F_A&quot; IN (4,6,8,12,16,24,36,48,72)))" label="Gf: Anzahl_F_A entspricht nicht Verb_ Art"/>
        <rule checkstate="0" key="{6857152c-3626-40f4-988f-8c3e1c6238d3}" symbol="14" filter="((&quot;Verb_Art&quot; = 1 AND &quot;Anzahl_F_A&quot; NOT IN (2,10,20,30,40,50,70,100,150,200,250,300,500,1000))) OR ((&quot;Verb_Art&quot; != 1 AND &quot;Anzahl_F_A&quot; IN (2,10,20,30,40,50,70,100,150,200,250,300,500,1000))) AND NOT (&quot;VERB_ART&quot; = 99 AND (&quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%'))" label="Cu: Anzahl_F_A entspricht nicht Verb_ Art"/>
        <rule checkstate="0" key="{c483b12b-5880-42db-bd49-584f377057a7}" symbol="15" filter=" &quot;F_A_RESERV&quot; >= &quot;ANZAHL_F_A&quot; " label="F_A_Reserve größer od. gleich ANZAHL_F_A"/>
        <rule checkstate="0" key="{64a0c88f-3fb5-4dee-b132-3fec99e71fb2}" symbol="16" filter=" &quot;F_A_RESERV&quot; &lt; 0" label="F_A_Reserve kleiner 0"/>
        <rule checkstate="0" key="{fec8a9eb-0ed4-4e5c-96ac-9fb0f789f935}" symbol="17" filter=" &quot;ZUSTAND&quot; = 1 AND  &quot;F_A_RESERV&quot;  != 0" label="F_A_Reserve bei Bestand nicht '0'"/>
        <rule checkstate="0" key="{09f2e5f0-19dc-42d5-a49f-3b17bb01d01b}" symbol="18" filter=" &quot;VERB_ART&quot; = 2 AND &quot;ZUSTAND&quot; = 2 AND  &quot;F_A_RESERV&quot; = 0" label="Wirklich F_A_Reserve bei neu = '0'?"/>
        <rule checkstate="0" key="{d835dd05-90e6-4fd5-bb95-2fba139f99be}" symbol="19" filter="&quot;ID_LR&quot; IS NULL AND  &quot;ID_Trassen&quot; IS NULL AND &quot;VERB_ART&quot; = 2" label="Prüfen: Wirklich Gf-Kabel im Erdreich?"/>
        <rule checkstate="0" key="{143186c3-c5dd-4b4a-9e59-64dc935b5b5d}" symbol="20" filter=" &quot;VERB_ART&quot; IS NULL OR &quot;ANZAHL_VER&quot; IS NULL OR &quot;LAE_KABEL&quot; IS NULL OR &quot;ANZAHL_F_A&quot; IS NULL OR &quot;LFD_M_F_A&quot; IS NULL OR &quot;F_A_RESERV&quot; IS NULL OR &quot;ZUSTAND&quot; IS NULL OR &quot;ID_START&quot; IS NULL OR &quot;ID_ENDE&quot; IS NULL OR &quot;E_FNAME&quot; IS NULL OR &quot;E_ORT&quot; IS NULL OR &quot;E_TEL&quot; IS NULL OR &quot;E_E_MAIL&quot; IS NULL OR &quot;A_VNAME&quot; IS NULL OR &quot;A_ZNAME&quot; IS NULL OR &quot;A_TEL&quot; IS NULL OR &quot;A_E_MAIL&quot; IS NULL" label="Fehlende Attribute"/>
      </rule>
      <rule checkstate="0" key="{64076f7e-8f3e-4540-97cf-9e14820bebe3}" label="MP-Fails">
        <rule key="{939b0e34-bcb3-40e5-a5b0-c713c6db8d61}" symbol="21" filter="&quot;ID_LR&quot; IS NULL  AND &quot;VERB_ART&quot; = 2" label="Prüfen: Wirklich Gf-Kabel im Erdreich?"/>
      </rule>
    </rules>
    <symbols>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="0" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="7" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="1"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="255,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="1"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="73,190,253,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="73,190,253,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="0.146"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="0.146"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.386"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="253,253,253,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.386"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="253,253,253,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="7" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="73,190,253,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="73,190,253,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="1" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="6" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="0,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="0,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="6" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="73,190,253,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="73,190,253,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="10" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="12" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="12" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="11" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="12" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="12" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="12" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="12" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="12" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="13" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="12" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="12" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="14" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="12" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="12" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="15" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="12" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="12" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="16" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="12" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="12" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="17" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="12" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="12" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="18" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="12" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="12" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="19" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="12" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="12" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="2" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="11" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="1"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="255,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="1"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="73,190,253,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="73,190,253,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="0.146"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="0.146"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.386"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="253,253,253,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.386"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="253,253,253,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="11" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="150,28,150,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="150,28,150,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="20" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="12" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="12" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="21" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="7" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="0,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="1"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="0,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="1"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.527"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="4"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.527"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="4"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="0.146"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="0.146"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.386"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="253,253,253,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.386"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="253,253,253,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="7" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="73,190,253,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.72"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="73,190,253,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.72"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="3" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="10" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="0,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="1"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="0,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="1"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="239,0,4,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="239,0,4,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="0.146"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="0.146"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.386"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="253,253,253,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.386"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="253,253,253,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="10" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="236,82,239,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.504"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="236,82,239,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.504"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="4" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="5" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="255,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="239,0,4,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="239,0,4,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="5" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="5" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="4" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="0,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="0,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="4" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="6" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="9" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="1"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="255,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="1"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="0,239,39,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="0,239,39,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="0.146"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="0.146"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.386"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="253,253,253,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.386"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="253,253,253,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="9" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,239,39,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="0,239,39,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="7" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="8" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="0,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="1"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="0,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="1"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="239,0,4,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="239,0,4,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="0.146"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="0.146"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.386"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="253,253,253,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.386"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="253,253,253,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="8" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,239,39,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="0,239,39,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="8" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="3" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="255,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="239,0,4,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="239,0,4,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="3" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,238,27,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,238,27,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol force_rhr="0" type="line" clip_to_extent="1" name="9" alpha="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer class="SimpleLine" pass="2" enabled="1" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="0,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="0,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="239,0,4,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="239,0,4,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer class="SimpleLine" pass="2" enabled="1" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,238,27,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,238,27,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <labeling type="rule-based">
    <rules key="{1acdb5e2-acc4-4855-8172-6cd00b538a69}">
      <rule description="ohne Reserv." key="{2a1f12a8-1db7-44e2-bdad-20fe51948da6}" filter="1">
        <rule description="Gf-Kabel" key="{a338c0c0-79af-4c71-9b7e-8a873049d0f0}" scalemindenom="1" filter="&quot;VERB_ART&quot; = 2 OR &quot;VERB_ART&quot; = 99" scalemaxdenom="4000">
          <rule description="u.i." key="{0584a8c1-f7b1-46c3-aed0-3c5f7a589fc7}">
            <rule description="Bezeichnung ist vorhanden" key="{266dbff2-74af-41bd-aec9-a4d89a2b011b}" filter="(&quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )) AND NOT (&quot;bezeichnung&quot; IS NULL)">
              <rule description="Gf-Kabel u.i. Bestand" key="{468f37d9-eb87-422f-b997-5e3e06db6880}" filter="&quot;ZUSTAND&quot; = 1">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' ' ||&quot;ANZAHL_F_A&quot;  || ' FS ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="Point" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="152,125,183,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="152,125,183,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Gf-Kabel u.i. neu" key="{b10b4663-afec-4bfe-8cb7-2357484917cb}" filter="&quot;ZUSTAND&quot; = 2">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="0,0,0,255" fieldName="' ' ||&quot;ANZAHL_F_A&quot;  || ' FS ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="Pixel" shapeFillColor="255,206,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="190,207,80,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="190,207,80,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="255,206,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="255,206,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option type="Map" name="properties">
                        <Option type="Map" name="ShapeSizeX">
                          <Option type="bool" name="active" value="false"/>
                          <Option type="QString" name="expression" value=""/>
                          <Option type="Map" name="transformer">
                            <Option type="Map" name="d">
                              <Option type="double" name="exponent" value="1"/>
                              <Option type="double" name="maxOutput" value="10"/>
                              <Option type="double" name="maxValue" value="0"/>
                              <Option type="double" name="minOutput" value="1"/>
                              <Option type="double" name="minValue" value="0"/>
                              <Option type="double" name="nullOutput" value="0"/>
                            </Option>
                            <Option type="int" name="t" value="0"/>
                          </Option>
                          <Option type="int" name="type" value="3"/>
                        </Option>
                      </Option>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
            <rule description="Bezeichnung ist NULL" key="{3da60a53-6f37-47e9-8228-8c2190ae3dac}" filter="(&quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )) AND (&quot;bezeichnung&quot; IS NULL)">
              <rule description="Gf-Kabel u.i. Bestand" key="{f3883ba8-5962-4852-af93-dc94a17402da}" filter="&quot;ZUSTAND&quot; = 1">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' ' ||&quot;ANZAHL_F_A&quot;  || ' FS '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="Point" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="152,125,183,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="152,125,183,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Gf-Kabel u.i. neu" key="{6f4154ad-4b0d-487c-abdf-99b89ffc6aa3}" filter="&quot;ZUSTAND&quot; = 2">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="0,0,0,255" fieldName="' ' ||&quot;ANZAHL_F_A&quot;  || ' FS '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="Pixel" shapeFillColor="255,206,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="190,207,80,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="190,207,80,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="255,206,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="255,206,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option type="Map" name="properties">
                        <Option type="Map" name="ShapeSizeX">
                          <Option type="bool" name="active" value="false"/>
                          <Option type="QString" name="expression" value=""/>
                          <Option type="Map" name="transformer">
                            <Option type="Map" name="d">
                              <Option type="double" name="exponent" value="1"/>
                              <Option type="double" name="maxOutput" value="10"/>
                              <Option type="double" name="maxValue" value="0"/>
                              <Option type="double" name="minOutput" value="1"/>
                              <Option type="double" name="minValue" value="0"/>
                              <Option type="double" name="nullOutput" value="0"/>
                            </Option>
                            <Option type="int" name="t" value="0"/>
                          </Option>
                          <Option type="int" name="type" value="3"/>
                        </Option>
                      </Option>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
          </rule>
          <rule description="o.i." key="{dcf37d6e-5a0f-4ff1-965a-9dcd2e35d0f9}">
            <rule description="Bezeichnung ist vorhanden" key="{87242c6c-1033-42f0-bc22-629f18da8355}" filter="(&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%') AND NOT (&quot;bezeichnung&quot; IS NULL)">
              <rule description="Gf-Kabel o.i. neu" key="{91738723-8ccb-46f4-a305-394467611638}" filter="&quot;ZUSTAND&quot; = 2">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="0,0,0,255" fieldName="' o.i. ' || &quot;ANZAHL_F_A&quot;  || ' FS ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="255,206,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="225,89,137,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="225,89,137,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="255,206,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="255,206,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Gf-Kabel o.i. Bestand" key="{599a2ce3-ad59-41a8-9c9b-0e0f743723c3}" filter="&quot;ZUSTAND&quot; = 1">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' o.i. ' || &quot;ANZAHL_F_A&quot;  || ' FS ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="183,72,75,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="183,72,75,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
            <rule description="Bezeichnung ist NULL" key="{34373825-f2dc-4be8-a9b9-b9e800158868}" filter="(&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%') AND (&quot;bezeichnung&quot; IS NULL)">
              <rule description="Gf-Kabel o.i. neu" key="{ec7bc3f7-9d32-4a0d-98d9-87590fe0fa76}" filter="&quot;ZUSTAND&quot; = 2">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="0,0,0,255" fieldName="' o.i. ' || &quot;ANZAHL_F_A&quot;  || ' FS '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="255,206,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="225,89,137,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="225,89,137,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="255,206,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="255,206,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Gf-Kabel o.i. Bestand" key="{17ff526a-e71a-4cee-9fdd-adff0ba14340}" filter="&quot;ZUSTAND&quot; = 1">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' o.i. ' || &quot;ANZAHL_F_A&quot;  || ' FS '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="183,72,75,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="183,72,75,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
          </rule>
        </rule>
        <rule description="Cu-Kabel" key="{199f1520-e393-4541-a9b8-8be034454fb8}" scalemindenom="1" filter="&quot;VERB_ART&quot; = 1" scalemaxdenom="4000">
          <rule description="u.i." key="{101ff792-d021-4f48-ba6f-d1d7fb6808bd}">
            <rule description="Bezeichnung ist vorhanden" key="{7806cd78-a6ef-428f-b5ee-b97a4a46d563}" filter="(&quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )) AND NOT (&quot;bezeichnung&quot; IS NULL)">
              <rule description="Cu-Kabel u.i. in neu" key="{7dd7dc0b-5c33-4660-873f-905bffec99e9}" filter="&quot;ZUSTAND&quot; = 2">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' '||&quot;ANZAHL_F_A&quot;  || ' DA ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="194,50,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="255,158,23,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="255,158,23,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="194,50,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="194,50,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Cu-Kabel u.i. in Bestand" key="{c2c13b11-8e08-49c3-ba28-83eddf6b2e88}" filter="&quot;ZUSTAND&quot; = 1">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' '||&quot;ANZAHL_F_A&quot;  || ' DA ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="141,90,153,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="141,90,153,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
            <rule description="Bezeichnung ist NULL" key="{53ee8550-0731-4611-9d8f-f5ccbd848586}" filter="(&quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )) AND (&quot;bezeichnung&quot; IS NULL)">
              <rule description="Cu-Kabel u.i. in neu" key="{63e970f0-490f-404d-9832-d70b063833dc}" filter="&quot;ZUSTAND&quot; = 2">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' '||&quot;ANZAHL_F_A&quot;  || ' DA '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="194,50,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="255,158,23,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="255,158,23,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="194,50,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="194,50,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Cu-Kabel u.i. in Bestand" key="{128badc0-35e5-4fd7-be64-59d6cc718c19}" filter="&quot;ZUSTAND&quot; = 1">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' '||&quot;ANZAHL_F_A&quot;  || ' DA '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="141,90,153,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="141,90,153,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
          </rule>
          <rule description="o.i." key="{d32f5420-f3fb-4157-bba3-07484759c2a1}">
            <rule description="Bezeichnung ist vorhanden" key="{6ce67f05-af13-41b1-b249-5af4ecaf81a5}" filter="(&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%') AND NOT (&quot;bezeichnung&quot; IS NULL)">
              <rule description="Cu-Kabel o.i. neu" key="{e50b77b0-8d91-431a-b4cf-d4902220615c}" filter="&quot;ZUSTAND&quot; = 2">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="194,50,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="243,166,178,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="243,166,178,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="194,50,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="194,50,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Cu-Kabel o.i. Bestand" key="{1900f3c3-a6bc-427d-ab04-cc7c56f2de37}" filter="&quot;ZUSTAND&quot; = 1">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' o.i. '  || &quot;ANZAHL_F_A&quot;  || ' DA ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="213,180,60,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="213,180,60,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
            <rule description="Bezeichnung ist NULL" key="{50911560-9559-4b50-a477-0db3c93ade3f}" filter="(&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%') AND (&quot;bezeichnung&quot; IS NULL)">
              <rule description="Cu-Kabel o.i. neu" key="{012eec97-fa8d-4c44-95ce-d62609464906}" filter="&quot;ZUSTAND&quot; = 2">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="194,50,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="243,166,178,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="243,166,178,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="194,50,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="194,50,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Cu-Kabel o.i. Bestand" key="{19b51bb2-a609-4a8d-8a9f-4933766d5eb0}" filter="&quot;ZUSTAND&quot; = 1">
                <settings calloutType="simple">
                  <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' o.i. '  || &quot;ANZAHL_F_A&quot;  || ' DA '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                    <families/>
                    <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                    <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                    <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                      <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="213,180,60,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="213,180,60,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                  <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                  <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
          </rule>
        </rule>
        <rule description="FSP-Kabel" key="{e8836ece-b7e2-4bf4-a28d-dab01c9822d0}" scalemindenom="1" filter="&quot;VERB_ART&quot; = 99 AND (&quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )" scalemaxdenom="4000">
          <rule description="FSP-Kabel in neu" key="{fdb91e9d-c0de-4318-a81a-e1f22951dcbe}" filter="&quot;ZUSTAND&quot; = 2">
            <settings calloutType="simple">
              <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' FSP '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                <families/>
                <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="194,50,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                  <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="angle" value="0"/>
                        <Option type="QString" name="cap_style" value="square"/>
                        <Option type="QString" name="color" value="125,139,143,255"/>
                        <Option type="QString" name="horizontal_anchor_point" value="1"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="name" value="circle"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="35,35,35,255"/>
                        <Option type="QString" name="outline_style" value="solid"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="scale_method" value="diameter"/>
                        <Option type="QString" name="size" value="2"/>
                        <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="size_unit" value="MM"/>
                        <Option type="QString" name="vertical_anchor_point" value="1"/>
                      </Option>
                      <prop k="angle" v="0"/>
                      <prop k="cap_style" v="square"/>
                      <prop k="color" v="125,139,143,255"/>
                      <prop k="horizontal_anchor_point" v="1"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="name" v="circle"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="35,35,35,255"/>
                      <prop k="outline_style" v="solid"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="scale_method" v="diameter"/>
                      <prop k="size" v="2"/>
                      <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="size_unit" v="MM"/>
                      <prop k="vertical_anchor_point" v="1"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                  <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="color" value="194,50,255,255"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="128,128,128,255"/>
                        <Option type="QString" name="outline_style" value="no"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="style" value="solid"/>
                      </Option>
                      <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="color" v="194,50,255,255"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="128,128,128,255"/>
                      <prop k="outline_style" v="no"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="style" v="solid"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                </background>
                <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <substitutions/>
              </text-style>
              <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
              <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
              <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
              <dd_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option name="properties"/>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </dd_properties>
              <callout type="simple">
                <Option type="Map">
                  <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                  <Option type="int" name="blendMode" value="0"/>
                  <Option type="Map" name="ddProperties">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                  <Option type="bool" name="drawToAllParts" value="false"/>
                  <Option type="QString" name="enabled" value="0"/>
                  <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                  <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                  <Option type="double" name="minLength" value="0"/>
                  <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="minLengthUnit" value="MM"/>
                  <Option type="double" name="offsetFromAnchor" value="0"/>
                  <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                  <Option type="double" name="offsetFromLabel" value="0"/>
                  <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                </Option>
              </callout>
            </settings>
          </rule>
          <rule description="FSP-Kabel in Bestand" key="{b7fbc80d-c60b-4505-a5b5-ccf4e0e0a233}" filter="&quot;ZUSTAND&quot; = 1">
            <settings calloutType="simple">
              <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' FSP '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                <families/>
                <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                  <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="angle" value="0"/>
                        <Option type="QString" name="cap_style" value="square"/>
                        <Option type="QString" name="color" value="133,182,111,255"/>
                        <Option type="QString" name="horizontal_anchor_point" value="1"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="name" value="circle"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="35,35,35,255"/>
                        <Option type="QString" name="outline_style" value="solid"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="scale_method" value="diameter"/>
                        <Option type="QString" name="size" value="2"/>
                        <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="size_unit" value="MM"/>
                        <Option type="QString" name="vertical_anchor_point" value="1"/>
                      </Option>
                      <prop k="angle" v="0"/>
                      <prop k="cap_style" v="square"/>
                      <prop k="color" v="133,182,111,255"/>
                      <prop k="horizontal_anchor_point" v="1"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="name" v="circle"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="35,35,35,255"/>
                      <prop k="outline_style" v="solid"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="scale_method" v="diameter"/>
                      <prop k="size" v="2"/>
                      <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="size_unit" v="MM"/>
                      <prop k="vertical_anchor_point" v="1"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                  <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="color" value="0,0,0,255"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="128,128,128,255"/>
                        <Option type="QString" name="outline_style" value="no"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="style" value="solid"/>
                      </Option>
                      <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="color" v="0,0,0,255"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="128,128,128,255"/>
                      <prop k="outline_style" v="no"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="style" v="solid"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                </background>
                <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <substitutions/>
              </text-style>
              <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
              <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
              <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
              <dd_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option name="properties"/>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </dd_properties>
              <callout type="simple">
                <Option type="Map">
                  <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                  <Option type="int" name="blendMode" value="0"/>
                  <Option type="Map" name="ddProperties">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                  <Option type="bool" name="drawToAllParts" value="false"/>
                  <Option type="QString" name="enabled" value="0"/>
                  <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                  <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                  <Option type="double" name="minLength" value="0"/>
                  <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="minLengthUnit" value="MM"/>
                  <Option type="double" name="offsetFromAnchor" value="0"/>
                  <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                  <Option type="double" name="offsetFromLabel" value="0"/>
                  <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                </Option>
              </callout>
            </settings>
          </rule>
        </rule>
      </rule>
      <rule description="mit Reserv." key="{f0ce14df-eff4-4534-94da-c6b9a3391856}" filter="0">
        <rule description="Gf-Kabel" key="{97e417a4-5062-45f0-a1cf-2ee85965cf43}" scalemindenom="1" filter="&quot;VERB_ART&quot; = 2 OR &quot;VERB_ART&quot; = 99" scalemaxdenom="4000">
          <rule description="Gf-Kabel u.i." key="{2d38ff2f-0885-42a6-81b8-a8336974d6e8}" filter=" &quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )">
            <rule description="Gf-Kabel u.i. neu" key="{d2e869eb-b956-4127-9a9e-240ec1f156fd}" filter="&quot;ZUSTAND&quot; = 2">
              <settings calloutType="simple">
                <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="0,0,0,255" fieldName="' ' ||&quot;ANZAHL_F_A&quot;  || ' FS l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                  <families/>
                  <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                  <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                  <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="Pixel" shapeFillColor="255,206,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                    <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="190,207,80,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="190,207,80,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="255,206,255,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="255,206,255,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option type="Map" name="properties">
                      <Option type="Map" name="ShapeSizeX">
                        <Option type="bool" name="active" value="false"/>
                        <Option type="QString" name="expression" value=""/>
                        <Option type="Map" name="transformer">
                          <Option type="Map" name="d">
                            <Option type="double" name="exponent" value="1"/>
                            <Option type="double" name="maxOutput" value="10"/>
                            <Option type="double" name="maxValue" value="0"/>
                            <Option type="double" name="minOutput" value="1"/>
                            <Option type="double" name="minValue" value="0"/>
                            <Option type="double" name="nullOutput" value="0"/>
                          </Option>
                          <Option type="int" name="t" value="0"/>
                        </Option>
                        <Option type="int" name="type" value="3"/>
                      </Option>
                    </Option>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
            <rule description="Gf-Kabel u.i. Bestand" key="{d5ea7a30-c14d-4a25-bc20-db95086f3643}" filter="&quot;ZUSTAND&quot; = 1">
              <settings calloutType="simple">
                <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' ' ||&quot;ANZAHL_F_A&quot;  || ' FS l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                  <families/>
                  <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                  <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                  <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="Point" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                    <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="152,125,183,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="152,125,183,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="0,0,0,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="0,0,0,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
          </rule>
          <rule description="Gf-Kabel o.i." key="{694408f2-0fcf-43ca-89b4-3dbe8567ea9f}" filter="&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%'">
            <rule description="Gf-Kabel o.i. neu" key="{c3f2e229-241c-4ebe-b35f-19bf1d01641a}" filter="&quot;ZUSTAND&quot; = 2">
              <settings calloutType="simple">
                <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="0,0,0,255" fieldName="' o.i. ' || &quot;ANZAHL_F_A&quot;  || ' FS l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                  <families/>
                  <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                  <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                  <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="255,206,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                    <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="225,89,137,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="225,89,137,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="255,206,255,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="255,206,255,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
            <rule description="Gf-Kabel o.i. Bestand" key="{42daba7e-e944-4743-af3c-c4f466ae3376}" filter="&quot;ZUSTAND&quot; = 1">
              <settings calloutType="simple">
                <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' o.i. ' || &quot;ANZAHL_F_A&quot;  || ' FS l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                  <families/>
                  <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                  <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                  <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                    <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="183,72,75,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="183,72,75,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="0,0,0,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="0,0,0,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
          </rule>
        </rule>
        <rule description="Cu-Kabel" key="{431dab84-5303-4082-841f-8290e868dcd8}" scalemindenom="1" filter="&quot;VERB_ART&quot; = 1" scalemaxdenom="4000">
          <rule description="Cu-Kabel u.i." key="{233eded4-1fb7-42e3-9986-03baced992f5}" filter=" &quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )">
            <rule description="Cu-Kabel u.i. in neu" key="{1ad75db6-6401-4923-9ca6-876265f69784}" filter="&quot;ZUSTAND&quot; = 2">
              <settings calloutType="simple">
                <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' '||&quot;ANZAHL_F_A&quot;  || ' DA l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                  <families/>
                  <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                  <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                  <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="194,50,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                    <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="255,158,23,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="255,158,23,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="194,50,255,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="194,50,255,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
            <rule description="Cu-Kabel u.i. in Bestand" key="{4f25f88e-d158-49b5-8931-b2a31c12e8ab}" filter="&quot;ZUSTAND&quot; = 1">
              <settings calloutType="simple">
                <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' '||&quot;ANZAHL_F_A&quot;  || ' DA l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                  <families/>
                  <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                  <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                  <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                    <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="141,90,153,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="141,90,153,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="0,0,0,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="0,0,0,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
          </rule>
          <rule description="Cu-Kabel o.i." key="{802e398b-e77e-4986-84f2-dd8171ef4967}" filter="&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%'">
            <rule description="Cu-Kabel o.i. neu" key="{1110aa46-fe49-443c-934a-dc979e5b756f}" filter="&quot;ZUSTAND&quot; = 2">
              <settings calloutType="simple">
                <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                  <families/>
                  <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                  <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                  <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="194,50,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                    <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="243,166,178,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="243,166,178,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="194,50,255,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="194,50,255,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
            <rule description="Cu-Kabel o.i. Bestand" key="{ef021ef0-0ee4-4271-8be9-dc7acebaaf54}" filter="&quot;ZUSTAND&quot; = 1">
              <settings calloutType="simple">
                <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' o.i. '  || &quot;ANZAHL_F_A&quot;  || ' DA l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                  <families/>
                  <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                  <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                  <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                    <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="213,180,60,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="213,180,60,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="0,0,0,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="0,0,0,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
                <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
                <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
          </rule>
        </rule>
        <rule description="FSP-Kabel" key="{08b02387-3b06-4f09-b071-5981df329592}" scalemindenom="1" filter="&quot;VERB_ART&quot; = 99 AND (&quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )" scalemaxdenom="4000">
          <rule description="FSP-Kabel in neu" key="{f008f7f5-6b6c-4613-a214-480b6bb0c675}" filter="&quot;ZUSTAND&quot; = 2">
            <settings calloutType="simple">
              <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' FSP '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                <families/>
                <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="194,50,255,255" shapeOpacity="1" shapeOffsetUnit="MM">
                  <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="angle" value="0"/>
                        <Option type="QString" name="cap_style" value="square"/>
                        <Option type="QString" name="color" value="125,139,143,255"/>
                        <Option type="QString" name="horizontal_anchor_point" value="1"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="name" value="circle"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="35,35,35,255"/>
                        <Option type="QString" name="outline_style" value="solid"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="scale_method" value="diameter"/>
                        <Option type="QString" name="size" value="2"/>
                        <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="size_unit" value="MM"/>
                        <Option type="QString" name="vertical_anchor_point" value="1"/>
                      </Option>
                      <prop k="angle" v="0"/>
                      <prop k="cap_style" v="square"/>
                      <prop k="color" v="125,139,143,255"/>
                      <prop k="horizontal_anchor_point" v="1"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="name" v="circle"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="35,35,35,255"/>
                      <prop k="outline_style" v="solid"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="scale_method" v="diameter"/>
                      <prop k="size" v="2"/>
                      <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="size_unit" v="MM"/>
                      <prop k="vertical_anchor_point" v="1"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                  <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="color" value="194,50,255,255"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="128,128,128,255"/>
                        <Option type="QString" name="outline_style" value="no"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="style" value="solid"/>
                      </Option>
                      <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="color" v="194,50,255,255"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="128,128,128,255"/>
                      <prop k="outline_style" v="no"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="style" v="solid"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                </background>
                <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <substitutions/>
              </text-style>
              <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
              <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="10" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
              <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
              <dd_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option name="properties"/>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </dd_properties>
              <callout type="simple">
                <Option type="Map">
                  <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                  <Option type="int" name="blendMode" value="0"/>
                  <Option type="Map" name="ddProperties">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                  <Option type="bool" name="drawToAllParts" value="false"/>
                  <Option type="QString" name="enabled" value="0"/>
                  <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                  <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                  <Option type="double" name="minLength" value="0"/>
                  <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="minLengthUnit" value="MM"/>
                  <Option type="double" name="offsetFromAnchor" value="0"/>
                  <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                  <Option type="double" name="offsetFromLabel" value="0"/>
                  <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                </Option>
              </callout>
            </settings>
          </rule>
          <rule description="FSP-Kabel in Bestand" key="{53e982bd-d80b-4062-8c9d-19d762578949}" filter="&quot;ZUSTAND&quot; = 1">
            <settings calloutType="simple">
              <text-style fontWordSpacing="0" fontLetterSpacing="0" fontWeight="50" fontSizeUnit="Point" fontSizeMapUnitScale="3x:0,0,0,0,0,0" namedStyle="Standard" blendMode="0" fontItalic="0" previewBkgrdColor="255,255,255,255" multilineHeight="1" allowHtml="0" fontSize="10" fontKerning="1" useSubstitutions="0" textColor="255,255,255,255" fieldName="' FSP '" textOpacity="1" fontUnderline="0" legendString="Aa" textOrientation="horizontal" isExpression="1" fontFamily="MS Shell Dlg 2" fontStrikeout="0" capitalization="0">
                <families/>
                <text-buffer bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferNoFill="1" bufferDraw="0" bufferJoinStyle="128" bufferBlendMode="0" bufferColor="255,255,255,255" bufferSizeUnits="MM"/>
                <text-mask maskEnabled="0" maskType="0" maskSizeUnits="MM" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSize="1.5" maskedSymbolLayers=""/>
                <background shapeSizeY="0" shapeBorderWidthUnit="MM" shapeRotationType="0" shapeBorderWidth="0" shapeRadiiX="0" shapeBlendMode="0" shapeType="0" shapeRotation="0" shapeSizeX="0" shapeOffsetX="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeBorderColor="128,128,128,255" shapeDraw="1" shapeSizeType="0" shapeOffsetY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiY="0" shapeSVGFile="" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeSizeUnit="MM" shapeFillColor="0,0,0,255" shapeOpacity="1" shapeOffsetUnit="MM">
                  <symbol force_rhr="0" type="marker" clip_to_extent="1" name="markerSymbol" alpha="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer class="SimpleMarker" pass="0" enabled="1" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="angle" value="0"/>
                        <Option type="QString" name="cap_style" value="square"/>
                        <Option type="QString" name="color" value="133,182,111,255"/>
                        <Option type="QString" name="horizontal_anchor_point" value="1"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="name" value="circle"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="35,35,35,255"/>
                        <Option type="QString" name="outline_style" value="solid"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="scale_method" value="diameter"/>
                        <Option type="QString" name="size" value="2"/>
                        <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="size_unit" value="MM"/>
                        <Option type="QString" name="vertical_anchor_point" value="1"/>
                      </Option>
                      <prop k="angle" v="0"/>
                      <prop k="cap_style" v="square"/>
                      <prop k="color" v="133,182,111,255"/>
                      <prop k="horizontal_anchor_point" v="1"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="name" v="circle"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="35,35,35,255"/>
                      <prop k="outline_style" v="solid"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="scale_method" v="diameter"/>
                      <prop k="size" v="2"/>
                      <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="size_unit" v="MM"/>
                      <prop k="vertical_anchor_point" v="1"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                  <symbol force_rhr="0" type="fill" clip_to_extent="1" name="fillSymbol" alpha="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer class="SimpleFill" pass="0" enabled="1" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="color" value="0,0,0,255"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="128,128,128,255"/>
                        <Option type="QString" name="outline_style" value="no"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="style" value="solid"/>
                      </Option>
                      <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="color" v="0,0,0,255"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="128,128,128,255"/>
                      <prop k="outline_style" v="no"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="style" v="solid"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                </background>
                <shadow shadowDraw="0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetGlobal="1" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowRadiusAlphaOnly="0" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowUnder="0" shadowOffsetDist="1" shadowBlendMode="6" shadowOffsetUnit="MM" shadowRadius="1.5"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <substitutions/>
              </text-style>
              <text-format autoWrapLength="0" leftDirectionSymbol="&lt;" plussign="0" rightDirectionSymbol=">" placeDirectionSymbol="0" multilineAlign="0" useMaxLineLengthForAutoWrap="1" wrapChar="" addDirectionSymbol="0" formatNumbers="0" decimals="3" reverseDirectionSymbol="0"/>
              <placement dist="5" centroidInside="0" distMapUnitScale="3x:0,0,0,0,0,0" offsetUnits="MM" lineAnchorType="0" maxCurvedCharAngleOut="-25" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" distUnits="Pixel" layerType="LineGeometry" placement="2" fitInPolygonOnly="0" xOffset="0" preserveRotation="1" quadOffset="4" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" polygonPlacementFlags="2" centroidWhole="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" yOffset="0" rotationUnit="AngleDegrees" offsetType="0" geometryGenerator="" maxCurvedCharAngleIn="25" repeatDistance="0" repeatDistanceUnits="MM" overrunDistance="0" priority="5" lineAnchorClipping="0" placementFlags="12" geometryGeneratorEnabled="0" rotationAngle="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorType="PointGeometry" overrunDistanceUnit="MM" lineAnchorPercent="0.5"/>
              <rendering limitNumLabels="0" fontMinPixelSize="3" obstacleFactor="1" scaleVisibility="0" labelPerPart="0" upsidedownLabels="0" zIndex="0" unplacedVisibility="0" obstacleType="1" fontMaxPixelSize="10000" fontLimitPixelSize="0" scaleMax="0" displayAll="0" minFeatureSize="0" obstacle="1" maxNumLabels="2000" drawLabels="1" scaleMin="0" mergeLines="0"/>
              <dd_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option name="properties"/>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </dd_properties>
              <callout type="simple">
                <Option type="Map">
                  <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                  <Option type="int" name="blendMode" value="0"/>
                  <Option type="Map" name="ddProperties">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                  <Option type="bool" name="drawToAllParts" value="false"/>
                  <Option type="QString" name="enabled" value="0"/>
                  <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                  <Option type="QString" name="lineSymbol" value="&lt;symbol force_rhr=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; name=&quot;symbol&quot; alpha=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer class=&quot;SimpleLine&quot; pass=&quot;0&quot; enabled=&quot;1&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                  <Option type="double" name="minLength" value="0"/>
                  <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="minLengthUnit" value="MM"/>
                  <Option type="double" name="offsetFromAnchor" value="0"/>
                  <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                  <Option type="double" name="offsetFromLabel" value="0"/>
                  <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                </Option>
              </callout>
            </settings>
          </rule>
        </rule>
      </rule>
    </rules>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option type="StringList" name="dualview/previewExpressions">
        <Option type="QString" value="COALESCE( &quot;E_FNAME&quot;, '&lt;NULL>' )"/>
        <Option type="QString" value="COALESCE( &quot;E_FNAME&quot;, '&lt;NULL>' )"/>
        <Option type="QString" value="COALESCE( &quot;E_FNAME&quot;, '&lt;NULL>' )"/>
        <Option type="QString" value="COALESCE( &quot;E_FNAME&quot;, '&lt;NULL>' )"/>
        <Option type="QString" value="COALESCE( &quot;E_FNAME&quot;, '&lt;NULL>' )"/>
        <Option type="QString" value="COALESCE( &quot;E_FNAME&quot;, '&lt;NULL>' )"/>
      </Option>
      <Option type="QString" name="embeddedWidgets/count" value="0"/>
      <Option type="invalid" name="variableNames"/>
      <Option type="invalid" name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory lineSizeScale="3x:0,0,0,0,0,0" backgroundAlpha="255" direction="1" enabled="0" showAxis="0" backgroundColor="#ffffff" penWidth="0" sizeScale="3x:0,0,0,0,0,0" minimumSize="0" height="15" lineSizeType="MM" scaleBasedVisibility="0" scaleDependency="Area" minScaleDenominator="0" maxScaleDenominator="1e+08" opacity="1" labelPlacementMethod="XHeight" penColor="#000000" spacingUnitScale="3x:0,0,0,0,0,0" penAlpha="255" sizeType="MM" barWidth="5" width="15" spacing="0" rotationOffset="270" spacingUnit="MM" diagramOrientation="Up">
      <fontProperties description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style=""/>
      <attribute colorOpacity="1" color="#000000" label="" field=""/>
      <axisSymbol>
        <symbol force_rhr="0" type="line" clip_to_extent="1" name="" alpha="1">
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer class="SimpleLine" pass="0" enabled="1" locked="0">
            <Option type="Map">
              <Option type="QString" name="align_dash_pattern" value="0"/>
              <Option type="QString" name="capstyle" value="square"/>
              <Option type="QString" name="customdash" value="5;2"/>
              <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="customdash_unit" value="MM"/>
              <Option type="QString" name="dash_pattern_offset" value="0"/>
              <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
              <Option type="QString" name="draw_inside_polygon" value="0"/>
              <Option type="QString" name="joinstyle" value="bevel"/>
              <Option type="QString" name="line_color" value="35,35,35,255"/>
              <Option type="QString" name="line_style" value="solid"/>
              <Option type="QString" name="line_width" value="0.26"/>
              <Option type="QString" name="line_width_unit" value="MM"/>
              <Option type="QString" name="offset" value="0"/>
              <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="offset_unit" value="MM"/>
              <Option type="QString" name="ring_filter" value="0"/>
              <Option type="QString" name="trim_distance_end" value="0"/>
              <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_end_unit" value="MM"/>
              <Option type="QString" name="trim_distance_start" value="0"/>
              <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_start_unit" value="MM"/>
              <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
              <Option type="QString" name="use_custom_dash" value="0"/>
              <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            </Option>
            <prop k="align_dash_pattern" v="0"/>
            <prop k="capstyle" v="square"/>
            <prop k="customdash" v="5;2"/>
            <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="customdash_unit" v="MM"/>
            <prop k="dash_pattern_offset" v="0"/>
            <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="dash_pattern_offset_unit" v="MM"/>
            <prop k="draw_inside_polygon" v="0"/>
            <prop k="joinstyle" v="bevel"/>
            <prop k="line_color" v="35,35,35,255"/>
            <prop k="line_style" v="solid"/>
            <prop k="line_width" v="0.26"/>
            <prop k="line_width_unit" v="MM"/>
            <prop k="offset" v="0"/>
            <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="offset_unit" v="MM"/>
            <prop k="ring_filter" v="0"/>
            <prop k="trim_distance_end" v="0"/>
            <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="trim_distance_end_unit" v="MM"/>
            <prop k="trim_distance_start" v="0"/>
            <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="trim_distance_start_unit" v="MM"/>
            <prop k="tweak_dash_pattern_on_corners" v="0"/>
            <prop k="use_custom_dash" v="0"/>
            <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value=""/>
                <Option name="properties"/>
                <Option type="QString" name="type" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings dist="0" placement="2" linePlacementFlags="18" showAll="1" priority="0" obstacle="0" zIndex="0">
    <properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="None" name="ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="VERB_ART">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="V_A_SONST">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ANZAHL_VER">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LAE_KABEL">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ANZAHL_F_A">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LFD_M_F_A">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="F_A_RESERV">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ZUSTAND">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_TRASSEN">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_LR">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_START">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_ENDE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="E_FNAME">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="E_ORT">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="E_TEL">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="E_E_MAIL">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MP_MBFD_CO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="A_VNAME">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="A_ZNAME">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="A_TEL">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="A_E_MAIL">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MP_DB_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MP_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MIT_CAB_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="SM_AUFTRAG">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" index="0" field="ID"/>
    <alias name="" index="1" field="VERB_ART"/>
    <alias name="" index="2" field="V_A_SONST"/>
    <alias name="" index="3" field="ANZAHL_VER"/>
    <alias name="" index="4" field="LAE_KABEL"/>
    <alias name="" index="5" field="ANZAHL_F_A"/>
    <alias name="" index="6" field="LFD_M_F_A"/>
    <alias name="" index="7" field="F_A_RESERV"/>
    <alias name="" index="8" field="ZUSTAND"/>
    <alias name="" index="9" field="ID_TRASSEN"/>
    <alias name="" index="10" field="ID_LR"/>
    <alias name="" index="11" field="ID_START"/>
    <alias name="" index="12" field="ID_ENDE"/>
    <alias name="" index="13" field="E_FNAME"/>
    <alias name="" index="14" field="E_ORT"/>
    <alias name="" index="15" field="E_TEL"/>
    <alias name="" index="16" field="E_E_MAIL"/>
    <alias name="" index="17" field="MP_MBFD_CO"/>
    <alias name="" index="18" field="A_VNAME"/>
    <alias name="" index="19" field="A_ZNAME"/>
    <alias name="" index="20" field="A_TEL"/>
    <alias name="" index="21" field="A_E_MAIL"/>
    <alias name="" index="22" field="MP_DB_ID"/>
    <alias name="" index="23" field="MP_ID"/>
    <alias name="" index="24" field="MIT_CAB_ID"/>
    <alias name="" index="25" field="SM_AUFTRAG"/>
  </aliases>
  <defaults>
    <default applyOnUpdate="0" expression="" field="ID"/>
    <default applyOnUpdate="0" expression="" field="VERB_ART"/>
    <default applyOnUpdate="0" expression="" field="V_A_SONST"/>
    <default applyOnUpdate="0" expression="" field="ANZAHL_VER"/>
    <default applyOnUpdate="0" expression="" field="LAE_KABEL"/>
    <default applyOnUpdate="0" expression="" field="ANZAHL_F_A"/>
    <default applyOnUpdate="0" expression="" field="LFD_M_F_A"/>
    <default applyOnUpdate="0" expression="" field="F_A_RESERV"/>
    <default applyOnUpdate="0" expression="" field="ZUSTAND"/>
    <default applyOnUpdate="0" expression="" field="ID_TRASSEN"/>
    <default applyOnUpdate="0" expression="" field="ID_LR"/>
    <default applyOnUpdate="0" expression="" field="ID_START"/>
    <default applyOnUpdate="0" expression="" field="ID_ENDE"/>
    <default applyOnUpdate="0" expression="" field="E_FNAME"/>
    <default applyOnUpdate="0" expression="" field="E_ORT"/>
    <default applyOnUpdate="0" expression="" field="E_TEL"/>
    <default applyOnUpdate="0" expression="" field="E_E_MAIL"/>
    <default applyOnUpdate="0" expression="" field="MP_MBFD_CO"/>
    <default applyOnUpdate="0" expression="" field="A_VNAME"/>
    <default applyOnUpdate="0" expression="" field="A_ZNAME"/>
    <default applyOnUpdate="0" expression="" field="A_TEL"/>
    <default applyOnUpdate="0" expression="" field="A_E_MAIL"/>
    <default applyOnUpdate="0" expression="" field="MP_DB_ID"/>
    <default applyOnUpdate="0" expression="" field="MP_ID"/>
    <default applyOnUpdate="0" expression="" field="MIT_CAB_ID"/>
    <default applyOnUpdate="0" expression="" field="SM_AUFTRAG"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="ID"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="VERB_ART"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="V_A_SONST"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="ANZAHL_VER"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="LAE_KABEL"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="ANZAHL_F_A"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="LFD_M_F_A"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="F_A_RESERV"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="ZUSTAND"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="ID_TRASSEN"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="ID_LR"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="ID_START"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="ID_ENDE"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="E_FNAME"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="E_ORT"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="E_TEL"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="E_E_MAIL"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="MP_MBFD_CO"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="A_VNAME"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="A_ZNAME"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="A_TEL"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="A_E_MAIL"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="MP_DB_ID"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="MP_ID"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="MIT_CAB_ID"/>
    <constraint exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0" field="SM_AUFTRAG"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="ID"/>
    <constraint exp="" desc="" field="VERB_ART"/>
    <constraint exp="" desc="" field="V_A_SONST"/>
    <constraint exp="" desc="" field="ANZAHL_VER"/>
    <constraint exp="" desc="" field="LAE_KABEL"/>
    <constraint exp="" desc="" field="ANZAHL_F_A"/>
    <constraint exp="" desc="" field="LFD_M_F_A"/>
    <constraint exp="" desc="" field="F_A_RESERV"/>
    <constraint exp="" desc="" field="ZUSTAND"/>
    <constraint exp="" desc="" field="ID_TRASSEN"/>
    <constraint exp="" desc="" field="ID_LR"/>
    <constraint exp="" desc="" field="ID_START"/>
    <constraint exp="" desc="" field="ID_ENDE"/>
    <constraint exp="" desc="" field="E_FNAME"/>
    <constraint exp="" desc="" field="E_ORT"/>
    <constraint exp="" desc="" field="E_TEL"/>
    <constraint exp="" desc="" field="E_E_MAIL"/>
    <constraint exp="" desc="" field="MP_MBFD_CO"/>
    <constraint exp="" desc="" field="A_VNAME"/>
    <constraint exp="" desc="" field="A_ZNAME"/>
    <constraint exp="" desc="" field="A_TEL"/>
    <constraint exp="" desc="" field="A_E_MAIL"/>
    <constraint exp="" desc="" field="MP_DB_ID"/>
    <constraint exp="" desc="" field="MP_ID"/>
    <constraint exp="" desc="" field="MIT_CAB_ID"/>
    <constraint exp="" desc="" field="SM_AUFTRAG"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig actionWidgetStyle="dropDown" sortOrder="0" sortExpression="&quot;VERB_ART&quot;">
    <columns>
      <column hidden="0" type="field" width="-1" name="ID"/>
      <column hidden="0" type="field" width="-1" name="VERB_ART"/>
      <column hidden="0" type="field" width="-1" name="V_A_SONST"/>
      <column hidden="0" type="field" width="-1" name="ANZAHL_VER"/>
      <column hidden="0" type="field" width="-1" name="LAE_KABEL"/>
      <column hidden="0" type="field" width="-1" name="ANZAHL_F_A"/>
      <column hidden="0" type="field" width="-1" name="LFD_M_F_A"/>
      <column hidden="0" type="field" width="-1" name="F_A_RESERV"/>
      <column hidden="0" type="field" width="-1" name="ZUSTAND"/>
      <column hidden="0" type="field" width="-1" name="ID_TRASSEN"/>
      <column hidden="0" type="field" width="-1" name="ID_LR"/>
      <column hidden="0" type="field" width="-1" name="ID_START"/>
      <column hidden="0" type="field" width="-1" name="ID_ENDE"/>
      <column hidden="0" type="field" width="-1" name="E_FNAME"/>
      <column hidden="0" type="field" width="-1" name="E_ORT"/>
      <column hidden="0" type="field" width="-1" name="E_TEL"/>
      <column hidden="0" type="field" width="-1" name="E_E_MAIL"/>
      <column hidden="0" type="field" width="-1" name="MP_MBFD_CO"/>
      <column hidden="0" type="field" width="-1" name="A_VNAME"/>
      <column hidden="0" type="field" width="-1" name="A_ZNAME"/>
      <column hidden="0" type="field" width="-1" name="A_TEL"/>
      <column hidden="0" type="field" width="-1" name="A_E_MAIL"/>
      <column hidden="0" type="field" width="-1" name="MP_DB_ID"/>
      <column hidden="0" type="field" width="-1" name="MP_ID"/>
      <column hidden="0" type="field" width="-1" name="MIT_CAB_ID"/>
      <column hidden="0" type="field" width="-1" name="SM_AUFTRAG"/>
      <column hidden="1" type="actions" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1">C:/Users/AppData/Roaming</editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath>C:/Users/AppData/Roaming</editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <attributeEditorForm>
    <attributeEditorField showLabel="1" name="ID" index="0"/>
    <attributeEditorField showLabel="1" name="Verb_Art" index="1"/>
    <attributeEditorField showLabel="1" name="V_A_Sonst" index="2"/>
    <attributeEditorField showLabel="1" name="Lae_Kabel" index="4"/>
    <attributeEditorField showLabel="1" name="Anzahl_Ver" index="3"/>
    <attributeEditorField showLabel="1" name="Anzahl_F_A" index="5"/>
    <attributeEditorField showLabel="1" name="F_A_Reserv" index="7"/>
    <attributeEditorField showLabel="1" name="Zustand" index="8"/>
    <attributeEditorField showLabel="1" name="ANZAHL_V_1" index="-1"/>
    <attributeEditorField showLabel="1" name="LFD_M_F_A" index="6"/>
    <attributeEditorField showLabel="1" name="ID_TRASSEN" index="9"/>
    <attributeEditorField showLabel="1" name="ID_LR" index="10"/>
    <attributeEditorField showLabel="1" name="ID_START" index="11"/>
    <attributeEditorField showLabel="1" name="ID_ENDE" index="12"/>
    <attributeEditorField showLabel="1" name="E_FNAME" index="13"/>
    <attributeEditorField showLabel="1" name="E_ORT" index="14"/>
    <attributeEditorField showLabel="1" name="E_TEL" index="15"/>
    <attributeEditorField showLabel="1" name="E_E_MAIL" index="16"/>
    <attributeEditorField showLabel="1" name="A_VNAME" index="18"/>
    <attributeEditorField showLabel="1" name="A_ZNAME" index="19"/>
    <attributeEditorField showLabel="1" name="A_TEL" index="20"/>
    <attributeEditorField showLabel="1" name="A_E_MAIL" index="21"/>
    <attributeEditorField showLabel="1" name="MP_DB_ID" index="22"/>
    <attributeEditorField showLabel="1" name="MP_ID" index="23"/>
    <attributeEditorField showLabel="1" name="MIT_CAB_ID" index="24"/>
    <attributeEditorField showLabel="1" name="ID_LIST" index="-1"/>
    <attributeEditorField showLabel="1" name="MIT_CAB__1" index="-1"/>
  </attributeEditorForm>
  <editable>
    <field editable="1" name="ANZAHL_F_A"/>
    <field editable="1" name="ANZAHL_VER"/>
    <field editable="1" name="A_E_MAIL"/>
    <field editable="1" name="A_TEL"/>
    <field editable="1" name="A_VNAME"/>
    <field editable="1" name="A_ZNAME"/>
    <field editable="1" name="Anzahl_F_A"/>
    <field editable="1" name="E_E_MAIL"/>
    <field editable="1" name="E_FNAME"/>
    <field editable="1" name="E_ORT"/>
    <field editable="1" name="E_TEL"/>
    <field editable="1" name="F_A_RESERV"/>
    <field editable="1" name="F_A_Reserv"/>
    <field editable="1" name="ID"/>
    <field editable="1" name="ID_ENDE"/>
    <field editable="1" name="ID_LR"/>
    <field editable="1" name="ID_START"/>
    <field editable="1" name="ID_TRASSEN"/>
    <field editable="1" name="LAE_KABEL"/>
    <field editable="1" name="LFD_M_F_A"/>
    <field editable="1" name="Lae_Kabel"/>
    <field editable="1" name="MIT_CAB_ID"/>
    <field editable="1" name="MP_DB_ID"/>
    <field editable="1" name="MP_ID"/>
    <field editable="1" name="MP_MBFD_CO"/>
    <field editable="1" name="SM_AUFTRAG"/>
    <field editable="1" name="VERB_ART"/>
    <field editable="1" name="V_A_SONST"/>
    <field editable="1" name="V_A_Sonst"/>
    <field editable="1" name="Verb_Art"/>
    <field editable="1" name="ZUSTAND"/>
    <field editable="1" name="Zustand"/>
    <field editable="1" name="bezeichnung"/>
    <field editable="1" name="fid"/>
    <field editable="1" name="laenge_gemessen"/>
    <field editable="1" name="material_nummer"/>
    <field editable="1" name="material_spezifikation"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="ANZAHL_F_A"/>
    <field labelOnTop="0" name="ANZAHL_VER"/>
    <field labelOnTop="0" name="A_E_MAIL"/>
    <field labelOnTop="0" name="A_TEL"/>
    <field labelOnTop="0" name="A_VNAME"/>
    <field labelOnTop="0" name="A_ZNAME"/>
    <field labelOnTop="0" name="Anzahl_F_A"/>
    <field labelOnTop="0" name="E_E_MAIL"/>
    <field labelOnTop="0" name="E_FNAME"/>
    <field labelOnTop="0" name="E_ORT"/>
    <field labelOnTop="0" name="E_TEL"/>
    <field labelOnTop="0" name="F_A_RESERV"/>
    <field labelOnTop="0" name="F_A_Reserv"/>
    <field labelOnTop="0" name="ID"/>
    <field labelOnTop="0" name="ID_ENDE"/>
    <field labelOnTop="0" name="ID_LR"/>
    <field labelOnTop="0" name="ID_START"/>
    <field labelOnTop="0" name="ID_TRASSEN"/>
    <field labelOnTop="0" name="LAE_KABEL"/>
    <field labelOnTop="0" name="LFD_M_F_A"/>
    <field labelOnTop="0" name="Lae_Kabel"/>
    <field labelOnTop="0" name="MIT_CAB_ID"/>
    <field labelOnTop="0" name="MP_DB_ID"/>
    <field labelOnTop="0" name="MP_ID"/>
    <field labelOnTop="0" name="MP_MBFD_CO"/>
    <field labelOnTop="0" name="SM_AUFTRAG"/>
    <field labelOnTop="0" name="VERB_ART"/>
    <field labelOnTop="0" name="V_A_SONST"/>
    <field labelOnTop="0" name="V_A_Sonst"/>
    <field labelOnTop="0" name="Verb_Art"/>
    <field labelOnTop="0" name="ZUSTAND"/>
    <field labelOnTop="0" name="Zustand"/>
    <field labelOnTop="0" name="bezeichnung"/>
    <field labelOnTop="0" name="fid"/>
    <field labelOnTop="0" name="laenge_gemessen"/>
    <field labelOnTop="0" name="material_nummer"/>
    <field labelOnTop="0" name="material_spezifikation"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="ANZAHL_F_A"/>
    <field reuseLastValue="0" name="ANZAHL_VER"/>
    <field reuseLastValue="0" name="A_E_MAIL"/>
    <field reuseLastValue="0" name="A_TEL"/>
    <field reuseLastValue="0" name="A_VNAME"/>
    <field reuseLastValue="0" name="A_ZNAME"/>
    <field reuseLastValue="0" name="Anzahl_F_A"/>
    <field reuseLastValue="0" name="E_E_MAIL"/>
    <field reuseLastValue="0" name="E_FNAME"/>
    <field reuseLastValue="0" name="E_ORT"/>
    <field reuseLastValue="0" name="E_TEL"/>
    <field reuseLastValue="0" name="F_A_RESERV"/>
    <field reuseLastValue="0" name="F_A_Reserv"/>
    <field reuseLastValue="0" name="ID"/>
    <field reuseLastValue="0" name="ID_ENDE"/>
    <field reuseLastValue="0" name="ID_LR"/>
    <field reuseLastValue="0" name="ID_START"/>
    <field reuseLastValue="0" name="ID_TRASSEN"/>
    <field reuseLastValue="0" name="LAE_KABEL"/>
    <field reuseLastValue="0" name="LFD_M_F_A"/>
    <field reuseLastValue="0" name="Lae_Kabel"/>
    <field reuseLastValue="0" name="MIT_CAB_ID"/>
    <field reuseLastValue="0" name="MP_DB_ID"/>
    <field reuseLastValue="0" name="MP_ID"/>
    <field reuseLastValue="0" name="MP_MBFD_CO"/>
    <field reuseLastValue="0" name="SM_AUFTRAG"/>
    <field reuseLastValue="0" name="VERB_ART"/>
    <field reuseLastValue="0" name="V_A_SONST"/>
    <field reuseLastValue="0" name="V_A_Sonst"/>
    <field reuseLastValue="0" name="Verb_Art"/>
    <field reuseLastValue="0" name="ZUSTAND"/>
    <field reuseLastValue="0" name="Zustand"/>
    <field reuseLastValue="0" name="bezeichnung"/>
    <field reuseLastValue="0" name="fid"/>
    <field reuseLastValue="0" name="laenge_gemessen"/>
    <field reuseLastValue="0" name="material_nummer"/>
    <field reuseLastValue="0" name="material_spezifikation"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>COALESCE( "E_FNAME", '&lt;NULL>' )</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>

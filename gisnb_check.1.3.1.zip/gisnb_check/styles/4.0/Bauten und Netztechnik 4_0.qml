<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyMaxScale="1" maxScale="0" labelsEnabled="1" simplifyAlgorithm="0" simplifyDrawingTol="1" readOnly="0" symbologyReferenceScale="-1" version="3.34.11-Prizren" minScale="100000000" simplifyDrawingHints="0" hasScaleBasedVisibilityFlag="0" styleCategories="AllStyleCategories" simplifyLocal="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal mode="0" limitMode="0" durationField="fid" startField="" fixedDuration="0" startExpression="" endField="" endExpression="" enabled="0" durationUnit="min" accumulate="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation symbology="Line" binding="Centroid" respectLayerSymbol="1" zoffset="0" zscale="1" extrusionEnabled="0" showMarkerSymbolInSurfacePlots="0" clamping="Terrain" type="IndividualFeatures" extrusion="0">
    <data-defined-properties>
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties"/>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="" force_rhr="0" frame_rate="10" type="line">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{9247caf0-4360-4d95-b434-59c1db414859}" locked="0" pass="0" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option name="align_dash_pattern" value="0" type="QString"/>
            <Option name="capstyle" value="square" type="QString"/>
            <Option name="customdash" value="5;2" type="QString"/>
            <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="customdash_unit" value="MM" type="QString"/>
            <Option name="dash_pattern_offset" value="0" type="QString"/>
            <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
            <Option name="draw_inside_polygon" value="0" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="line_color" value="125,139,143,255" type="QString"/>
            <Option name="line_style" value="solid" type="QString"/>
            <Option name="line_width" value="0.6" type="QString"/>
            <Option name="line_width_unit" value="MM" type="QString"/>
            <Option name="offset" value="0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="ring_filter" value="0" type="QString"/>
            <Option name="trim_distance_end" value="0" type="QString"/>
            <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_end_unit" value="MM" type="QString"/>
            <Option name="trim_distance_start" value="0" type="QString"/>
            <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="trim_distance_start_unit" value="MM" type="QString"/>
            <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
            <Option name="use_custom_dash" value="0" type="QString"/>
            <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="" force_rhr="0" frame_rate="10" type="fill">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{637cbcd8-5da8-41b1-a2f5-c31aeb3255d2}" locked="0" pass="0" class="SimpleFill" enabled="1">
          <Option type="Map">
            <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="89,99,102,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="style" value="solid" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{6583e1f1-2fbd-4a31-9637-08b69c909938}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="125,139,143,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="diamond" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="89,99,102,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 referencescale="-1" enableorderby="0" forceraster="0" type="RuleRenderer" symbollevels="1">
    <rules key="{d1b4f60d-aa42-4ede-b402-2c0298d36840}">
      <rule label="Struktur" key="{f5984586-67ce-48f4-a44f-b349c5c7e7fc}">
        <rule symbol="0" label="(1) HVt/POP" key="{1f5ff417-f6a5-47c9-a6ce-3ff1249172f4}" filter=" &quot;Art&quot;  = 1"/>
        <rule symbol="1" label="(2) NVt neu" key="{8d39ad83-56f2-4c7c-aaa2-3fdaf0f6c487}" filter="&quot;Art&quot;  = 2 AND &quot;ZUSTAND&quot; = 1 AND  &quot;Bezeichner&quot; Like '%V%'"/>
        <rule symbol="2" label="(2) NVt Bestand " key="{1a5bae3b-509f-4870-af28-9b96e3569145}" filter="&quot;Art&quot;  = 2 AND &quot;ZUSTAND&quot; = 2 AND  &quot;Bezeichner&quot; Like '%V%'"/>
        <rule symbol="3" label="(99) NVt neu (in Muffe)" key="{4261cdcb-6271-4579-995a-1f80bda95491}" filter="&quot;Art&quot;  = 99 AND &quot;ZUSTAND&quot; = 1 AND  &quot;Art_Sonst&quot; Like '%NVt in Muffe%'"/>
        <rule symbol="4" label="(99) NVt Bestand (in Muffe)" key="{8e4394d4-5d61-4785-880a-be7d4e689757}" filter="&quot;Art&quot;  = 99 AND &quot;ZUSTAND&quot; = 2 AND  &quot;Art_Sonst&quot; Like '%NVt in Muffe%'"/>
        <rule symbol="5" label="(6) MFG (MSAN) neu" key="{48ec001b-b2ed-405c-9463-35534e8ce7ad}" filter=" &quot;Art&quot;  = 6 AND &quot;ZUSTAND&quot; = 1 AND  (&quot;Bezeichner&quot; Like '%A%' OR &quot;Bezeichner&quot; Like '%R%')"/>
        <rule symbol="6" label="(6) MFG (MSAN) Bestand" key="{4d91291a-f515-42cb-8055-c11794824733}" filter=" &quot;Art&quot;  = 6 AND &quot;ZUSTAND&quot; = 2 AND  (&quot;Bezeichner&quot; Like '%A%' OR &quot;Bezeichner&quot; Like '%R%')"/>
        <rule symbol="7" label="(99) KVz (Mini-MSAN) Geh. neu" key="{7bebc814-e98a-466f-b829-0a0d43839d85}" filter=" &quot;Art&quot;  = 99 AND &quot;ZUSTAND&quot; = 1 AND   &quot;Art_Sonst&quot; = 'Mini-MSAN'&#xa;"/>
        <rule symbol="8" label="(99) KVz (Mini-MSAN) Geh. Bestand" key="{4339cba1-0ba9-4f09-9cfe-fa8748c71498}" filter=" &quot;Art&quot;  = 99 AND &quot;ZUSTAND&quot; = 2 AND   &quot;Art_Sonst&quot; = 'Mini-MSAN'&#xa;"/>
        <rule symbol="9" label="(2) KVz neu" key="{ef7116c1-b61f-4d40-af48-379672866baf}" filter=" &quot;Art&quot;  = 2 AND &quot;ZUSTAND&quot; = 1 AND  &quot;Bezeichner&quot; Like '%A%'"/>
        <rule symbol="10" label="(2) KVz Bestand" key="{717493cb-081a-4a5d-8e48-25f870cfd92b}" filter=" &quot;Art&quot;  = 2 AND &quot;ZUSTAND&quot; = 2 AND  &quot;Bezeichner&quot; Like '%A%'"/>
        <rule symbol="11" label="(4)  HÜP/ApL (Gf-AP)" key="{b60894d9-4170-42e7-95e6-7d3d9270ec28}" filter="&quot;Art&quot; = 4"/>
        <rule symbol="12" label="(3) Kabelschacht/Muffe neu" key="{41b18c01-094a-4d98-9ffe-e8c003c49b0a}" filter="&quot;Art&quot; = 3 AND  &quot;Zustand&quot; = 1"/>
        <rule symbol="13" label="(3) Kabelschacht/Muffe Bestand" key="{4498c288-3820-4808-8b36-f747523f7cc1}" filter="&quot;Art&quot; = 3 AND  &quot;Zustand&quot; = 2"/>
        <rule symbol="14" label="(99) Sonstiges" key="{62148f0c-e791-41f1-9bac-d1f05fc92d1b}" filter="&quot;Art&quot; = 99 AND  &quot;Art_Sonst&quot; IS NOT NULL"/>
        <rule symbol="15" label="(99) Mastboxen" key="{d2f95892-cb13-4f02-97e3-41fbf99f6843}" filter="&quot;Art&quot; = 99 AND  &quot;Art_Sonst&quot; = 'Mastbox'"/>
      </rule>
      <rule symbol="16" checkstate="0" label="alle Netztechnik" key="{b0d0999d-a2c9-47f3-beb5-05fc9f090c91}"/>
      <rule checkstate="0" label="Prüfung" key="{1dd94915-4b2c-4705-81a3-5924875d5630}">
        <rule symbol="17" checkstate="0" label="(99) Mini-MSAN und nicht Art = 99" key="{93e03f6f-6882-474e-a70f-0582995d30ef}" filter=" &quot;Art&quot;  != 99 AND &quot;ART_SONST&quot;  = 'Mini-MSAN'"/>
        <rule symbol="18" checkstate="0" label="(99) Mastboxen und nicht Art= 99" key="{2cdc2c66-8527-402b-87e5-1e536c7b354c}" filter=" &quot;Art&quot;  != 99 AND &quot;ART_SONST&quot;  = 'Mastbox'"/>
        <rule symbol="19" checkstate="0" label="Art_NT nicht plausibel" key="{ea4a0d5d-6771-4ab4-8fa5-c881f0cb5e8d}" filter=" &quot;Art&quot;  NOT IN (1,2,3,4,6,99)"/>
        <rule symbol="20" checkstate="0" label="ID_Tech unplausibel" key="{1f2591f4-4c9c-410d-ae76-2cb851559173}" filter="(&#xd;&#xa;&quot;Art&quot; IN (1,3,99) AND&#xd;&#xa;&quot;Art_Sonst&quot; IS NOT 'Mini-MSAN' AND&#xd;&#xa;&quot;Art_Sonst&quot; IS NOT 'NVt in Muffe'&#xd;&#xa;) AND&#xd;&#xa;&quot;ID_TECH&quot; IS NOT '-1'"/>
        <rule symbol="21" checkstate="0" label="Fehlende Attribute" key="{8270f2fe-a215-4721-9eaf-446985535fbb}" filter=" &quot;ID&quot; IS NULL OR &quot;Art&quot; IS NULL OR &quot;Zustand&quot; IS NULL OR &quot;Bezeichner&quot; IS NULL OR &quot;ID_Tech&quot; IS NULL"/>
        <rule symbol="22" checkstate="0" label="Prüfen: Wirklich Gehäuse MFG in Bestand?" key="{de090185-3ea4-4445-9faa-b9deea50a600}" filter=" &quot;Art&quot;  = 6 AND &quot;ZUSTAND&quot; = 2 AND  &quot;Bezeichner&quot; Like '%A%'"/>
        <rule symbol="23" checkstate="0" label="Prüfen: Wirklich Gehäuse NVt in Bestand?" key="{47971c10-5466-46b0-9f2a-ae9f2f048e56}" filter=" &quot;Art&quot;  = 2 AND &quot;ZUSTAND&quot; = 2 AND  &quot;Bezeichner&quot; Like '%V%'"/>
        <rule symbol="24" checkstate="0" label="Prüfen: Welchen Zustand hat Gehäuse Mini-MSAN wirklich?" key="{0a346547-01c5-4be8-aa90-37c838c55177}" filter=" &quot;Art&quot;  = 99 AND  &quot;Art_Sonst&quot; = 'Mini-MSAN'&#xa;"/>
        <rule symbol="25" checkstate="0" label="Prüfen: Wirklich Gf-AP in Bestand?" key="{e45b2572-ba94-4794-bd4f-4c7ad1518e08}" filter=" &quot;Art&quot;  = 4 AND &quot;ZUSTAND&quot; = 2"/>
      </rule>
    </rules>
    <symbols>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="0" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{99184aaa-7886-4d9a-a277-42eb3c068310}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,255,255,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.6" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="area" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{f6dde581-54c9-44eb-bf56-5ea0fa0d1f43}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="90" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,127,0,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="line" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.6" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="area" type="QString"/>
            <Option name="size" value="5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="1" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{b7022ad4-8d8f-4703-8e68-99e9730066bd}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="32,168,11,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="diamond" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="239,0,4,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="area" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{74a3954e-e245-476d-a6c7-28aa21a148cc}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="255,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="10" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{fd42b417-d48e-4555-92a8-875293df12a0}" locked="0" pass="1" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,255,255,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="area" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{0fd6bbf9-af20-4cac-bc87-82fb861b0273}" locked="0" pass="1" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,0" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="1.5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{ec5bdc38-c537-4957-9207-27a5275cc49f}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="11" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{5a443194-3a84-4551-80f3-e4ce329b311f}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="1,255,30,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="1" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="12" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{e4befeb6-9b13-4c13-84a3-d985c8264687}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="239,0,4,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="1.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="13" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{a005083b-271d-4462-ae98-d68060263e93}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="1.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="14" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{69842a7c-22f9-4ee6-acd6-e2649365458c}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="236,129,239,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="15" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{b215c39b-7028-4319-81a9-079734ed6b30}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="73,190,253,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="16" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{3e0d3ec1-b01a-429c-9805-6418f41a8296}" locked="0" pass="0" class="FilledMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="name" value="asterisk_fill" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2.8" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol clip_to_extent="1" alpha="1" is_animated="0" name="@16@0" force_rhr="0" frame_rate="10" type="fill">
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer id="{30a1e471-6381-48ee-8312-e933068f6f63}" locked="0" pass="0" class="SimpleFill" enabled="1">
              <Option type="Map">
                <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="joinstyle" value="bevel" type="QString"/>
                <Option name="offset" value="0,0" type="QString"/>
                <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="outline_color" value="255,0,0,255" type="QString"/>
                <Option name="outline_style" value="solid" type="QString"/>
                <Option name="outline_width" value="0.4" type="QString"/>
                <Option name="outline_width_unit" value="MM" type="QString"/>
                <Option name="style" value="solid" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="17" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{59325b2d-3969-40c3-b734-e681e2325ab0}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="236,180,239,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="255,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="0" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="0.5" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,0,0,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="2" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="opacity" value="0.5" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,255,255,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="2" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{4b5ec67b-cc54-4f97-b915-058ee18e4dcc}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="90" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="triangle" type="QString"/>
            <Option name="offset" value="0,-0.352941" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,0" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="18" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{20954ab6-47be-4145-aff6-df3fd9090008}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="73,190,253,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="0" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,0,0,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="2" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="opacity" value="0.5" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,255,255,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="2" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="19" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{a97f7a37-afd8-4b55-8d51-3aca9393e8ab}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,165,47,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="0" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,0,0,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="2" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="opacity" value="0.5" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,255,255,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="2" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="2" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{2e7f5239-c2be-4b94-accd-c837fa3915f1}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="32,168,11,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="diamond" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="area" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{c081af98-a433-4aa8-9e8b-f71fe6c12a10}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="20" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{427738ab-a567-4f20-96ea-42a3a766702a}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,165,47,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="0" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,0,0,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="2" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="opacity" value="0.5" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,255,255,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="2" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="21" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{8bc68a98-07eb-450f-a7db-fd485ea6ce46}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,165,47,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="0" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,0,0,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="2" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="opacity" value="0.5" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,255,255,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="2" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="22" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{4b343c2b-8d8c-4283-b662-c65b480cb44c}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="248,1,236,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="area" type="QString"/>
            <Option name="size" value="4.1" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="0" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="0.65" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,0,0,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="4" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="opacity" value="0.5" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,255,255,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="2" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{b622141c-59d1-45e5-bd4b-b30744ff187b}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{811b2077-3ef4-4485-a4b0-9ce43777c36b}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="90" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="triangle" type="QString"/>
            <Option name="offset" value="0,-0.352941" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,0" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="23" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{9b3ca893-15aa-44d8-9137-0803b52361e1}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="32,168,11,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="diamond" type="QString"/>
            <Option name="offset" value="0,1.39999999999999991" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="area" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="2" type="QString"/>
          </Option>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="0" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="0.741" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,0,0,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="4" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="opacity" value="0.5" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,255,255,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="2" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="24" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{3e002b9d-b854-4438-9082-9bca4a4d87e8}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="236,180,239,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="255,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="0" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="0.751" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,0,0,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="4" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="0" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="opacity" value="0.439" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,0,0,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="4" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="25" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{b7f3aab8-4d8e-4013-a66e-b4a1044d7939}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="1,255,30,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="1" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="0" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="0.5" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,0,0,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="7" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="1" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option name="blend_mode" value="13" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color" value="0,0,0,255" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="offset_angle" value="135" type="QString"/>
                <Option name="offset_distance" value="2" type="QString"/>
                <Option name="offset_unit" value="MM" type="QString"/>
                <Option name="offset_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="opacity" value="1" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option name="blend_mode" value="0" type="QString"/>
                <Option name="blur_level" value="2.645" type="QString"/>
                <Option name="blur_unit" value="MM" type="QString"/>
                <Option name="blur_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="color1" value="0,0,255,255" type="QString"/>
                <Option name="color2" value="0,255,0,255" type="QString"/>
                <Option name="color_type" value="0" type="QString"/>
                <Option name="direction" value="ccw" type="QString"/>
                <Option name="discrete" value="0" type="QString"/>
                <Option name="draw_mode" value="2" type="QString"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="opacity" value="0.5" type="QString"/>
                <Option name="rampType" value="gradient" type="QString"/>
                <Option name="single_color" value="255,255,255,255" type="QString"/>
                <Option name="spec" value="rgb" type="QString"/>
                <Option name="spread" value="2" type="QString"/>
                <Option name="spread_unit" value="MM" type="QString"/>
                <Option name="spread_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="3" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{f56de805-00aa-4b5e-ab1c-1e3e2b7f9959}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="32,168,11,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="diamond" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="239,0,4,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="area" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{a076e488-2fb5-4ae6-a2fb-2214493a5d20}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="255,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="4" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{b12ba43b-9747-40fa-b93a-0a74b864905d}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="32,168,11,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="diamond" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="area" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{159a93f4-eb8c-45d5-bbef-d1723e39f5a1}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="5" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{4874a4bc-4d6f-4465-819b-812ef42649cf}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="248,1,236,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="255,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="area" type="QString"/>
            <Option name="size" value="4.1" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{39f1a3eb-6058-4136-9f3e-478affbbd51a}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="255,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{bc874901-c00d-4430-892d-f3e9bc5d7057}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="90" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="triangle" type="QString"/>
            <Option name="offset" value="0,-0.352941" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,0" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="6" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{5b9edc2d-3927-4e2d-88b5-cd1cea715312}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="248,1,236,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="area" type="QString"/>
            <Option name="size" value="4.1" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{2d1823d2-9e29-4fd7-a017-02b40bf1d478}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{aa959767-549c-4aa0-8e0f-67f26c02457b}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="90" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="0,0,0,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="triangle" type="QString"/>
            <Option name="offset" value="0,-0.352941" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,0" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="7" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{3e8ed943-2317-40a8-a72e-65050565a2c7}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="236,180,239,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="255,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{02754824-23c8-4e62-b67f-4d45b54617d2}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="90" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="triangle" type="QString"/>
            <Option name="offset" value="0,-0.352941" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,0" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="8" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{9bea7b45-c30e-4aa3-99b8-3190d308acb2}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="236,180,239,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{f9dea6ea-d20f-42db-85e6-1e075770818f}" locked="0" pass="2" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="90" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="triangle" type="QString"/>
            <Option name="offset" value="0,-0.352941" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="0,0,0,0" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="9" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{78a5b3c2-5ce2-41c3-bcc1-8826e3fb6d0d}" locked="0" pass="1" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,255,255,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="255,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.4" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="area" type="QString"/>
            <Option name="size" value="3" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{515ff51c-1c5b-4ee6-a714-d1c70c9cff78}" locked="0" pass="1" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,0" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="1.5" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer id="{7dcd4fea-2ea3-4efe-b08d-7b6b2b3401ed}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,0" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="square" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="255,0,0,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0.2" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="5.6" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol clip_to_extent="1" alpha="1" is_animated="0" name="" force_rhr="0" frame_rate="10" type="marker">
        <data_defined_properties>
          <Option type="Map">
            <Option name="name" value="" type="QString"/>
            <Option name="properties"/>
            <Option name="type" value="collection" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer id="{355afb9b-9377-4a0d-af46-271eec40a48b}" locked="0" pass="0" class="SimpleMarker" enabled="1">
          <Option type="Map">
            <Option name="angle" value="0" type="QString"/>
            <Option name="cap_style" value="square" type="QString"/>
            <Option name="color" value="255,0,0,255" type="QString"/>
            <Option name="horizontal_anchor_point" value="1" type="QString"/>
            <Option name="joinstyle" value="bevel" type="QString"/>
            <Option name="name" value="circle" type="QString"/>
            <Option name="offset" value="0,0" type="QString"/>
            <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="offset_unit" value="MM" type="QString"/>
            <Option name="outline_color" value="35,35,35,255" type="QString"/>
            <Option name="outline_style" value="solid" type="QString"/>
            <Option name="outline_width" value="0" type="QString"/>
            <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="outline_width_unit" value="MM" type="QString"/>
            <Option name="scale_method" value="diameter" type="QString"/>
            <Option name="size" value="2" type="QString"/>
            <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            <Option name="size_unit" value="MM" type="QString"/>
            <Option name="vertical_anchor_point" value="1" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="rule-based">
    <rules key="{cf4450fa-1bab-447c-91ce-179c0aa8c84d}">
      <rule description="Struktur" key="{c220eb47-447a-44fa-bf49-8a4c6c2b96cf}" filter="1">
        <rule description="HVt" key="{d169395c-9c0c-4ff4-b57a-00772b11e9bf}" filter=" &quot;ART&quot;  = 1">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,255,255,255" fontWeight="75" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Bold" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="7" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="0.71700000000000008" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="21,7,22,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="21,7,22,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="10" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{2739e60e-3172-4c85-8bb6-da4fe6629fb1}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="MFG neu" key="{7f8dd012-52d6-43fb-8d9c-f1c9101d3902}" filter=" &quot;ART&quot;  = 6 AND  &quot;Zustand&quot; = 1">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,0,0,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="1" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="255,255,255,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="255,255,255,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="9" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{6ceeb690-8a6e-415f-be06-310fcc71c147}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="MFG Bestand" key="{c84c2697-7458-4e06-84a8-741593bf6af0}" filter=" &quot;ART&quot;  = 6 AND  &quot;Zustand&quot; = 2">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,255,255,255" fontWeight="75" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Bold" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="7" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="0.69999999999999996" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="0,0,0,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="0,0,0,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="9" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{ad6db798-c87f-406c-a9a4-b1df83961981}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="Mini-MSAN neu" key="{8915bb1d-a935-492d-9449-d636cc83d8b1}" filter=" &quot;ART&quot;  = 99 AND &quot;Art_Sonst&quot; = 'Mini-MSAN' AND &quot;Zustand&quot; = 1">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,0,0,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="1" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="255,255,255,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="255,255,255,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="9" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{1d28916b-2771-4089-ab7a-67938a972373}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="Mini-MSAN Bestand" key="{a828b295-89ba-4f16-8a89-8b946a175507}" filter=" &quot;ART&quot;  = 99 AND &quot;Art_Sonst&quot; = 'Mini-MSAN' AND &quot;Zustand&quot; = 2">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,255,255,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="0.69999999999999996" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="0,0,0,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="0,0,0,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="9" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{7cc1cc8c-8545-498c-94c0-c0c92c80b664}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="KVz neu" key="{71e70c16-268f-4709-8f36-ea451dee5b5d}" filter=" &quot;ART&quot;  = 2 AND  &quot;Bezeichner&quot; Like '%A%' AND &quot;Zustand&quot; = 1">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,0,0,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="1" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="255,255,255,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="255,255,255,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="9" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{907bbbb4-5d16-4094-951d-7a1d64fadcff}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="KVz Bestand" key="{e374b2bc-4643-4b47-b66c-ddab7c582010}" filter=" &quot;ART&quot;  = 2 AND  &quot;Bezeichner&quot; Like '%A%' AND &quot;Zustand&quot; = 2">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,255,255,255" fontWeight="75" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Bold" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="7" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="0.69999999999999996" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="0,0,0,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="0,0,0,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="9" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{69a102db-a724-4fcc-a17f-0b847cd0860e}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="NVt neu" key="{d68b6c30-13b2-4746-95bb-ac1ea78879b4}" filter="&quot;Art&quot;  = 2 AND &quot;ZUSTAND&quot; = 1 AND  &quot;Bezeichner&quot; Like '%V%'">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,0,0,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="1" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="255,255,255,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="255,255,255,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="10" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{fc4cf1f7-ae11-48cc-8d96-edc32670ba85}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="NVt Bestand" key="{ab069dd1-21c8-4fe7-b5ed-8cda2373c087}" filter="&quot;Art&quot;  = 2 AND &quot;ZUSTAND&quot; = 2 AND  &quot;Bezeichner&quot; Like '%V%'">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,255,255,255" fontWeight="75" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Bold" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="7" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="0.69999999999999996" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="0,0,0,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="0,0,0,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="9" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{98989d9f-6f3c-4e3a-8c1d-4b9c56fe1615}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="NVt neu (in Muffe)" key="{e16d774e-8d65-4a23-9af9-c8569db9bf5c}" filter="&quot;Art&quot;  = 99 AND &quot;ZUSTAND&quot; = 1 AND  &quot;Art_Sonst&quot; Like '%NVt in Muffe%'">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,0,0,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot; || ' (in Muffe)'" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="1" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="255,255,255,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="255,255,255,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="10" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{29297253-1238-44da-a902-85fe567c0ec4}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="NVt Bestand (in Muffe)" key="{629ccb16-0f77-4286-abb0-43b744996010}" filter="&quot;Art&quot;  = 99 AND &quot;ZUSTAND&quot; = 2 AND  &quot;Art_Sonst&quot; Like '%NVt in Muffe%'">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,255,255,255" fontWeight="75" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Bold" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="7" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot; || ' (in Muffe)'" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="0.69999999999999996" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="0,0,0,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="0,0,0,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="10" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{bf54babe-9acc-4114-8247-4f5e5ad42168}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule scalemaxdenom="5500" scalemindenom="1" description="Gf-AP" key="{337fe6ab-05a5-422e-bbb3-4803c25589ef}" filter=" &quot;ART&quot;  = 4">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="0,0,0,255" fontWeight="50" fontStrikeout="0" isExpression="0" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName="Bezeichner" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="1" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="177,255,130,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="177,255,130,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="5" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{834cf30b-2910-4bfc-85cf-f2ed0504498a}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="Mastboxen" key="{60a20d29-0a5b-41c8-885d-46a464c456ae}" filter=" &quot;Art&quot;  = 99 AND  &quot;Art_Sonst&quot;   = 'Mastbox'">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="0,0,0,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8.1999999999999993" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName="'Mastbox'" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="0.317" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="236,82,239,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="236,82,239,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="5" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{1ecf01ca-1f34-47df-87b9-99c5768c2be0}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
      </rule>
      <rule description="Detail" key="{8694d55a-2194-4ee0-ba00-37af96843100}" filter="0">
        <rule description="HVt" key="{a3ca5d0b-0c74-425c-a6c3-81ac16fb982d}" filter=" &quot;ART&quot;  = 1">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,255,255,255" fontWeight="75" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Bold" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="7" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName="'HVt-ID: ' ||  &quot;ID&quot;  || '>   ' || &quot;BEZEICHNER&quot;  " fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="0.71700000000000008" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="21,7,22,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="21,7,22,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="5" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{b94605da-6dcd-4cb7-8680-7e0e69507aa7}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="MFG neu" key="{07ec8319-051d-45c9-b14a-a9a696d403c0}" filter=" &quot;ART&quot;  = 6 AND  &quot;Zustand&quot; = 1">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,0,0,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName="'MFG-ID: '||&quot;ID&quot;||'   ID_Tech: '||&quot;ID_Tech&quot; ||'>'||&quot;BEZEICHNER&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="1" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="255,255,255,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="255,255,255,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="5" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{8b15f3ea-e7fd-4ce5-9bde-a1d2a8a46143}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="MFG Bestand" key="{ebac1bb6-47fc-4208-9176-a791c887a7f1}" filter=" &quot;ART&quot;  = 6 AND  &quot;Zustand&quot; = 2">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,255,255,255" fontWeight="75" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Bold" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="7" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName="'MFG-ID: '||&quot;ID&quot;||'   ID_Tech: '||&quot;ID_Tech&quot; ||'>'||&quot;BEZEICHNER&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="0.69999999999999996" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="0,0,0,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="0,0,0,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="5" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{5b2dec22-10c6-4694-bbba-56ddadc42bbb}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="Mini-MSAN neu" key="{8ed28816-7f2c-4839-ab1e-53dbaf066de5}" filter=" &quot;ART&quot;  = 99 AND &quot;Art_Sonst&quot; = 'Mini-MSAN' AND &quot;Zustand&quot; = 1">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,0,0,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName="'Mini-MSAN-ID: '||&quot;ID&quot;||'   ID_Tech: '||&quot;ID_Tech&quot; ||'>'||&quot;BEZEICHNER&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="1" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="255,255,255,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="255,255,255,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="5" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{0d6334ea-b281-4ced-923b-989d6ca50829}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="Mini-MSAN Bestand" key="{2649b077-c38b-4797-b32d-626ca94ddfa3}" filter=" &quot;ART&quot;  = 99 AND &quot;Art_Sonst&quot; = 'Mini-MSAN' AND &quot;Zustand&quot; = 2">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,255,255,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName="'Mini-MSAN-ID: '||&quot;ID&quot;||'   ID_Tech: '||&quot;ID_Tech&quot; ||'>'||&quot;BEZEICHNER&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="0.69999999999999996" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="0,0,0,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="0,0,0,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="5" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{651c267b-7497-4f32-a43f-007d5b54b1f4}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="KVz neu" key="{12e214aa-e74b-44ec-a18b-97b411543604}" filter=" &quot;ART&quot;  = 2 AND  &quot;Bezeichner&quot; Like '%A%' AND &quot;Zustand&quot; = 1">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,0,0,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName="'KVz-ID: '||&quot;ID&quot;||'   ID_Tech: '||&quot;ID_Tech&quot; ||'>'||&quot;BEZEICHNER&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="1" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="255,255,255,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="255,255,255,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="5" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{862575c6-3e47-42b6-82e4-e66e904c92f5}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="KVz Bestand" key="{0f46a705-862f-48c4-8565-0720e704ac6f}" filter=" &quot;ART&quot;  = 2 AND  &quot;Bezeichner&quot; Like '%A%' AND &quot;Zustand&quot; = 2">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,255,255,255" fontWeight="75" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Bold" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="7" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName="'KVz-ID: '||&quot;ID&quot;||'   ID_Tech: '||&quot;ID_Tech&quot; ||'>'||&quot;BEZEICHNER&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="0.69999999999999996" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="0,0,0,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="0,0,0,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="5" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{b643d6ee-a498-4548-af4a-cf8bbee6069f}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="NVt neu" key="{8022fdd3-3fcc-4704-8c4f-6641353095c4}" filter=" &quot;ART&quot;  = 2 AND  &quot;Bezeichner&quot; Like '%V%' AND &quot;Zustand&quot; = 1">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,0,0,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName="'NVt-ID: '||&quot;ID&quot;||'   ID_Tech: '||&quot;ID_Tech&quot; ||'>'||&quot;BEZEICHNER&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="1" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="255,255,255,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="255,255,255,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="5" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{c564d55e-b8ac-4282-ace7-409dab864a78}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="NVt Bestand" key="{13992e2a-92c4-417a-92f1-686c99608ee1}" filter=" &quot;ART&quot;  = 2 AND  &quot;Bezeichner&quot; Like '%V%' AND &quot;Zustand&quot; = 2">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="255,255,255,255" fontWeight="75" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Bold" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="7" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName="'NVt-ID: '||&quot;ID&quot;||'   ID_Tech: '||&quot;ID_Tech&quot; ||'>'||&quot;BEZEICHNER&quot;" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="0.69999999999999996" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="0,0,0,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="0,0,0,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="5" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{c65c9f29-8685-4b28-876c-1dde515841d5}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="Gf-AP" key="{36fde7d1-5c97-4aa9-9584-206129369fcf}" filter=" &quot;ART&quot;  = 4">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="0,0,0,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName="&quot;BEZEICHNER&quot;||'>'||'ID_Tech: '||&quot;ID_Tech&quot; " fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="1" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="177,255,130,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="177,255,130,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="5" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{d4665b7e-3f2b-4a11-8e34-457064916678}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule description="Mastboxen" key="{51c944d4-b481-4273-b100-11aa409b5a24}" filter=" &quot;Art&quot;  = 99 AND  &quot;Art_Sonst&quot;   = 'Mastbox'">
          <settings calloutType="simple">
            <text-style fontSizeUnit="Point" fontUnderline="0" fontSizeMapUnitScale="3x:0,0,0,0,0,0" blendMode="0" legendString="Aa" textColor="0,0,0,255" fontWeight="50" fontStrikeout="0" isExpression="1" fontLetterSpacing="0" namedStyle="Standard" fontFamily="MS Shell Dlg 2" fontWordSpacing="0" fontSize="8.1999999999999993" previewBkgrdColor="255,255,255,255" textOpacity="1" textOrientation="horizontal" allowHtml="0" capitalization="0" multilineHeight="1" fontItalic="0" fieldName="'Mastbox'" fontKerning="1" forcedItalic="0" forcedBold="0" useSubstitutions="0" multilineHeightUnit="Percentage">
              <families/>
              <text-buffer bufferDraw="0" bufferSizeUnits="MM" bufferJoinStyle="128" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferOpacity="1" bufferBlendMode="0" bufferNoFill="1" bufferColor="255,255,255,255"/>
              <text-mask maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskedSymbolLayers="" maskSize2="1.5" maskSize="1.5" maskEnabled="0" maskType="0" maskSizeUnits="MM"/>
              <background shapeRotation="0" shapeOpacity="0.317" shapeDraw="1" shapeOffsetUnit="MM" shapeRotationType="0" shapeOffsetY="0" shapeType="0" shapeBorderColor="128,128,128,255" shapeSizeUnit="MM" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeJoinStyle="64" shapeRadiiY="0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiUnit="MM" shapeBorderWidth="0.10000000000000001" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeSizeType="0" shapeSizeY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeRadiiX="0" shapeOffsetX="0" shapeFillColor="236,82,239,255" shapeBlendMode="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0">
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="markerSymbol" force_rhr="0" frame_rate="10" type="marker">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleMarker" enabled="1">
                    <Option type="Map">
                      <Option name="angle" value="0" type="QString"/>
                      <Option name="cap_style" value="square" type="QString"/>
                      <Option name="color" value="145,82,45,255" type="QString"/>
                      <Option name="horizontal_anchor_point" value="1" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="name" value="circle" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="35,35,35,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0" type="QString"/>
                      <Option name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="scale_method" value="diameter" type="QString"/>
                      <Option name="size" value="2" type="QString"/>
                      <Option name="size_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="size_unit" value="MM" type="QString"/>
                      <Option name="vertical_anchor_point" value="1" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol clip_to_extent="1" alpha="1" is_animated="0" name="fillSymbol" force_rhr="0" frame_rate="10" type="fill">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option name="name" value="" type="QString"/>
                      <Option name="properties"/>
                      <Option name="type" value="collection" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer id="" locked="0" pass="0" class="SimpleFill" enabled="1">
                    <Option type="Map">
                      <Option name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="color" value="236,82,239,255" type="QString"/>
                      <Option name="joinstyle" value="bevel" type="QString"/>
                      <Option name="offset" value="0,0" type="QString"/>
                      <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
                      <Option name="offset_unit" value="MM" type="QString"/>
                      <Option name="outline_color" value="128,128,128,255" type="QString"/>
                      <Option name="outline_style" value="solid" type="QString"/>
                      <Option name="outline_width" value="0.1" type="QString"/>
                      <Option name="outline_width_unit" value="MM" type="QString"/>
                      <Option name="style" value="solid" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option name="name" value="" type="QString"/>
                        <Option name="properties"/>
                        <Option name="type" value="collection" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowColor="0,0,0,255" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetAngle="135" shadowRadiusUnit="MM" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadius="1.5" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowUnder="0" shadowBlendMode="6" shadowOpacity="0.69999999999999996"/>
              <dd_properties>
                <Option type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format rightDirectionSymbol=">" wrapChar=">" multilineAlign="3" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" decimals="3" addDirectionSymbol="0" plussign="0" formatNumbers="0" reverseDirectionSymbol="0" placeDirectionSymbol="0" leftDirectionSymbol="&lt;"/>
            <placement repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" allowDegraded="0" maxCurvedCharAngleIn="25" rotationAngle="0" lineAnchorPercent="0.5" yOffset="0" polygonPlacementFlags="2" placementFlags="10" repeatDistanceUnits="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" geometryGenerator="" lineAnchorType="0" lineAnchorClipping="0" preserveRotation="1" repeatDistance="0" centroidInside="0" offsetUnits="MM" rotationUnit="AngleDegrees" centroidWhole="0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" overrunDistanceUnit="MM" distUnits="Pixel" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" geometryGeneratorEnabled="0" offsetType="0" maxCurvedCharAngleOut="-25" priority="5" fitInPolygonOnly="0" geometryGeneratorType="PointGeometry" overlapHandling="PreventOverlap" placement="0" lineAnchorTextPoint="CenterOfText" quadOffset="4" layerType="PointGeometry" distMapUnitScale="3x:0,0,0,0,0,0" xOffset="0" overrunDistance="0" dist="10"/>
            <rendering labelPerPart="0" mergeLines="0" scaleMin="0" scaleVisibility="0" fontLimitPixelSize="0" obstacleType="0" scaleMax="0" minFeatureSize="0" drawLabels="1" unplacedVisibility="0" limitNumLabels="0" upsidedownLabels="0" obstacle="1" maxNumLabels="2000" fontMinPixelSize="3" fontMaxPixelSize="10000" obstacleFactor="1" zIndex="0"/>
            <dd_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option name="anchorPoint" value="pole_of_inaccessibility" type="QString"/>
                <Option name="blendMode" value="0" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option name="name" value="" type="QString"/>
                  <Option name="properties"/>
                  <Option name="type" value="collection" type="QString"/>
                </Option>
                <Option name="drawToAllParts" value="false" type="bool"/>
                <Option name="enabled" value="0" type="QString"/>
                <Option name="labelAnchorPoint" value="point_on_exterior" type="QString"/>
                <Option name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; is_animated=&quot;0&quot; name=&quot;symbol&quot; force_rhr=&quot;0&quot; frame_rate=&quot;10&quot; type=&quot;line&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer id=&quot;{b1744910-f751-44fb-ba38-d6222a2e4fec}&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;align_dash_pattern&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;capstyle&quot; value=&quot;square&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash&quot; value=&quot;5;2&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;customdash_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;draw_inside_polygon&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;joinstyle&quot; value=&quot;bevel&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_color&quot; value=&quot;60,60,60,255&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_style&quot; value=&quot;solid&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width&quot; value=&quot;0.3&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;line_width_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;offset_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;ring_filter&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;use_custom_dash&quot; value=&quot;0&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option name=&quot;name&quot; value=&quot;&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option name=&quot;type&quot; value=&quot;collection&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" type="QString"/>
                <Option name="minLength" value="0" type="double"/>
                <Option name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="minLengthUnit" value="MM" type="QString"/>
                <Option name="offsetFromAnchor" value="0" type="double"/>
                <Option name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromAnchorUnit" value="MM" type="QString"/>
                <Option name="offsetFromLabel" value="0" type="double"/>
                <Option name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0" type="QString"/>
                <Option name="offsetFromLabelUnit" value="MM" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
      </rule>
    </rules>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option name="dualview/previewExpressions" type="StringList">
        <Option value="COALESCE( &quot;E_FNAME&quot;, '&lt;NULL>' )" type="QString"/>
      </Option>
      <Option name="embeddedWidgets/count" value="0" type="QString"/>
      <Option name="plugins/multilayerselect/excluded" value="true" type="bool"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer diagramType="Histogram" attributeLegend="1">
    <DiagramCategory penColor="#000000" barWidth="5" width="15" enabled="0" opacity="1" minimumSize="0" maxScaleDenominator="1e+08" penAlpha="255" sizeType="MM" spacingUnitScale="3x:0,0,0,0,0,0" scaleDependency="Area" labelPlacementMethod="XHeight" penWidth="0" minScaleDenominator="0" showAxis="0" sizeScale="3x:0,0,0,0,0,0" spacingUnit="MM" backgroundAlpha="255" backgroundColor="#ffffff" height="15" direction="1" spacing="0" lineSizeType="MM" lineSizeScale="3x:0,0,0,0,0,0" rotationOffset="270" scaleBasedVisibility="0" diagramOrientation="Up">
      <fontProperties underline="0" strikethrough="0" bold="0" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style="" italic="0"/>
      <attribute colorOpacity="1" field="" color="#000000" label=""/>
      <axisSymbol>
        <symbol clip_to_extent="1" alpha="1" is_animated="0" name="" force_rhr="0" frame_rate="10" type="line">
          <data_defined_properties>
            <Option type="Map">
              <Option name="name" value="" type="QString"/>
              <Option name="properties"/>
              <Option name="type" value="collection" type="QString"/>
            </Option>
          </data_defined_properties>
          <layer id="{206bc4e2-464a-4c34-97f4-f275382703a1}" locked="0" pass="0" class="SimpleLine" enabled="1">
            <Option type="Map">
              <Option name="align_dash_pattern" value="0" type="QString"/>
              <Option name="capstyle" value="square" type="QString"/>
              <Option name="customdash" value="5;2" type="QString"/>
              <Option name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="customdash_unit" value="MM" type="QString"/>
              <Option name="dash_pattern_offset" value="0" type="QString"/>
              <Option name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="dash_pattern_offset_unit" value="MM" type="QString"/>
              <Option name="draw_inside_polygon" value="0" type="QString"/>
              <Option name="joinstyle" value="bevel" type="QString"/>
              <Option name="line_color" value="35,35,35,255" type="QString"/>
              <Option name="line_style" value="solid" type="QString"/>
              <Option name="line_width" value="0.26" type="QString"/>
              <Option name="line_width_unit" value="MM" type="QString"/>
              <Option name="offset" value="0" type="QString"/>
              <Option name="offset_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="offset_unit" value="MM" type="QString"/>
              <Option name="ring_filter" value="0" type="QString"/>
              <Option name="trim_distance_end" value="0" type="QString"/>
              <Option name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="trim_distance_end_unit" value="MM" type="QString"/>
              <Option name="trim_distance_start" value="0" type="QString"/>
              <Option name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
              <Option name="trim_distance_start_unit" value="MM" type="QString"/>
              <Option name="tweak_dash_pattern_on_corners" value="0" type="QString"/>
              <Option name="use_custom_dash" value="0" type="QString"/>
              <Option name="width_map_unit_scale" value="3x:0,0,0,0,0,0" type="QString"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option name="name" value="" type="QString"/>
                <Option name="properties"/>
                <Option name="type" value="collection" type="QString"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings zIndex="0" placement="0" priority="0" obstacle="0" showAll="1" linePlacementFlags="2" dist="0">
    <properties>
      <Option type="Map">
        <Option name="name" value="" type="QString"/>
        <Option name="properties"/>
        <Option name="type" value="collection" type="QString"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field name="fid" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Art" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Art_Sonst" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Zustand" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="Bezeichner" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ID" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ID_Tech" configurationFlags="NoFlag">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="TE_ART_VOR" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="TE_V_SONST" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ID_BAU" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="KD_ANB_V" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ANZ_ANS_V" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="KD_ANB_G" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="ANZ_ANS_G" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="SENDE_GEOM" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="SENDE_BB" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="SI_ABST_XY" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="SI_ABST_Z" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MONT_Z" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MP_MBFD_CO" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="STRUCTURE_" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MP_DB_ID" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="MP_ID" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="SM_AUFTRAG" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field name="BEZ_OLD" configurationFlags="NoFlag">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="fid" name="" index="0"/>
    <alias field="Art" name="" index="1"/>
    <alias field="Art_Sonst" name="" index="2"/>
    <alias field="Zustand" name="" index="3"/>
    <alias field="Bezeichner" name="" index="4"/>
    <alias field="ID" name="" index="5"/>
    <alias field="ID_Tech" name="" index="6"/>
    <alias field="TE_ART_VOR" name="" index="7"/>
    <alias field="TE_V_SONST" name="" index="8"/>
    <alias field="ID_BAU" name="" index="9"/>
    <alias field="KD_ANB_V" name="" index="10"/>
    <alias field="ANZ_ANS_V" name="" index="11"/>
    <alias field="KD_ANB_G" name="" index="12"/>
    <alias field="ANZ_ANS_G" name="" index="13"/>
    <alias field="SENDE_GEOM" name="" index="14"/>
    <alias field="SENDE_BB" name="" index="15"/>
    <alias field="SI_ABST_XY" name="" index="16"/>
    <alias field="SI_ABST_Z" name="" index="17"/>
    <alias field="MONT_Z" name="" index="18"/>
    <alias field="MP_MBFD_CO" name="" index="19"/>
    <alias field="STRUCTURE_" name="" index="20"/>
    <alias field="MP_DB_ID" name="" index="21"/>
    <alias field="MP_ID" name="" index="22"/>
    <alias field="SM_AUFTRAG" name="" index="23"/>
    <alias field="BEZ_OLD" name="" index="24"/>
  </aliases>
  <splitPolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="Art"/>
    <policy policy="Duplicate" field="Art_Sonst"/>
    <policy policy="Duplicate" field="Zustand"/>
    <policy policy="Duplicate" field="Bezeichner"/>
    <policy policy="Duplicate" field="ID"/>
    <policy policy="Duplicate" field="ID_Tech"/>
    <policy policy="Duplicate" field="TE_ART_VOR"/>
    <policy policy="Duplicate" field="TE_V_SONST"/>
    <policy policy="Duplicate" field="ID_BAU"/>
    <policy policy="Duplicate" field="KD_ANB_V"/>
    <policy policy="Duplicate" field="ANZ_ANS_V"/>
    <policy policy="Duplicate" field="KD_ANB_G"/>
    <policy policy="Duplicate" field="ANZ_ANS_G"/>
    <policy policy="Duplicate" field="SENDE_GEOM"/>
    <policy policy="Duplicate" field="SENDE_BB"/>
    <policy policy="Duplicate" field="SI_ABST_XY"/>
    <policy policy="Duplicate" field="SI_ABST_Z"/>
    <policy policy="Duplicate" field="MONT_Z"/>
    <policy policy="Duplicate" field="MP_MBFD_CO"/>
    <policy policy="Duplicate" field="STRUCTURE_"/>
    <policy policy="Duplicate" field="MP_DB_ID"/>
    <policy policy="Duplicate" field="MP_ID"/>
    <policy policy="Duplicate" field="SM_AUFTRAG"/>
    <policy policy="Duplicate" field="BEZ_OLD"/>
  </splitPolicies>
  <defaults>
    <default applyOnUpdate="0" field="fid" expression=""/>
    <default applyOnUpdate="0" field="Art" expression=""/>
    <default applyOnUpdate="0" field="Art_Sonst" expression=""/>
    <default applyOnUpdate="0" field="Zustand" expression=""/>
    <default applyOnUpdate="0" field="Bezeichner" expression=""/>
    <default applyOnUpdate="0" field="ID" expression=""/>
    <default applyOnUpdate="0" field="ID_Tech" expression=""/>
    <default applyOnUpdate="0" field="TE_ART_VOR" expression=""/>
    <default applyOnUpdate="0" field="TE_V_SONST" expression=""/>
    <default applyOnUpdate="0" field="ID_BAU" expression=""/>
    <default applyOnUpdate="0" field="KD_ANB_V" expression=""/>
    <default applyOnUpdate="0" field="ANZ_ANS_V" expression=""/>
    <default applyOnUpdate="0" field="KD_ANB_G" expression=""/>
    <default applyOnUpdate="0" field="ANZ_ANS_G" expression=""/>
    <default applyOnUpdate="0" field="SENDE_GEOM" expression=""/>
    <default applyOnUpdate="0" field="SENDE_BB" expression=""/>
    <default applyOnUpdate="0" field="SI_ABST_XY" expression=""/>
    <default applyOnUpdate="0" field="SI_ABST_Z" expression=""/>
    <default applyOnUpdate="0" field="MONT_Z" expression=""/>
    <default applyOnUpdate="0" field="MP_MBFD_CO" expression=""/>
    <default applyOnUpdate="0" field="STRUCTURE_" expression=""/>
    <default applyOnUpdate="0" field="MP_DB_ID" expression=""/>
    <default applyOnUpdate="0" field="MP_ID" expression=""/>
    <default applyOnUpdate="0" field="SM_AUFTRAG" expression=""/>
    <default applyOnUpdate="0" field="BEZ_OLD" expression=""/>
  </defaults>
  <constraints>
    <constraint constraints="3" field="fid" notnull_strength="1" unique_strength="1" exp_strength="0"/>
    <constraint constraints="0" field="Art" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="Art_Sonst" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="Zustand" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="Bezeichner" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="ID" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="ID_Tech" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="TE_ART_VOR" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="TE_V_SONST" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="ID_BAU" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="KD_ANB_V" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="ANZ_ANS_V" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="KD_ANB_G" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="ANZ_ANS_G" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="SENDE_GEOM" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="SENDE_BB" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="SI_ABST_XY" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="SI_ABST_Z" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="MONT_Z" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="MP_MBFD_CO" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="STRUCTURE_" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="MP_DB_ID" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="MP_ID" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="SM_AUFTRAG" notnull_strength="0" unique_strength="0" exp_strength="0"/>
    <constraint constraints="0" field="BEZ_OLD" notnull_strength="0" unique_strength="0" exp_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" exp="" field="fid"/>
    <constraint desc="" exp="" field="Art"/>
    <constraint desc="" exp="" field="Art_Sonst"/>
    <constraint desc="" exp="" field="Zustand"/>
    <constraint desc="" exp="" field="Bezeichner"/>
    <constraint desc="" exp="" field="ID"/>
    <constraint desc="" exp="" field="ID_Tech"/>
    <constraint desc="" exp="" field="TE_ART_VOR"/>
    <constraint desc="" exp="" field="TE_V_SONST"/>
    <constraint desc="" exp="" field="ID_BAU"/>
    <constraint desc="" exp="" field="KD_ANB_V"/>
    <constraint desc="" exp="" field="ANZ_ANS_V"/>
    <constraint desc="" exp="" field="KD_ANB_G"/>
    <constraint desc="" exp="" field="ANZ_ANS_G"/>
    <constraint desc="" exp="" field="SENDE_GEOM"/>
    <constraint desc="" exp="" field="SENDE_BB"/>
    <constraint desc="" exp="" field="SI_ABST_XY"/>
    <constraint desc="" exp="" field="SI_ABST_Z"/>
    <constraint desc="" exp="" field="MONT_Z"/>
    <constraint desc="" exp="" field="MP_MBFD_CO"/>
    <constraint desc="" exp="" field="STRUCTURE_"/>
    <constraint desc="" exp="" field="MP_DB_ID"/>
    <constraint desc="" exp="" field="MP_ID"/>
    <constraint desc="" exp="" field="SM_AUFTRAG"/>
    <constraint desc="" exp="" field="BEZ_OLD"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig sortExpression="&quot;Art_Sonst&quot;" sortOrder="1" actionWidgetStyle="dropDown">
    <columns>
      <column hidden="0" name="fid" width="-1" type="field"/>
      <column hidden="0" name="ID" width="-1" type="field"/>
      <column hidden="1" width="-1" type="actions"/>
      <column hidden="1" name="MP_DB_ID" width="-1" type="field"/>
      <column hidden="1" name="MP_ID" width="-1" type="field"/>
      <column hidden="1" name="TE_ART_VOR" width="-1" type="field"/>
      <column hidden="1" name="TE_V_SONST" width="-1" type="field"/>
      <column hidden="1" name="ID_BAU" width="-1" type="field"/>
      <column hidden="1" name="KD_ANB_V" width="-1" type="field"/>
      <column hidden="1" name="ANZ_ANS_V" width="-1" type="field"/>
      <column hidden="1" name="KD_ANB_G" width="-1" type="field"/>
      <column hidden="1" name="ANZ_ANS_G" width="-1" type="field"/>
      <column hidden="1" name="SENDE_GEOM" width="-1" type="field"/>
      <column hidden="1" name="SENDE_BB" width="-1" type="field"/>
      <column hidden="1" name="SI_ABST_XY" width="-1" type="field"/>
      <column hidden="1" name="SI_ABST_Z" width="-1" type="field"/>
      <column hidden="1" name="MONT_Z" width="-1" type="field"/>
      <column hidden="1" name="MP_MBFD_CO" width="-1" type="field"/>
      <column hidden="1" name="STRUCTURE_" width="-1" type="field"/>
      <column hidden="0" name="Art" width="-1" type="field"/>
      <column hidden="0" name="Art_Sonst" width="186" type="field"/>
      <column hidden="0" name="Zustand" width="-1" type="field"/>
      <column hidden="0" name="Bezeichner" width="-1" type="field"/>
      <column hidden="0" name="ID_Tech" width="-1" type="field"/>
      <column hidden="1" name="BEZ_OLD" width="-1" type="field"/>
      <column hidden="1" name="SM_AUFTRAG" width="-1" type="field"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1">C:/Users/A754221/OneDrive - Deutsche Telekom AG/Desktop/QGIS 3.10/bin</editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath>C:/Users/A754221/OneDrive - Deutsche Telekom AG/Desktop/QGIS 3.10/bin</editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <attributeEditorForm>
    <labelStyle overrideLabelColor="0" overrideLabelFont="0" labelColor="0,0,0,255">
      <labelFont underline="0" strikethrough="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" style="" italic="0"/>
    </labelStyle>
    <attributeEditorField verticalStretch="0" horizontalStretch="0" name="ID" showLabel="1" index="5">
      <labelStyle overrideLabelColor="0" overrideLabelFont="0" labelColor="0,0,0,255">
        <labelFont underline="0" strikethrough="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" style="" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField verticalStretch="0" horizontalStretch="0" name="ID_Tech" showLabel="1" index="6">
      <labelStyle overrideLabelColor="0" overrideLabelFont="0" labelColor="0,0,0,255">
        <labelFont underline="0" strikethrough="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" style="" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField verticalStretch="0" horizontalStretch="0" name="Art" showLabel="1" index="1">
      <labelStyle overrideLabelColor="0" overrideLabelFont="0" labelColor="0,0,0,255">
        <labelFont underline="0" strikethrough="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" style="" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField verticalStretch="0" horizontalStretch="0" name="Art_Sonst" showLabel="1" index="2">
      <labelStyle overrideLabelColor="0" overrideLabelFont="0" labelColor="0,0,0,255">
        <labelFont underline="0" strikethrough="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" style="" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField verticalStretch="0" horizontalStretch="0" name="Zustand" showLabel="1" index="3">
      <labelStyle overrideLabelColor="0" overrideLabelFont="0" labelColor="0,0,0,255">
        <labelFont underline="0" strikethrough="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" style="" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField verticalStretch="0" horizontalStretch="0" name="Bezeichner" showLabel="1" index="4">
      <labelStyle overrideLabelColor="0" overrideLabelFont="0" labelColor="0,0,0,255">
        <labelFont underline="0" strikethrough="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" style="" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField verticalStretch="0" horizontalStretch="0" name="Te_Art_Gep" showLabel="1" index="-1">
      <labelStyle overrideLabelColor="0" overrideLabelFont="0" labelColor="0,0,0,255">
        <labelFont underline="0" strikethrough="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" style="" italic="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField verticalStretch="0" horizontalStretch="0" name="Te_G_Sonst" showLabel="1" index="-1">
      <labelStyle overrideLabelColor="0" overrideLabelFont="0" labelColor="0,0,0,255">
        <labelFont underline="0" strikethrough="0" bold="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" style="" italic="0"/>
      </labelStyle>
    </attributeEditorField>
  </attributeEditorForm>
  <editable>
    <field editable="1" name="ANZ_ANS_G"/>
    <field editable="1" name="ANZ_ANS_V"/>
    <field editable="1" name="ART"/>
    <field editable="1" name="ART_NT"/>
    <field editable="1" name="ART_SONST"/>
    <field editable="1" name="A_E_MAIL"/>
    <field editable="1" name="A_TEL"/>
    <field editable="1" name="A_VNAME"/>
    <field editable="1" name="A_ZNAME"/>
    <field editable="1" name="Art"/>
    <field editable="1" name="Art_Sonst"/>
    <field editable="1" name="BEZEICHNER"/>
    <field editable="1" name="BEZEICHNUN"/>
    <field editable="1" name="BEZ_OLD"/>
    <field editable="1" name="Bezeichner"/>
    <field editable="1" name="ELER"/>
    <field editable="1" name="E_E_MAIL"/>
    <field editable="1" name="E_FNAME"/>
    <field editable="1" name="E_ORT"/>
    <field editable="1" name="E_TEL"/>
    <field editable="1" name="GID"/>
    <field editable="1" name="ID"/>
    <field editable="1" name="ID_BAU"/>
    <field editable="1" name="ID_TECH"/>
    <field editable="1" name="ID_Tech"/>
    <field editable="1" name="KD_ANB_G"/>
    <field editable="1" name="KD_ANB_V"/>
    <field editable="1" name="MONT_Z"/>
    <field editable="1" name="MP_DB_ID"/>
    <field editable="1" name="MP_ID"/>
    <field editable="1" name="MP_MBFD_CO"/>
    <field editable="1" name="NT_SONST"/>
    <field editable="1" name="ONB_NUMMER"/>
    <field editable="1" name="SENDE_BB"/>
    <field editable="1" name="SENDE_GEOM"/>
    <field editable="1" name="SI_ABST_XY"/>
    <field editable="1" name="SI_ABST_Z"/>
    <field editable="1" name="SM_AUFTRAG"/>
    <field editable="1" name="STRUCTURE_"/>
    <field editable="1" name="TE_ART_GEP"/>
    <field editable="1" name="TE_ART_VOR"/>
    <field editable="1" name="TE_G_SONST"/>
    <field editable="1" name="TE_V_SONST"/>
    <field editable="1" name="ZUSTAND"/>
    <field editable="1" name="Zustand"/>
    <field editable="1" name="debug_errors"/>
    <field editable="1" name="fid"/>
    <field editable="1" name="loeschen"/>
  </editable>
  <labelOnTop>
    <field name="ANZ_ANS_G" labelOnTop="0"/>
    <field name="ANZ_ANS_V" labelOnTop="0"/>
    <field name="ART" labelOnTop="0"/>
    <field name="ART_NT" labelOnTop="0"/>
    <field name="ART_SONST" labelOnTop="0"/>
    <field name="A_E_MAIL" labelOnTop="0"/>
    <field name="A_TEL" labelOnTop="0"/>
    <field name="A_VNAME" labelOnTop="0"/>
    <field name="A_ZNAME" labelOnTop="0"/>
    <field name="Art" labelOnTop="0"/>
    <field name="Art_Sonst" labelOnTop="0"/>
    <field name="BEZEICHNER" labelOnTop="0"/>
    <field name="BEZEICHNUN" labelOnTop="0"/>
    <field name="BEZ_OLD" labelOnTop="0"/>
    <field name="Bezeichner" labelOnTop="0"/>
    <field name="ELER" labelOnTop="0"/>
    <field name="E_E_MAIL" labelOnTop="0"/>
    <field name="E_FNAME" labelOnTop="0"/>
    <field name="E_ORT" labelOnTop="0"/>
    <field name="E_TEL" labelOnTop="0"/>
    <field name="GID" labelOnTop="0"/>
    <field name="ID" labelOnTop="0"/>
    <field name="ID_BAU" labelOnTop="0"/>
    <field name="ID_TECH" labelOnTop="0"/>
    <field name="ID_Tech" labelOnTop="0"/>
    <field name="KD_ANB_G" labelOnTop="0"/>
    <field name="KD_ANB_V" labelOnTop="0"/>
    <field name="MONT_Z" labelOnTop="0"/>
    <field name="MP_DB_ID" labelOnTop="0"/>
    <field name="MP_ID" labelOnTop="0"/>
    <field name="MP_MBFD_CO" labelOnTop="0"/>
    <field name="NT_SONST" labelOnTop="0"/>
    <field name="ONB_NUMMER" labelOnTop="0"/>
    <field name="SENDE_BB" labelOnTop="0"/>
    <field name="SENDE_GEOM" labelOnTop="0"/>
    <field name="SI_ABST_XY" labelOnTop="0"/>
    <field name="SI_ABST_Z" labelOnTop="0"/>
    <field name="SM_AUFTRAG" labelOnTop="0"/>
    <field name="STRUCTURE_" labelOnTop="0"/>
    <field name="TE_ART_GEP" labelOnTop="0"/>
    <field name="TE_ART_VOR" labelOnTop="0"/>
    <field name="TE_G_SONST" labelOnTop="0"/>
    <field name="TE_V_SONST" labelOnTop="0"/>
    <field name="ZUSTAND" labelOnTop="0"/>
    <field name="Zustand" labelOnTop="0"/>
    <field name="debug_errors" labelOnTop="0"/>
    <field name="fid" labelOnTop="0"/>
    <field name="loeschen" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="ANZ_ANS_G"/>
    <field reuseLastValue="0" name="ANZ_ANS_V"/>
    <field reuseLastValue="0" name="ART_NT"/>
    <field reuseLastValue="0" name="A_E_MAIL"/>
    <field reuseLastValue="0" name="A_TEL"/>
    <field reuseLastValue="0" name="A_VNAME"/>
    <field reuseLastValue="0" name="A_ZNAME"/>
    <field reuseLastValue="0" name="Art"/>
    <field reuseLastValue="0" name="Art_Sonst"/>
    <field reuseLastValue="0" name="BEZEICHNER"/>
    <field reuseLastValue="0" name="BEZEICHNUN"/>
    <field reuseLastValue="0" name="BEZ_OLD"/>
    <field reuseLastValue="0" name="Bezeichner"/>
    <field reuseLastValue="0" name="E_E_MAIL"/>
    <field reuseLastValue="0" name="E_FNAME"/>
    <field reuseLastValue="0" name="E_ORT"/>
    <field reuseLastValue="0" name="E_TEL"/>
    <field reuseLastValue="0" name="ID"/>
    <field reuseLastValue="0" name="ID_BAU"/>
    <field reuseLastValue="0" name="ID_TECH"/>
    <field reuseLastValue="0" name="ID_Tech"/>
    <field reuseLastValue="0" name="KD_ANB_G"/>
    <field reuseLastValue="0" name="KD_ANB_V"/>
    <field reuseLastValue="0" name="MONT_Z"/>
    <field reuseLastValue="0" name="MP_DB_ID"/>
    <field reuseLastValue="0" name="MP_ID"/>
    <field reuseLastValue="0" name="MP_MBFD_CO"/>
    <field reuseLastValue="0" name="NT_SONST"/>
    <field reuseLastValue="0" name="ONB_NUMMER"/>
    <field reuseLastValue="0" name="SENDE_BB"/>
    <field reuseLastValue="0" name="SENDE_GEOM"/>
    <field reuseLastValue="0" name="SI_ABST_XY"/>
    <field reuseLastValue="0" name="SI_ABST_Z"/>
    <field reuseLastValue="0" name="SM_AUFTRAG"/>
    <field reuseLastValue="0" name="STRUCTURE_"/>
    <field reuseLastValue="0" name="TE_ART_GEP"/>
    <field reuseLastValue="0" name="TE_ART_VOR"/>
    <field reuseLastValue="0" name="TE_G_SONST"/>
    <field reuseLastValue="0" name="TE_V_SONST"/>
    <field reuseLastValue="0" name="ZUSTAND"/>
    <field reuseLastValue="0" name="Zustand"/>
    <field reuseLastValue="0" name="fid"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>COALESCE( "E_FNAME", '&lt;NULL>' )</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>

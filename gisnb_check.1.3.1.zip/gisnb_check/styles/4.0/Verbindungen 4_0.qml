<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis hasScaleBasedVisibilityFlag="0" version="3.22.16-Białowieża" styleCategories="AllStyleCategories" symbologyReferenceScale="-1" maxScale="0" simplifyLocal="1" minScale="100000000" readOnly="0" labelsEnabled="1" simplifyDrawingHints="1" simplifyAlgorithm="0" simplifyMaxScale="1" simplifyDrawingTol="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endField="" mode="0" startExpression="" fixedDuration="0" enabled="0" endExpression="" accumulate="0" startField="" durationUnit="min" limitMode="0" durationField="">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <renderer-v2 enableorderby="0" referencescale="-1" type="RuleRenderer" forceraster="0" symbollevels="1">
    <rules key="{25a1cd1a-8e15-44e8-8aa2-8c2503d5288d}">
      <rule key="{449a9c95-6af4-4724-bce5-250cb466f365}" label="Struktur">
        <rule filter="&quot;VERB_ART&quot; IN (5,6,7,8,9,10,11,99)" key="{62e1dfb1-18c3-4478-89d3-7778dd876e9c}" label="Gf-Kabel">
          <rule filter=" &quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' OR &quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )" key="{6699a01a-70be-42df-8acb-53977391dc5e}" label="Gf-Kabel u.i.">
            <rule filter="&quot;ZUSTAND&quot; = 1" key="{88b3198b-532a-4091-8fe2-1389866f7f17}" symbol="0" label="Gf-Kabel u.i. neu"/>
            <rule filter="&quot;ZUSTAND&quot; = 2" key="{31ea56d7-bcb9-43a2-8973-1e24ae4bb1a4}" symbol="1" label="Gf-Kabel u.i. Bestand"/>
          </rule>
          <rule filter="&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%'" key="{5dfc6b00-a713-4a45-9c36-c8dcf688de58}" label="Gf-Kabel o.i.">
            <rule filter="&quot;ZUSTAND&quot; = 1" key="{29dd56ce-1121-4ef0-bd08-73bab0c17aee}" symbol="2" label="Gf-Kabel o.i. neu"/>
            <rule filter="&quot;ZUSTAND&quot; = 2" key="{87aa018e-abd8-4a67-b94b-57f7115b3754}" symbol="3" label="Gf-Kabel o.i. Bestand"/>
          </rule>
        </rule>
        <rule filter="&quot;VERB_ART&quot; = 1" key="{a7573130-4a04-43b0-924d-52b613210ee0}" label="Cu-Kabel">
          <rule filter=" &quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )" key="{a3409e7b-7041-474b-8fc8-6e4aa14204e5}" label="Cu-Kabel u.i.">
            <rule filter="&quot;ZUSTAND&quot; = 1" key="{442ce49f-5eb8-44ea-aefb-ae7e023c7363}" symbol="4" label="Cu-Kabel u.i. in neu"/>
            <rule filter="&quot;ZUSTAND&quot; = 2" key="{ca608f35-36fe-45ae-9e0c-bd7a90ccce10}" symbol="5" label="Cu-Kabel u.i. in Bestand"/>
          </rule>
          <rule filter="&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%'" key="{23856506-c018-43a4-9f96-4b8bf313f5e8}" label="Cu-Kabel o.i.">
            <rule filter="&quot;ZUSTAND&quot; = 1" key="{0f52aca9-e54d-4814-ac86-e11c119e1e52}" symbol="6" label="Cu-Kabel o.i. neu"/>
            <rule filter="&quot;ZUSTAND&quot; = 2" key="{17509443-fb1e-4f18-a4f4-ace95c3966c3}" symbol="7" label="Cu-Kabel o.i. Bestand"/>
          </rule>
        </rule>
        <rule filter="&quot;VERB_ART&quot; = 99 AND (&quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )" key="{7384fc44-28db-424f-93e4-6a1041e303f2}" label="FSP-Kabel">
          <rule filter="&quot;ZUSTAND&quot; = 1 " key="{b5f680ec-12bc-4deb-b4f0-afdb73a27fa0}" symbol="8" label="FSP-Kabel in neu"/>
          <rule filter="&quot;ZUSTAND&quot; = 2" key="{44045546-713a-45de-a98a-5c40d4dd8ccb}" symbol="9" label="FSP-Kabel in Bestand"/>
        </rule>
        <rule filter="&quot;VERB_ART&quot; = 2" key="{00db33c4-74e7-4dee-adbd-aeb3e0c448ff}" symbol="10" label="&quot;VERB_ART&quot; 2 > korrigieren"/>
      </rule>
      <rule checkstate="0" key="{800d2046-1cd7-4cec-82b1-b1820fe69afa}" symbol="11" label="alle Kabel"/>
      <rule checkstate="0" key="{349379fc-5856-4f38-94aa-93b43f1b2411}" label="Prüfung">
        <rule filter=" &quot;VERB_ART&quot; NOT IN (1,5,6,7,8,9,10,11,99)" checkstate="0" key="{a49bdf4c-743c-49a1-8a65-bd2754603254}" symbol="12" label="Verb_Art unplausibel"/>
        <rule filter="&quot;Verb_Art&quot; IS NOT 1 AND ((&quot;Verb_Art&quot; != 5 AND &quot;Anzahl_F_A&quot; = 6) OR (&quot;Verb_Art&quot; != 6 AND &quot;Anzahl_F_A&quot; = 12) OR (&quot;Verb_Art&quot; != 7 AND &quot;Anzahl_F_A&quot; = 24) OR (&quot;Verb_Art&quot; != 8 AND &quot;Anzahl_F_A&quot; = 48) OR (&quot;Verb_Art&quot; != 9 AND &quot;Anzahl_F_A&quot; = 72) OR (&quot;Verb_Art&quot; != 10 AND &quot;Anzahl_F_A&quot; = 96) OR (&quot;Verb_Art&quot; != 11 AND &quot;Anzahl_F_A&quot; = 144)) OR ((&quot;Verb_Art&quot; = 5 AND &quot;Anzahl_F_A&quot; != 6) OR (&quot;Verb_Art&quot; = 6 AND &quot;Anzahl_F_A&quot; != 12) OR (&quot;Verb_Art&quot; = 7 AND &quot;Anzahl_F_A&quot; != 24) OR (&quot;Verb_Art&quot; = 8 AND &quot;Anzahl_F_A&quot; != 48) OR (&quot;Verb_Art&quot; = 9 AND &quot;Anzahl_F_A&quot; != 72) OR (&quot;Verb_Art&quot; = 10 AND &quot;Anzahl_F_A&quot; != 96) OR (&quot;Verb_Art&quot; = 11 AND &quot;Anzahl_F_A&quot; != 144))" checkstate="0" key="{715c05cc-a471-4d3e-9b18-03910ed20172}" symbol="13" label="Gf: Anzahl_F_A entspricht nicht Verb_ Art"/>
        <rule filter="((&quot;Verb_Art&quot; = 1 AND &quot;Anzahl_F_A&quot; NOT IN (2,10,20,30,40,50,70,100,150,200,250,300,500,1000))) OR ((&quot;Verb_Art&quot; != 1 AND &quot;Anzahl_F_A&quot; IN (2,10,20,30,40,50,70,100,150,200,250,300,500,1000))) AND NOT (&quot;VERB_ART&quot; = 99 AND (&quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%'))" checkstate="0" key="{22d38f42-194a-4346-bbe7-52ce15a2e5ea}" symbol="14" label="Cu: Anzahl_F_A entspricht nicht Verb_ Art"/>
        <rule filter=" &quot;F_A_RESERV&quot; >= &quot;ANZAHL_F_A&quot; " checkstate="0" key="{2d01a9e0-fd35-4f38-9793-717977ecb149}" symbol="15" label="F_A_Reserve größer od. gleich ANZAHL_F_A"/>
        <rule filter=" &quot;F_A_RESERV&quot; &lt; 0" checkstate="0" key="{4c243821-e8ab-4700-9936-2a7d615038ff}" symbol="16" label="F_A_Reserve kleiner 0"/>
        <rule filter=" &quot;ZUSTAND&quot; = 2 AND  &quot;F_A_RESERV&quot;  != 0" checkstate="0" key="{f79bf7a4-1276-4c17-abbd-b8b71418ed3e}" symbol="17" label="F_A_Reserve bei Bestand nicht  '0'"/>
        <rule filter=" &quot;Verb_Art&quot; != 1 AND &quot;ZUSTAND&quot; = 1 AND  &quot;F_A_RESERV&quot; = 0" checkstate="0" key="{34748ed0-af2c-4b4f-ad81-61d1d828452a}" symbol="18" label="Wirklich F_A_Reserve bei neu = '0'?"/>
        <rule filter=" &quot;Verb_Art&quot; IS NULL OR &quot;Lae_Kabel&quot; IS NULL OR &quot;Anzahl_F_A&quot; IS NULL OR &quot;F_A_Reserv&quot; IS NULL OR &quot;Zustand&quot; IS NULL" checkstate="0" key="{5f67dee0-aa9f-4edf-9990-cbf46058a469}" symbol="19" label="Fehlende Attribute"/>
      </rule>
    </rules>
    <symbols>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="0">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="7" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="1"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="255,0,0,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="1" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="73,190,253,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="73,190,253,255" k="single_color"/>
              <prop v="1" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="0.146"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="0.146" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.386"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="253,253,253,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.386" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="253,253,253,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="7" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="73,190,253,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="square" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="73,190,253,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="6" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="0,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="0,0,0,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="6" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="73,190,253,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="73,190,253,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="10">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="12" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="163,3,255,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="1.36" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.466" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,0,0,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,255,255,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="12" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,187,5,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.985641" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="11">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="12" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="163,3,255,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="1.36" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="12" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,187,5,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.985641" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="12">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="12" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="163,3,255,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="1.36" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.466" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,0,0,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,255,255,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="12" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,187,5,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.985641" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="13">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="12" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="163,3,255,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="1.36" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.466" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,0,0,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,255,255,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="12" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,187,5,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.985641" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="14">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="12" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="163,3,255,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="1.36" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.466" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,0,0,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,255,255,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="12" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,187,5,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.985641" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="15">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="12" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="163,3,255,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="1.36" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.466" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,0,0,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,255,255,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="12" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,187,5,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.985641" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="16">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="12" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="163,3,255,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="1.36" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.466" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,0,0,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,255,255,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="12" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,187,5,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.985641" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="17">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="12" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="163,3,255,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="1.36" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.466" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,0,0,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,255,255,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="12" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,187,5,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.985641" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="18">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="12" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="163,3,255,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="1.36" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.466" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,0,0,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,255,255,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="12" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,187,5,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.985641" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="19">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="12" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="163,3,255,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="1.36"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="163,3,255,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="1.36" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.466"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,0,0,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.466" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,0,0,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,255,255,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="12" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.985641"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,187,5,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.985641" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="2">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="11" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="1"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="255,0,0,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="1" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="73,190,253,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="73,190,253,255" k="single_color"/>
              <prop v="1" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="0.146"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="0.146" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.386"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="253,253,253,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.386" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="253,253,253,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="11" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="150,28,150,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="square" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="150,28,150,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="3">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="10" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="0,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="1"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="0,0,0,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="1" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="239,0,4,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="239,0,4,255" k="single_color"/>
              <prop v="1" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="0.146"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="0.146" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.386"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="253,253,253,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.386" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="253,253,253,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="10" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="236,82,239,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.504"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="square" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="236,82,239,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.504" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="4">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="5" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="255,0,0,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="239,0,4,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="239,0,4,255" k="single_color"/>
              <prop v="1" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,255,255,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="5" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,187,5,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="5">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="4" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="0,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="0,0,0,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="4" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,187,5,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,187,5,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="6">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="9" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="1"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="255,0,0,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="1" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="0,239,39,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="0,239,39,255" k="single_color"/>
              <prop v="1" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="0.146"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="0.146" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.386"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="253,253,253,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.386" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="253,253,253,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="9" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,239,39,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="square" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="0,239,39,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="7">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="8" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="0,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="1"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="0,0,0,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="1" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="239,0,4,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="239,0,4,255" k="single_color"/>
              <prop v="1" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="0.146"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="0.146" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.386"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="253,253,253,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.386" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="253,253,253,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="8" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="square"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="0,239,39,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="square" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="0,239,39,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="8">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="3" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="255,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="255,0,0,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="239,0,4,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="239,0,4,255" k="single_color"/>
              <prop v="1" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,255,255,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="3" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,238,27,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,238,27,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="9">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" name="name" value=""/>
            <Option name="properties"/>
            <Option type="QString" name="type" value="collection"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" class="SimpleLine" pass="2" locked="0">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="round"/>
            <Option type="QString" name="line_color" value="0,0,0,255"/>
            <Option type="QString" name="line_style" value="solid"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="round" k="joinstyle"/>
          <prop v="0,0,0,255" k="line_color"/>
          <prop v="solid" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="239,0,4,255"/>
                <Option type="QString" name="spread" value="1"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="239,0,4,255" k="single_color"/>
              <prop v="1" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="1"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="2" k="draw_mode"/>
              <prop v="1" k="enabled"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="13"/>
                <Option type="QString" name="blur_level" value="2.645"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color" value="0,0,0,255"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="offset_angle" value="135"/>
                <Option type="QString" name="offset_distance" value="2"/>
                <Option type="QString" name="offset_unit" value="MM"/>
                <Option type="QString" name="offset_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="opacity" value="1"/>
              </Option>
              <prop v="13" k="blend_mode"/>
              <prop v="2.645" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,0,255" k="color"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="135" k="offset_angle"/>
              <prop v="2" k="offset_distance"/>
              <prop v="MM" k="offset_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="offset_unit_scale"/>
              <prop v="1" k="opacity"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" name="blend_mode" value="0"/>
                <Option type="QString" name="blur_level" value="0.7935"/>
                <Option type="QString" name="blur_unit" value="MM"/>
                <Option type="QString" name="blur_unit_scale" value="3x:0,0,0,0,0,0"/>
                <Option type="QString" name="color1" value="0,0,255,255"/>
                <Option type="QString" name="color2" value="0,255,0,255"/>
                <Option type="QString" name="color_type" value="0"/>
                <Option type="QString" name="discrete" value="0"/>
                <Option type="QString" name="draw_mode" value="2"/>
                <Option type="QString" name="enabled" value="0"/>
                <Option type="QString" name="opacity" value="0.5"/>
                <Option type="QString" name="rampType" value="gradient"/>
                <Option type="QString" name="single_color" value="255,255,255,255"/>
                <Option type="QString" name="spread" value="2"/>
                <Option type="QString" name="spread_unit" value="MM"/>
                <Option type="QString" name="spread_unit_scale" value="3x:0,0,0,0,0,0"/>
              </Option>
              <prop v="0" k="blend_mode"/>
              <prop v="0.7935" k="blur_level"/>
              <prop v="MM" k="blur_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="blur_unit_scale"/>
              <prop v="0,0,255,255" k="color1"/>
              <prop v="0,255,0,255" k="color2"/>
              <prop v="0" k="color_type"/>
              <prop v="0" k="discrete"/>
              <prop v="2" k="draw_mode"/>
              <prop v="0" k="enabled"/>
              <prop v="0.5" k="opacity"/>
              <prop v="gradient" k="rampType"/>
              <prop v="255,255,255,255" k="single_color"/>
              <prop v="2" k="spread"/>
              <prop v="MM" k="spread_unit"/>
              <prop v="3x:0,0,0,0,0,0" k="spread_unit_scale"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" class="SimpleLine" pass="2" locked="1">
          <Option type="Map">
            <Option type="QString" name="align_dash_pattern" value="0"/>
            <Option type="QString" name="capstyle" value="round"/>
            <Option type="QString" name="customdash" value="5;2"/>
            <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="customdash_unit" value="MM"/>
            <Option type="QString" name="dash_pattern_offset" value="0"/>
            <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
            <Option type="QString" name="draw_inside_polygon" value="0"/>
            <Option type="QString" name="joinstyle" value="bevel"/>
            <Option type="QString" name="line_color" value="253,238,27,255"/>
            <Option type="QString" name="line_style" value="dot"/>
            <Option type="QString" name="line_width" value="0.7"/>
            <Option type="QString" name="line_width_unit" value="MM"/>
            <Option type="QString" name="offset" value="0"/>
            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="offset_unit" value="MM"/>
            <Option type="QString" name="ring_filter" value="0"/>
            <Option type="QString" name="trim_distance_end" value="0"/>
            <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_end_unit" value="MM"/>
            <Option type="QString" name="trim_distance_start" value="0"/>
            <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            <Option type="QString" name="trim_distance_start_unit" value="MM"/>
            <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
            <Option type="QString" name="use_custom_dash" value="0"/>
            <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
          </Option>
          <prop v="0" k="align_dash_pattern"/>
          <prop v="round" k="capstyle"/>
          <prop v="5;2" k="customdash"/>
          <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
          <prop v="MM" k="customdash_unit"/>
          <prop v="0" k="dash_pattern_offset"/>
          <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
          <prop v="MM" k="dash_pattern_offset_unit"/>
          <prop v="0" k="draw_inside_polygon"/>
          <prop v="bevel" k="joinstyle"/>
          <prop v="253,238,27,255" k="line_color"/>
          <prop v="dot" k="line_style"/>
          <prop v="0.7" k="line_width"/>
          <prop v="MM" k="line_width_unit"/>
          <prop v="0" k="offset"/>
          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
          <prop v="MM" k="offset_unit"/>
          <prop v="0" k="ring_filter"/>
          <prop v="0" k="trim_distance_end"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
          <prop v="MM" k="trim_distance_end_unit"/>
          <prop v="0" k="trim_distance_start"/>
          <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
          <prop v="MM" k="trim_distance_start_unit"/>
          <prop v="0" k="tweak_dash_pattern_on_corners"/>
          <prop v="0" k="use_custom_dash"/>
          <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <labeling type="rule-based">
    <rules key="{a9df8b5f-3321-4c13-beae-ff0177e10f31}">
      <rule filter="1" key="{919d09cb-f377-46eb-8e2d-424076c41139}" description="ohne Reserve">
        <rule filter="&quot;VERB_ART&quot; IN (5,6,7,8,9,10,11,99)" key="{7760eee1-5159-44b4-b09d-6572a746b8fc}" scalemindenom="1" scalemaxdenom="4000" description="Gf-Kabel">
          <rule key="{6638cc39-5f22-4afd-8acc-140c31cb1c87}" description="u.i.">
            <rule filter="(&quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' OR &quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )) AND NOT (&quot;bezeichnung&quot; IS NULL)" key="{22cbce83-58c7-4c43-ba1a-87f2a2a9ac04}" description="Bezeichnung ist vorhanden">
              <rule filter="&quot;ZUSTAND&quot; = 1" key="{ad06c964-7681-4dcc-8600-d4372fc2ea9f}" description="Gf-Kabel u.i. neu">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  FS ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="0,0,0,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="255,206,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="190,207,80,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="190,207,80,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="255,206,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="255,206,255,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule filter="&quot;ZUSTAND&quot; = 2" key="{4713ad3b-da56-4682-ba3b-8c80b66b4c0e}" description="Gf-Kabel u.i. Bestand">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  FS ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="Point" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="152,125,183,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="152,125,183,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="0,0,0,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
            <rule filter="(&quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' OR &quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )) AND (&quot;bezeichnung&quot; IS NULL)" key="{6a3dcd37-b5ed-42cf-a5ea-66477fc2513c}" description="Bezeichnung is NULL">
              <rule filter="&quot;ZUSTAND&quot; = 1" key="{62edcb6c-2ee7-44cd-80aa-02fc972ea059}" description="Gf-Kabel u.i. neu">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  FS '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="0,0,0,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="255,206,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="190,207,80,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="190,207,80,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="255,206,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="255,206,255,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule filter="&quot;ZUSTAND&quot; = 2" key="{817bac50-6dc6-45fa-b5e2-df3efd0fcd46}" description="Gf-Kabel u.i. Bestand">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  FS '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="Point" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="152,125,183,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="152,125,183,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="0,0,0,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
          </rule>
          <rule key="{6bf3126e-6373-4c21-a150-299dcdbea854}" description="o.i.">
            <rule filter="(&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%') AND NOT (&quot;bezeichnung&quot; IS NULL)" key="{ae8da886-59c7-4ff6-8098-9920ba8ce6b4}" description="Bezeichnung ist vorhanden">
              <rule filter="&quot;ZUSTAND&quot; = 1" key="{00e00c4c-b08c-4f63-92e3-59981194040e}" description="Gf-Kabel o.i. neu">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  FS ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="0,0,0,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="255,206,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="225,89,137,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="225,89,137,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="255,206,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="255,206,255,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule filter="&quot;ZUSTAND&quot; = 2" key="{ef998dec-28cc-4b66-92e3-a42efbec89b0}" description="Gf-Kabel o.i. Bestand">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  FS ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="183,72,75,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="183,72,75,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="0,0,0,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule key="{050049aa-9a77-4506-92b8-f75ee727c58f}" description="u.i."/>
            </rule>
            <rule filter="(&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%') AND (&quot;bezeichnung&quot; IS NULL)" key="{a82e1438-a020-419e-91b3-650ff91c1ea7}" description="Bezeichnung is NULL">
              <rule filter="&quot;ZUSTAND&quot; = 1" key="{fef6bdc3-d89a-469c-b723-4202d11c2481}" description="Gf-Kabel o.i. neu">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  FS '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="0,0,0,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="255,206,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="225,89,137,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="225,89,137,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="255,206,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="255,206,255,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule filter="&quot;ZUSTAND&quot; = 2" key="{7f4c2cc3-c3e4-4eec-a4d0-122b34816a1f}" description="Gf-Kabel o.i. Bestand">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  FS '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="183,72,75,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="183,72,75,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="0,0,0,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
          </rule>
        </rule>
        <rule filter="&quot;VERB_ART&quot; = 1" key="{1af96e8d-ef8f-4c4f-b861-81b3ad66fce2}" scalemindenom="1" scalemaxdenom="4000" description="Cu-Kabel">
          <rule key="{05681114-8e7a-4e5d-817a-795c73f4a9cb}" description="u.i.">
            <rule filter="(&quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )) AND NOT (&quot;bezeichnung&quot; IS NULL)" key="{7382c1af-193e-4c62-8982-2f339eb53eca}" description="Bezeichnung ist vorhanden">
              <rule filter="&quot;ZUSTAND&quot; = 1" key="{d8ba7bee-4c1e-43b8-b857-51e12239683d}" description="Cu-Kabel u.i. in neu">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  DA' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="194,50,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="255,158,23,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="255,158,23,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="194,50,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="194,50,255,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule filter="&quot;ZUSTAND&quot; = 2" key="{1dd9b1c7-7a15-430b-aaee-bdbec102e742}" description="Cu-Kabel u.i. in Bestand">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  DA' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="141,90,153,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="141,90,153,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="0,0,0,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
            <rule filter="(&quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )) AND (&quot;bezeichnung&quot; IS NULL)" key="{8b89a14e-bf15-4145-a83e-d4bacc26bd10}" description="Bezeichnung is NULL">
              <rule filter="&quot;ZUSTAND&quot; = 1" key="{09b3ceb3-29bd-49d0-aac7-6a0fe6f79623}" description="Cu-Kabel u.i. in neu">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  DA'" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="194,50,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="255,158,23,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="255,158,23,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="194,50,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="194,50,255,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule filter="&quot;ZUSTAND&quot; = 2" key="{3f75b4c0-210d-4c92-a80e-ec6cb460ad8b}" description="Cu-Kabel u.i. in Bestand">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  DA'" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="141,90,153,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="141,90,153,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="0,0,0,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
          </rule>
          <rule key="{d1403295-3d46-4bc8-9afe-4a126849180a}" description="o.i.">
            <rule filter="(&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%') AND NOT (&quot;bezeichnung&quot; IS NULL)" key="{2ee37ae8-8644-461d-8913-502f6415f8d6}" description="Bezeichnung ist vorhanden">
              <rule filter="&quot;ZUSTAND&quot; = 1" key="{25c25a06-bc6a-4a39-8b2e-d330482691e7}" description="Cu-Kabel o.i. neu">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="194,50,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="243,166,178,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="243,166,178,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="194,50,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="194,50,255,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule filter="&quot;ZUSTAND&quot; = 2" key="{fd6e2ffa-a240-4ffc-83a9-786b858c3d1a}" description="Cu-Kabel o.i. Bestand">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA ' || '(' || &quot;bezeichnung&quot;  || ') '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="213,180,60,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="213,180,60,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="0,0,0,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
            <rule filter="(&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%') AND (&quot;bezeichnung&quot; IS NULL)" key="{b90c479a-1f55-4e36-aecc-b8c39f551472}" description="Bezeichnung is NULL">
              <rule filter="&quot;ZUSTAND&quot; = 1" key="{ff5c7c0f-893f-4aac-a3fb-d464380b1178}" description="Cu-Kabel o.i. neu">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="194,50,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="243,166,178,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="243,166,178,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="194,50,255,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="194,50,255,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule filter="&quot;ZUSTAND&quot; = 2" key="{5b8c8bd5-ddb8-4165-bf07-2cffaf9df800}" description="Cu-Kabel o.i. Bestand">
                <settings calloutType="simple">
                  <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                    <families/>
                    <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                    <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                    <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                      <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="angle" value="0"/>
                            <Option type="QString" name="cap_style" value="square"/>
                            <Option type="QString" name="color" value="213,180,60,255"/>
                            <Option type="QString" name="horizontal_anchor_point" value="1"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="name" value="circle"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="35,35,35,255"/>
                            <Option type="QString" name="outline_style" value="solid"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="scale_method" value="diameter"/>
                            <Option type="QString" name="size" value="2"/>
                            <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="size_unit" value="MM"/>
                            <Option type="QString" name="vertical_anchor_point" value="1"/>
                          </Option>
                          <prop v="0" k="angle"/>
                          <prop v="square" k="cap_style"/>
                          <prop v="213,180,60,255" k="color"/>
                          <prop v="1" k="horizontal_anchor_point"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="circle" k="name"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="35,35,35,255" k="outline_color"/>
                          <prop v="solid" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="diameter" k="scale_method"/>
                          <prop v="2" k="size"/>
                          <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                          <prop v="MM" k="size_unit"/>
                          <prop v="1" k="vertical_anchor_point"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                        <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                          <Option type="Map">
                            <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="color" value="0,0,0,255"/>
                            <Option type="QString" name="joinstyle" value="bevel"/>
                            <Option type="QString" name="offset" value="0,0"/>
                            <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                            <Option type="QString" name="offset_unit" value="MM"/>
                            <Option type="QString" name="outline_color" value="128,128,128,255"/>
                            <Option type="QString" name="outline_style" value="no"/>
                            <Option type="QString" name="outline_width" value="0"/>
                            <Option type="QString" name="outline_width_unit" value="MM"/>
                            <Option type="QString" name="style" value="solid"/>
                          </Option>
                          <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                          <prop v="0,0,0,255" k="color"/>
                          <prop v="bevel" k="joinstyle"/>
                          <prop v="0,0" k="offset"/>
                          <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                          <prop v="MM" k="offset_unit"/>
                          <prop v="128,128,128,255" k="outline_color"/>
                          <prop v="no" k="outline_style"/>
                          <prop v="0" k="outline_width"/>
                          <prop v="MM" k="outline_width_unit"/>
                          <prop v="solid" k="style"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" name="name" value=""/>
                              <Option name="properties"/>
                              <Option type="QString" name="type" value="collection"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                  <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                  <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                      <Option type="int" name="blendMode" value="0"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                      <Option type="bool" name="drawToAllParts" value="false"/>
                      <Option type="QString" name="enabled" value="0"/>
                      <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                      <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                      <Option type="double" name="minLength" value="0"/>
                      <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="minLengthUnit" value="MM"/>
                      <Option type="double" name="offsetFromAnchor" value="0"/>
                      <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                      <Option type="double" name="offsetFromLabel" value="0"/>
                      <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                      <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
          </rule>
        </rule>
        <rule filter="&quot;VERB_ART&quot; = 99 AND (&quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )" key="{72cd65f8-862c-4dec-b3e6-8e9df88802f7}" scalemindenom="1" scalemaxdenom="4000" description="FSP-Kabel">
          <rule filter="&quot;ZUSTAND&quot; = 1" key="{cd64aee3-3f05-438f-8b14-7087eab47665}" description="FSP-Kabel in neu">
            <settings calloutType="simple">
              <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' FSP '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                <families/>
                <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="194,50,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                  <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="angle" value="0"/>
                        <Option type="QString" name="cap_style" value="square"/>
                        <Option type="QString" name="color" value="125,139,143,255"/>
                        <Option type="QString" name="horizontal_anchor_point" value="1"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="name" value="circle"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="35,35,35,255"/>
                        <Option type="QString" name="outline_style" value="solid"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="scale_method" value="diameter"/>
                        <Option type="QString" name="size" value="2"/>
                        <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="size_unit" value="MM"/>
                        <Option type="QString" name="vertical_anchor_point" value="1"/>
                      </Option>
                      <prop v="0" k="angle"/>
                      <prop v="square" k="cap_style"/>
                      <prop v="125,139,143,255" k="color"/>
                      <prop v="1" k="horizontal_anchor_point"/>
                      <prop v="bevel" k="joinstyle"/>
                      <prop v="circle" k="name"/>
                      <prop v="0,0" k="offset"/>
                      <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                      <prop v="MM" k="offset_unit"/>
                      <prop v="35,35,35,255" k="outline_color"/>
                      <prop v="solid" k="outline_style"/>
                      <prop v="0" k="outline_width"/>
                      <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                      <prop v="MM" k="outline_width_unit"/>
                      <prop v="diameter" k="scale_method"/>
                      <prop v="2" k="size"/>
                      <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                      <prop v="MM" k="size_unit"/>
                      <prop v="1" k="vertical_anchor_point"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                  <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="color" value="194,50,255,255"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="128,128,128,255"/>
                        <Option type="QString" name="outline_style" value="no"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="style" value="solid"/>
                      </Option>
                      <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                      <prop v="194,50,255,255" k="color"/>
                      <prop v="bevel" k="joinstyle"/>
                      <prop v="0,0" k="offset"/>
                      <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                      <prop v="MM" k="offset_unit"/>
                      <prop v="128,128,128,255" k="outline_color"/>
                      <prop v="no" k="outline_style"/>
                      <prop v="0" k="outline_width"/>
                      <prop v="MM" k="outline_width_unit"/>
                      <prop v="solid" k="style"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                </background>
                <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <substitutions/>
              </text-style>
              <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
              <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
              <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
              <dd_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option name="properties"/>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </dd_properties>
              <callout type="simple">
                <Option type="Map">
                  <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                  <Option type="int" name="blendMode" value="0"/>
                  <Option type="Map" name="ddProperties">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                  <Option type="bool" name="drawToAllParts" value="false"/>
                  <Option type="QString" name="enabled" value="0"/>
                  <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                  <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                  <Option type="double" name="minLength" value="0"/>
                  <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="minLengthUnit" value="MM"/>
                  <Option type="double" name="offsetFromAnchor" value="0"/>
                  <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                  <Option type="double" name="offsetFromLabel" value="0"/>
                  <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                </Option>
              </callout>
            </settings>
          </rule>
          <rule filter="&quot;ZUSTAND&quot; = 2" key="{52de16e3-87f4-4174-8090-061470601bae}" description="FSP-Kabel in Bestand">
            <settings calloutType="simple">
              <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' FSP '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                <families/>
                <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                  <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="angle" value="0"/>
                        <Option type="QString" name="cap_style" value="square"/>
                        <Option type="QString" name="color" value="133,182,111,255"/>
                        <Option type="QString" name="horizontal_anchor_point" value="1"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="name" value="circle"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="35,35,35,255"/>
                        <Option type="QString" name="outline_style" value="solid"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="scale_method" value="diameter"/>
                        <Option type="QString" name="size" value="2"/>
                        <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="size_unit" value="MM"/>
                        <Option type="QString" name="vertical_anchor_point" value="1"/>
                      </Option>
                      <prop v="0" k="angle"/>
                      <prop v="square" k="cap_style"/>
                      <prop v="133,182,111,255" k="color"/>
                      <prop v="1" k="horizontal_anchor_point"/>
                      <prop v="bevel" k="joinstyle"/>
                      <prop v="circle" k="name"/>
                      <prop v="0,0" k="offset"/>
                      <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                      <prop v="MM" k="offset_unit"/>
                      <prop v="35,35,35,255" k="outline_color"/>
                      <prop v="solid" k="outline_style"/>
                      <prop v="0" k="outline_width"/>
                      <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                      <prop v="MM" k="outline_width_unit"/>
                      <prop v="diameter" k="scale_method"/>
                      <prop v="2" k="size"/>
                      <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                      <prop v="MM" k="size_unit"/>
                      <prop v="1" k="vertical_anchor_point"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                  <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="color" value="0,0,0,255"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="128,128,128,255"/>
                        <Option type="QString" name="outline_style" value="no"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="style" value="solid"/>
                      </Option>
                      <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                      <prop v="0,0,0,255" k="color"/>
                      <prop v="bevel" k="joinstyle"/>
                      <prop v="0,0" k="offset"/>
                      <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                      <prop v="MM" k="offset_unit"/>
                      <prop v="128,128,128,255" k="outline_color"/>
                      <prop v="no" k="outline_style"/>
                      <prop v="0" k="outline_width"/>
                      <prop v="MM" k="outline_width_unit"/>
                      <prop v="solid" k="style"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                </background>
                <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <substitutions/>
              </text-style>
              <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
              <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
              <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
              <dd_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option name="properties"/>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </dd_properties>
              <callout type="simple">
                <Option type="Map">
                  <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                  <Option type="int" name="blendMode" value="0"/>
                  <Option type="Map" name="ddProperties">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                  <Option type="bool" name="drawToAllParts" value="false"/>
                  <Option type="QString" name="enabled" value="0"/>
                  <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                  <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                  <Option type="double" name="minLength" value="0"/>
                  <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="minLengthUnit" value="MM"/>
                  <Option type="double" name="offsetFromAnchor" value="0"/>
                  <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                  <Option type="double" name="offsetFromLabel" value="0"/>
                  <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                </Option>
              </callout>
            </settings>
          </rule>
        </rule>
      </rule>
      <rule filter="0" key="{e0d947b8-ffd0-4840-b265-3382c05ee364}" description="mit Reserve">
        <rule filter="&quot;VERB_ART&quot; IN (5,6,7,8,9,10,11,99)" key="{34c0ce63-fe7e-4667-b09c-39818c2cec81}" scalemindenom="1" scalemaxdenom="4000" description="Gf-Kabel">
          <rule filter=" &quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' OR &quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )" key="{1b6b45a1-a3f3-4930-b7be-d0c71274c2eb}" description="Gf-Kabel u.i.">
            <rule filter="&quot;ZUSTAND&quot; = 1" key="{3914c98d-ed99-403f-8a54-ea161c003e99}" description="Gf-Kabel u.i. neu">
              <settings calloutType="simple">
                <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  FS l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="0,0,0,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                  <families/>
                  <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                  <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                  <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="255,206,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                    <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="190,207,80,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop v="0" k="angle"/>
                        <prop v="square" k="cap_style"/>
                        <prop v="190,207,80,255" k="color"/>
                        <prop v="1" k="horizontal_anchor_point"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="circle" k="name"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="35,35,35,255" k="outline_color"/>
                        <prop v="solid" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="diameter" k="scale_method"/>
                        <prop v="2" k="size"/>
                        <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                        <prop v="MM" k="size_unit"/>
                        <prop v="1" k="vertical_anchor_point"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="255,206,255,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                        <prop v="255,206,255,255" k="color"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="128,128,128,255" k="outline_color"/>
                        <prop v="no" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="solid" k="style"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
            <rule filter="&quot;ZUSTAND&quot; = 2" key="{74db9e3a-9d4f-45e5-ad9f-67dcce949dc1}" description="Gf-Kabel u.i. Bestand">
              <settings calloutType="simple">
                <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  FS l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                  <families/>
                  <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                  <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                  <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="Point" shapeBorderWidth="0">
                    <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="152,125,183,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop v="0" k="angle"/>
                        <prop v="square" k="cap_style"/>
                        <prop v="152,125,183,255" k="color"/>
                        <prop v="1" k="horizontal_anchor_point"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="circle" k="name"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="35,35,35,255" k="outline_color"/>
                        <prop v="solid" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="diameter" k="scale_method"/>
                        <prop v="2" k="size"/>
                        <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                        <prop v="MM" k="size_unit"/>
                        <prop v="1" k="vertical_anchor_point"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="0,0,0,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                        <prop v="0,0,0,255" k="color"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="128,128,128,255" k="outline_color"/>
                        <prop v="no" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="solid" k="style"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
          </rule>
          <rule filter="&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%'" key="{309e2b80-a187-42b4-9e2b-30115d7a7452}" description="Gf-Kabel o.i.">
            <rule filter="&quot;ZUSTAND&quot; = 1" key="{efa15076-bdd1-4a59-baa5-0f984e917199}" description="Gf-Kabel o.i. neu">
              <settings calloutType="simple">
                <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  FS l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="0,0,0,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                  <families/>
                  <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                  <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                  <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="255,206,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                    <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="225,89,137,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop v="0" k="angle"/>
                        <prop v="square" k="cap_style"/>
                        <prop v="225,89,137,255" k="color"/>
                        <prop v="1" k="horizontal_anchor_point"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="circle" k="name"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="35,35,35,255" k="outline_color"/>
                        <prop v="solid" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="diameter" k="scale_method"/>
                        <prop v="2" k="size"/>
                        <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                        <prop v="MM" k="size_unit"/>
                        <prop v="1" k="vertical_anchor_point"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="255,206,255,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                        <prop v="255,206,255,255" k="color"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="128,128,128,255" k="outline_color"/>
                        <prop v="no" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="solid" k="style"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
            <rule filter="&quot;ZUSTAND&quot; = 2" key="{182c3996-e6ee-48e4-8ddd-a9b0b6b083c2}" description="Gf-Kabel o.i. Bestand">
              <settings calloutType="simple">
                <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  FS l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                  <families/>
                  <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                  <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                  <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                    <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="183,72,75,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop v="0" k="angle"/>
                        <prop v="square" k="cap_style"/>
                        <prop v="183,72,75,255" k="color"/>
                        <prop v="1" k="horizontal_anchor_point"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="circle" k="name"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="35,35,35,255" k="outline_color"/>
                        <prop v="solid" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="diameter" k="scale_method"/>
                        <prop v="2" k="size"/>
                        <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                        <prop v="MM" k="size_unit"/>
                        <prop v="1" k="vertical_anchor_point"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="0,0,0,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                        <prop v="0,0,0,255" k="color"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="128,128,128,255" k="outline_color"/>
                        <prop v="no" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="solid" k="style"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
          </rule>
        </rule>
        <rule filter="&quot;VERB_ART&quot; = 1" key="{f77d63eb-6ed4-4437-b29c-9f8da1b16ce9}" scalemindenom="1" scalemaxdenom="4000" description="Cu-Kabel">
          <rule filter=" &quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )" key="{3143901b-5769-491b-be27-c46e8a3cd79e}" description="Cu-Kabel u.i.">
            <rule filter="&quot;ZUSTAND&quot; = 1" key="{7fccbda2-f381-4931-91ad-5e4b3a044bef}" description="Cu-Kabel u.i. in neu">
              <settings calloutType="simple">
                <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  DA l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                  <families/>
                  <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                  <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                  <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="194,50,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                    <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="255,158,23,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop v="0" k="angle"/>
                        <prop v="square" k="cap_style"/>
                        <prop v="255,158,23,255" k="color"/>
                        <prop v="1" k="horizontal_anchor_point"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="circle" k="name"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="35,35,35,255" k="outline_color"/>
                        <prop v="solid" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="diameter" k="scale_method"/>
                        <prop v="2" k="size"/>
                        <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                        <prop v="MM" k="size_unit"/>
                        <prop v="1" k="vertical_anchor_point"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="194,50,255,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                        <prop v="194,50,255,255" k="color"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="128,128,128,255" k="outline_color"/>
                        <prop v="no" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="solid" k="style"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
            <rule filter="&quot;ZUSTAND&quot; = 2" key="{6e92f831-225f-4a48-96e5-289e264f89e7}" description="Cu-Kabel u.i. in Bestand">
              <settings calloutType="simple">
                <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  DA l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                  <families/>
                  <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                  <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                  <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                    <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="141,90,153,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop v="0" k="angle"/>
                        <prop v="square" k="cap_style"/>
                        <prop v="141,90,153,255" k="color"/>
                        <prop v="1" k="horizontal_anchor_point"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="circle" k="name"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="35,35,35,255" k="outline_color"/>
                        <prop v="solid" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="diameter" k="scale_method"/>
                        <prop v="2" k="size"/>
                        <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                        <prop v="MM" k="size_unit"/>
                        <prop v="1" k="vertical_anchor_point"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="0,0,0,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                        <prop v="0,0,0,255" k="color"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="128,128,128,255" k="outline_color"/>
                        <prop v="no" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="solid" k="style"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
          </rule>
          <rule filter="&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%'" key="{38b13dcf-c70f-4576-acc9-bb4907a6dda9}" description="Cu-Kabel o.i.">
            <rule filter="&quot;ZUSTAND&quot; = 1" key="{0e7f12da-6489-4e9d-9096-a545801926c8}" description="Cu-Kabel o.i. neu">
              <settings calloutType="simple">
                <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                  <families/>
                  <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                  <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                  <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="194,50,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                    <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="243,166,178,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop v="0" k="angle"/>
                        <prop v="square" k="cap_style"/>
                        <prop v="243,166,178,255" k="color"/>
                        <prop v="1" k="horizontal_anchor_point"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="circle" k="name"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="35,35,35,255" k="outline_color"/>
                        <prop v="solid" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="diameter" k="scale_method"/>
                        <prop v="2" k="size"/>
                        <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                        <prop v="MM" k="size_unit"/>
                        <prop v="1" k="vertical_anchor_point"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="194,50,255,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                        <prop v="194,50,255,255" k="color"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="128,128,128,255" k="outline_color"/>
                        <prop v="no" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="solid" k="style"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
            <rule filter="&quot;ZUSTAND&quot; = 2" key="{a780b024-c93b-4330-bbea-00f395602504}" description="Cu-Kabel o.i. Bestand">
              <settings calloutType="simple">
                <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                  <families/>
                  <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                  <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                  <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                    <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="angle" value="0"/>
                          <Option type="QString" name="cap_style" value="square"/>
                          <Option type="QString" name="color" value="213,180,60,255"/>
                          <Option type="QString" name="horizontal_anchor_point" value="1"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="name" value="circle"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="35,35,35,255"/>
                          <Option type="QString" name="outline_style" value="solid"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="scale_method" value="diameter"/>
                          <Option type="QString" name="size" value="2"/>
                          <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="size_unit" value="MM"/>
                          <Option type="QString" name="vertical_anchor_point" value="1"/>
                        </Option>
                        <prop v="0" k="angle"/>
                        <prop v="square" k="cap_style"/>
                        <prop v="213,180,60,255" k="color"/>
                        <prop v="1" k="horizontal_anchor_point"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="circle" k="name"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="35,35,35,255" k="outline_color"/>
                        <prop v="solid" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="diameter" k="scale_method"/>
                        <prop v="2" k="size"/>
                        <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                        <prop v="MM" k="size_unit"/>
                        <prop v="1" k="vertical_anchor_point"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                      <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                        <Option type="Map">
                          <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="color" value="0,0,0,255"/>
                          <Option type="QString" name="joinstyle" value="bevel"/>
                          <Option type="QString" name="offset" value="0,0"/>
                          <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                          <Option type="QString" name="offset_unit" value="MM"/>
                          <Option type="QString" name="outline_color" value="128,128,128,255"/>
                          <Option type="QString" name="outline_style" value="no"/>
                          <Option type="QString" name="outline_width" value="0"/>
                          <Option type="QString" name="outline_width_unit" value="MM"/>
                          <Option type="QString" name="style" value="solid"/>
                        </Option>
                        <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                        <prop v="0,0,0,255" k="color"/>
                        <prop v="bevel" k="joinstyle"/>
                        <prop v="0,0" k="offset"/>
                        <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                        <prop v="MM" k="offset_unit"/>
                        <prop v="128,128,128,255" k="outline_color"/>
                        <prop v="no" k="outline_style"/>
                        <prop v="0" k="outline_width"/>
                        <prop v="MM" k="outline_width_unit"/>
                        <prop v="solid" k="style"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" name="name" value=""/>
                            <Option name="properties"/>
                            <Option type="QString" name="type" value="collection"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
                <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
                <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                    <Option type="int" name="blendMode" value="0"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" name="name" value=""/>
                      <Option name="properties"/>
                      <Option type="QString" name="type" value="collection"/>
                    </Option>
                    <Option type="bool" name="drawToAllParts" value="false"/>
                    <Option type="QString" name="enabled" value="0"/>
                    <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                    <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                    <Option type="double" name="minLength" value="0"/>
                    <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="minLengthUnit" value="MM"/>
                    <Option type="double" name="offsetFromAnchor" value="0"/>
                    <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                    <Option type="double" name="offsetFromLabel" value="0"/>
                    <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                    <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                  </Option>
                </callout>
              </settings>
            </rule>
          </rule>
        </rule>
        <rule filter="&quot;VERB_ART&quot; = 99 AND (&quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )" key="{51c39a37-9b3f-400c-8c85-71028f36c990}" scalemindenom="1" scalemaxdenom="4000" description="FSP-Kabel">
          <rule filter="&quot;ZUSTAND&quot; = 1" key="{85ba9c57-02b7-46c2-8e37-1ce3528a39d8}" description="FSP-Kabel in neu">
            <settings calloutType="simple">
              <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' FSP '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                <families/>
                <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="194,50,255,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                  <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="angle" value="0"/>
                        <Option type="QString" name="cap_style" value="square"/>
                        <Option type="QString" name="color" value="125,139,143,255"/>
                        <Option type="QString" name="horizontal_anchor_point" value="1"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="name" value="circle"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="35,35,35,255"/>
                        <Option type="QString" name="outline_style" value="solid"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="scale_method" value="diameter"/>
                        <Option type="QString" name="size" value="2"/>
                        <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="size_unit" value="MM"/>
                        <Option type="QString" name="vertical_anchor_point" value="1"/>
                      </Option>
                      <prop v="0" k="angle"/>
                      <prop v="square" k="cap_style"/>
                      <prop v="125,139,143,255" k="color"/>
                      <prop v="1" k="horizontal_anchor_point"/>
                      <prop v="bevel" k="joinstyle"/>
                      <prop v="circle" k="name"/>
                      <prop v="0,0" k="offset"/>
                      <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                      <prop v="MM" k="offset_unit"/>
                      <prop v="35,35,35,255" k="outline_color"/>
                      <prop v="solid" k="outline_style"/>
                      <prop v="0" k="outline_width"/>
                      <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                      <prop v="MM" k="outline_width_unit"/>
                      <prop v="diameter" k="scale_method"/>
                      <prop v="2" k="size"/>
                      <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                      <prop v="MM" k="size_unit"/>
                      <prop v="1" k="vertical_anchor_point"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                  <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="color" value="194,50,255,255"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="128,128,128,255"/>
                        <Option type="QString" name="outline_style" value="no"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="style" value="solid"/>
                      </Option>
                      <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                      <prop v="194,50,255,255" k="color"/>
                      <prop v="bevel" k="joinstyle"/>
                      <prop v="0,0" k="offset"/>
                      <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                      <prop v="MM" k="offset_unit"/>
                      <prop v="128,128,128,255" k="outline_color"/>
                      <prop v="no" k="outline_style"/>
                      <prop v="0" k="outline_width"/>
                      <prop v="MM" k="outline_width_unit"/>
                      <prop v="solid" k="style"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                </background>
                <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <substitutions/>
              </text-style>
              <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
              <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="10" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
              <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
              <dd_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option name="properties"/>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </dd_properties>
              <callout type="simple">
                <Option type="Map">
                  <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                  <Option type="int" name="blendMode" value="0"/>
                  <Option type="Map" name="ddProperties">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                  <Option type="bool" name="drawToAllParts" value="false"/>
                  <Option type="QString" name="enabled" value="0"/>
                  <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                  <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                  <Option type="double" name="minLength" value="0"/>
                  <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="minLengthUnit" value="MM"/>
                  <Option type="double" name="offsetFromAnchor" value="0"/>
                  <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                  <Option type="double" name="offsetFromLabel" value="0"/>
                  <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                </Option>
              </callout>
            </settings>
          </rule>
          <rule filter="&quot;ZUSTAND&quot; = 2" key="{d9aa13b5-ad28-44b4-b1fc-97a3b10529cd}" description="FSP-Kabel in Bestand">
            <settings calloutType="simple">
              <text-style fontSize="10" fontUnderline="0" fontLetterSpacing="0" fieldName=" ' FSP '" textOpacity="1" multilineHeight="1" fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontWeight="50" fontKerning="1" legendString="Aa" textColor="255,255,255,255" allowHtml="0" fontWordSpacing="0" fontStrikeout="0" namedStyle="Standard" fontItalic="0" previewBkgrdColor="255,255,255,255" fontFamily="MS Shell Dlg 2" textOrientation="horizontal" capitalization="0" useSubstitutions="0" fontSizeUnit="Point" blendMode="0" isExpression="1">
                <families/>
                <text-buffer bufferSizeUnits="MM" bufferSize="1" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferNoFill="1" bufferOpacity="1" bufferColor="255,255,255,255" bufferJoinStyle="128" bufferBlendMode="0" bufferDraw="0"/>
                <text-mask maskedSymbolLayers="" maskType="0" maskEnabled="0" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskOpacity="1" maskJoinStyle="128" maskSizeUnits="MM" maskSize="1.5"/>
                <background shapeRotation="0" shapeDraw="1" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeType="0" shapeOffsetY="0" shapeBorderWidthUnit="MM" shapeSVGFile="" shapeSizeType="0" shapeOpacity="1" shapeOffsetX="0" shapeRadiiY="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiX="0" shapeJoinStyle="64" shapeBlendMode="0" shapeRadiiUnit="MM" shapeSizeY="0" shapeOffsetUnit="MM" shapeBorderColor="128,128,128,255" shapeFillColor="0,0,0,255" shapeSizeX="0" shapeRotationType="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeBorderWidth="0">
                  <symbol clip_to_extent="1" force_rhr="0" type="marker" alpha="1" name="markerSymbol">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer enabled="1" class="SimpleMarker" pass="0" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="angle" value="0"/>
                        <Option type="QString" name="cap_style" value="square"/>
                        <Option type="QString" name="color" value="133,182,111,255"/>
                        <Option type="QString" name="horizontal_anchor_point" value="1"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="name" value="circle"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="35,35,35,255"/>
                        <Option type="QString" name="outline_style" value="solid"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="scale_method" value="diameter"/>
                        <Option type="QString" name="size" value="2"/>
                        <Option type="QString" name="size_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="size_unit" value="MM"/>
                        <Option type="QString" name="vertical_anchor_point" value="1"/>
                      </Option>
                      <prop v="0" k="angle"/>
                      <prop v="square" k="cap_style"/>
                      <prop v="133,182,111,255" k="color"/>
                      <prop v="1" k="horizontal_anchor_point"/>
                      <prop v="bevel" k="joinstyle"/>
                      <prop v="circle" k="name"/>
                      <prop v="0,0" k="offset"/>
                      <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                      <prop v="MM" k="offset_unit"/>
                      <prop v="35,35,35,255" k="outline_color"/>
                      <prop v="solid" k="outline_style"/>
                      <prop v="0" k="outline_width"/>
                      <prop v="3x:0,0,0,0,0,0" k="outline_width_map_unit_scale"/>
                      <prop v="MM" k="outline_width_unit"/>
                      <prop v="diameter" k="scale_method"/>
                      <prop v="2" k="size"/>
                      <prop v="3x:0,0,0,0,0,0" k="size_map_unit_scale"/>
                      <prop v="MM" k="size_unit"/>
                      <prop v="1" k="vertical_anchor_point"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                  <symbol clip_to_extent="1" force_rhr="0" type="fill" alpha="1" name="fillSymbol">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" name="name" value=""/>
                        <Option name="properties"/>
                        <Option type="QString" name="type" value="collection"/>
                      </Option>
                    </data_defined_properties>
                    <layer enabled="1" class="SimpleFill" pass="0" locked="0">
                      <Option type="Map">
                        <Option type="QString" name="border_width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="color" value="0,0,0,255"/>
                        <Option type="QString" name="joinstyle" value="bevel"/>
                        <Option type="QString" name="offset" value="0,0"/>
                        <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
                        <Option type="QString" name="offset_unit" value="MM"/>
                        <Option type="QString" name="outline_color" value="128,128,128,255"/>
                        <Option type="QString" name="outline_style" value="no"/>
                        <Option type="QString" name="outline_width" value="0"/>
                        <Option type="QString" name="outline_width_unit" value="MM"/>
                        <Option type="QString" name="style" value="solid"/>
                      </Option>
                      <prop v="3x:0,0,0,0,0,0" k="border_width_map_unit_scale"/>
                      <prop v="0,0,0,255" k="color"/>
                      <prop v="bevel" k="joinstyle"/>
                      <prop v="0,0" k="offset"/>
                      <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
                      <prop v="MM" k="offset_unit"/>
                      <prop v="128,128,128,255" k="outline_color"/>
                      <prop v="no" k="outline_style"/>
                      <prop v="0" k="outline_width"/>
                      <prop v="MM" k="outline_width_unit"/>
                      <prop v="solid" k="style"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" name="name" value=""/>
                          <Option name="properties"/>
                          <Option type="QString" name="type" value="collection"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                </background>
                <shadow shadowDraw="0" shadowBlendMode="6" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowRadius="1.5" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowOffsetUnit="MM" shadowScale="100" shadowOffsetGlobal="1" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowColor="0,0,0,255" shadowOffsetAngle="135" shadowOffsetDist="1" shadowRadiusAlphaOnly="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                </dd_properties>
                <substitutions/>
              </text-style>
              <text-format leftDirectionSymbol="&lt;" decimals="3" useMaxLineLengthForAutoWrap="1" multilineAlign="0" wrapChar="" placeDirectionSymbol="0" autoWrapLength="0" reverseDirectionSymbol="0" addDirectionSymbol="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
              <placement overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="LineGeometry" yOffset="0" priority="5" geometryGeneratorType="PointGeometry" offsetUnits="MM" lineAnchorClipping="0" rotationAngle="0" maxCurvedCharAngleOut="-25" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" overrunDistance="0" overrunDistanceUnit="MM" xOffset="0" dist="5" preserveRotation="1" rotationUnit="AngleDegrees" offsetType="0" distUnits="Pixel" maxCurvedCharAngleIn="25" repeatDistanceUnits="MM" lineAnchorType="0" quadOffset="4" geometryGenerator="" placement="2" placementFlags="12" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" fitInPolygonOnly="0" repeatDistance="0" geometryGeneratorEnabled="0" centroidWhole="0" lineAnchorPercent="0.5" polygonPlacementFlags="2" centroidInside="0"/>
              <rendering limitNumLabels="0" labelPerPart="0" fontMaxPixelSize="10000" obstacle="1" fontMinPixelSize="3" obstacleType="1" obstacleFactor="1" mergeLines="0" scaleMax="0" scaleMin="0" displayAll="0" upsidedownLabels="0" minFeatureSize="0" scaleVisibility="0" drawLabels="1" zIndex="0" unplacedVisibility="0" maxNumLabels="2000" fontLimitPixelSize="0"/>
              <dd_properties>
                <Option type="Map">
                  <Option type="QString" name="name" value=""/>
                  <Option name="properties"/>
                  <Option type="QString" name="type" value="collection"/>
                </Option>
              </dd_properties>
              <callout type="simple">
                <Option type="Map">
                  <Option type="QString" name="anchorPoint" value="pole_of_inaccessibility"/>
                  <Option type="int" name="blendMode" value="0"/>
                  <Option type="Map" name="ddProperties">
                    <Option type="QString" name="name" value=""/>
                    <Option name="properties"/>
                    <Option type="QString" name="type" value="collection"/>
                  </Option>
                  <Option type="bool" name="drawToAllParts" value="false"/>
                  <Option type="QString" name="enabled" value="0"/>
                  <Option type="QString" name="labelAnchorPoint" value="point_on_exterior"/>
                  <Option type="QString" name="lineSymbol" value="&lt;symbol clip_to_extent=&quot;1&quot; force_rhr=&quot;0&quot; type=&quot;line&quot; alpha=&quot;1&quot; name=&quot;symbol&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; class=&quot;SimpleLine&quot; pass=&quot;0&quot; locked=&quot;0&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;align_dash_pattern&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;capstyle&quot; value=&quot;square&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash&quot; value=&quot;5;2&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;customdash_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;dash_pattern_offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;draw_inside_polygon&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;joinstyle&quot; value=&quot;bevel&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_color&quot; value=&quot;60,60,60,255&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_style&quot; value=&quot;solid&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width&quot; value=&quot;0.3&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;line_width_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;offset_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;ring_filter&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_end_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;trim_distance_start_unit&quot; value=&quot;MM&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;tweak_dash_pattern_on_corners&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;use_custom_dash&quot; value=&quot;0&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;width_map_unit_scale&quot; value=&quot;3x:0,0,0,0,0,0&quot;/>&lt;/Option>&lt;prop v=&quot;0&quot; k=&quot;align_dash_pattern&quot;/>&lt;prop v=&quot;square&quot; k=&quot;capstyle&quot;/>&lt;prop v=&quot;5;2&quot; k=&quot;customdash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;customdash_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;customdash_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;dash_pattern_offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;dash_pattern_offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;draw_inside_polygon&quot;/>&lt;prop v=&quot;bevel&quot; k=&quot;joinstyle&quot;/>&lt;prop v=&quot;60,60,60,255&quot; k=&quot;line_color&quot;/>&lt;prop v=&quot;solid&quot; k=&quot;line_style&quot;/>&lt;prop v=&quot;0.3&quot; k=&quot;line_width&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;line_width_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;offset&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;offset_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;offset_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;ring_filter&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_end&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_end_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;trim_distance_start&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;prop v=&quot;MM&quot; k=&quot;trim_distance_start_unit&quot;/>&lt;prop v=&quot;0&quot; k=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;prop v=&quot;0&quot; k=&quot;use_custom_dash&quot;/>&lt;prop v=&quot;3x:0,0,0,0,0,0&quot; k=&quot;width_map_unit_scale&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; name=&quot;name&quot; value=&quot;&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; name=&quot;type&quot; value=&quot;collection&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>"/>
                  <Option type="double" name="minLength" value="0"/>
                  <Option type="QString" name="minLengthMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="minLengthUnit" value="MM"/>
                  <Option type="double" name="offsetFromAnchor" value="0"/>
                  <Option type="QString" name="offsetFromAnchorMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromAnchorUnit" value="MM"/>
                  <Option type="double" name="offsetFromLabel" value="0"/>
                  <Option type="QString" name="offsetFromLabelMapUnitScale" value="3x:0,0,0,0,0,0"/>
                  <Option type="QString" name="offsetFromLabelUnit" value="MM"/>
                </Option>
              </callout>
            </settings>
          </rule>
        </rule>
      </rule>
    </rules>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option type="List" name="dualview/previewExpressions">
        <Option type="QString" value="&quot;Verb_Art&quot;"/>
      </Option>
      <Option type="QString" name="embeddedWidgets/count" value="0"/>
      <Option type="invalid" name="variableNames"/>
      <Option type="invalid" name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory width="15" barWidth="5" lineSizeType="MM" spacingUnitScale="3x:0,0,0,0,0,0" backgroundAlpha="255" penAlpha="255" direction="1" diagramOrientation="Up" scaleBasedVisibility="0" opacity="1" spacing="0" height="15" minScaleDenominator="0" penColor="#000000" maxScaleDenominator="1e+08" backgroundColor="#ffffff" spacingUnit="MM" minimumSize="0" sizeScale="3x:0,0,0,0,0,0" showAxis="0" enabled="0" labelPlacementMethod="XHeight" scaleDependency="Area" lineSizeScale="3x:0,0,0,0,0,0" penWidth="0" sizeType="MM" rotationOffset="270">
      <fontProperties style="" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0"/>
      <attribute color="#000000" field="" colorOpacity="1" label=""/>
      <axisSymbol>
        <symbol clip_to_extent="1" force_rhr="0" type="line" alpha="1" name="">
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" name="name" value=""/>
              <Option name="properties"/>
              <Option type="QString" name="type" value="collection"/>
            </Option>
          </data_defined_properties>
          <layer enabled="1" class="SimpleLine" pass="0" locked="0">
            <Option type="Map">
              <Option type="QString" name="align_dash_pattern" value="0"/>
              <Option type="QString" name="capstyle" value="square"/>
              <Option type="QString" name="customdash" value="5;2"/>
              <Option type="QString" name="customdash_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="customdash_unit" value="MM"/>
              <Option type="QString" name="dash_pattern_offset" value="0"/>
              <Option type="QString" name="dash_pattern_offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="dash_pattern_offset_unit" value="MM"/>
              <Option type="QString" name="draw_inside_polygon" value="0"/>
              <Option type="QString" name="joinstyle" value="bevel"/>
              <Option type="QString" name="line_color" value="35,35,35,255"/>
              <Option type="QString" name="line_style" value="solid"/>
              <Option type="QString" name="line_width" value="0.26"/>
              <Option type="QString" name="line_width_unit" value="MM"/>
              <Option type="QString" name="offset" value="0"/>
              <Option type="QString" name="offset_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="offset_unit" value="MM"/>
              <Option type="QString" name="ring_filter" value="0"/>
              <Option type="QString" name="trim_distance_end" value="0"/>
              <Option type="QString" name="trim_distance_end_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_end_unit" value="MM"/>
              <Option type="QString" name="trim_distance_start" value="0"/>
              <Option type="QString" name="trim_distance_start_map_unit_scale" value="3x:0,0,0,0,0,0"/>
              <Option type="QString" name="trim_distance_start_unit" value="MM"/>
              <Option type="QString" name="tweak_dash_pattern_on_corners" value="0"/>
              <Option type="QString" name="use_custom_dash" value="0"/>
              <Option type="QString" name="width_map_unit_scale" value="3x:0,0,0,0,0,0"/>
            </Option>
            <prop v="0" k="align_dash_pattern"/>
            <prop v="square" k="capstyle"/>
            <prop v="5;2" k="customdash"/>
            <prop v="3x:0,0,0,0,0,0" k="customdash_map_unit_scale"/>
            <prop v="MM" k="customdash_unit"/>
            <prop v="0" k="dash_pattern_offset"/>
            <prop v="3x:0,0,0,0,0,0" k="dash_pattern_offset_map_unit_scale"/>
            <prop v="MM" k="dash_pattern_offset_unit"/>
            <prop v="0" k="draw_inside_polygon"/>
            <prop v="bevel" k="joinstyle"/>
            <prop v="35,35,35,255" k="line_color"/>
            <prop v="solid" k="line_style"/>
            <prop v="0.26" k="line_width"/>
            <prop v="MM" k="line_width_unit"/>
            <prop v="0" k="offset"/>
            <prop v="3x:0,0,0,0,0,0" k="offset_map_unit_scale"/>
            <prop v="MM" k="offset_unit"/>
            <prop v="0" k="ring_filter"/>
            <prop v="0" k="trim_distance_end"/>
            <prop v="3x:0,0,0,0,0,0" k="trim_distance_end_map_unit_scale"/>
            <prop v="MM" k="trim_distance_end_unit"/>
            <prop v="0" k="trim_distance_start"/>
            <prop v="3x:0,0,0,0,0,0" k="trim_distance_start_map_unit_scale"/>
            <prop v="MM" k="trim_distance_start_unit"/>
            <prop v="0" k="tweak_dash_pattern_on_corners"/>
            <prop v="0" k="use_custom_dash"/>
            <prop v="3x:0,0,0,0,0,0" k="width_map_unit_scale"/>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" name="name" value=""/>
                <Option name="properties"/>
                <Option type="QString" name="type" value="collection"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings placement="2" showAll="1" obstacle="0" priority="0" zIndex="0" linePlacementFlags="18" dist="0">
    <properties>
      <Option type="Map">
        <Option type="QString" name="name" value=""/>
        <Option name="properties"/>
        <Option type="QString" name="type" value="collection"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions removeDuplicateNodes="0" geometryPrecision="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend showLabelLegend="0" type="default-vector"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="None" name="Verb_Art">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="V_A_Sonst">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="Lae_Kabel">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="Anzahl_F_A">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="F_A_Reserv">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="Zustand">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LFD_M_F_A">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_TRASSEN">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_LR">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_START">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_ENDE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MP_MBFD_CO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MP_DB_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MP_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MIT_CAB_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="SM_AUFTRAG">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="debug_errors">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="loeschen">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="GID">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_LIST">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MIT_CAB_ID_LIST">
      <editWidget type="">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias index="0" field="Verb_Art" name=""/>
    <alias index="1" field="V_A_Sonst" name=""/>
    <alias index="2" field="Lae_Kabel" name=""/>
    <alias index="3" field="Anzahl_F_A" name=""/>
    <alias index="4" field="F_A_Reserv" name=""/>
    <alias index="5" field="Zustand" name=""/>
    <alias index="6" field="LFD_M_F_A" name=""/>
    <alias index="7" field="ID_TRASSEN" name=""/>
    <alias index="8" field="ID_LR" name=""/>
    <alias index="9" field="ID_START" name=""/>
    <alias index="10" field="ID_ENDE" name=""/>
    <alias index="11" field="MP_MBFD_CO" name=""/>
    <alias index="12" field="MP_DB_ID" name=""/>
    <alias index="13" field="MP_ID" name=""/>
    <alias index="14" field="MIT_CAB_ID" name=""/>
    <alias index="15" field="SM_AUFTRAG" name=""/>
    <alias index="16" field="debug_errors" name=""/>
    <alias index="17" field="loeschen" name=""/>
    <alias index="18" field="GID" name=""/>
    <alias index="19" field="ID_LIST" name=""/>
    <alias index="20" field="MIT_CAB_ID_LIST" name=""/>
  </aliases>
  <defaults>
    <default expression="" field="Verb_Art" applyOnUpdate="0"/>
    <default expression="" field="V_A_Sonst" applyOnUpdate="0"/>
    <default expression="" field="Lae_Kabel" applyOnUpdate="0"/>
    <default expression="" field="Anzahl_F_A" applyOnUpdate="0"/>
    <default expression="" field="F_A_Reserv" applyOnUpdate="0"/>
    <default expression="" field="Zustand" applyOnUpdate="0"/>
    <default expression="" field="LFD_M_F_A" applyOnUpdate="0"/>
    <default expression="" field="ID_TRASSEN" applyOnUpdate="0"/>
    <default expression="" field="ID_LR" applyOnUpdate="0"/>
    <default expression="" field="ID_START" applyOnUpdate="0"/>
    <default expression="" field="ID_ENDE" applyOnUpdate="0"/>
    <default expression="" field="MP_MBFD_CO" applyOnUpdate="0"/>
    <default expression="" field="MP_DB_ID" applyOnUpdate="0"/>
    <default expression="" field="MP_ID" applyOnUpdate="0"/>
    <default expression="" field="MIT_CAB_ID" applyOnUpdate="0"/>
    <default expression="" field="SM_AUFTRAG" applyOnUpdate="0"/>
    <default expression="" field="debug_errors" applyOnUpdate="0"/>
    <default expression="" field="loeschen" applyOnUpdate="0"/>
    <default expression="" field="GID" applyOnUpdate="0"/>
    <default expression="" field="ID_LIST" applyOnUpdate="0"/>
    <default expression="" field="MIT_CAB_ID_LIST" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint exp_strength="0" notnull_strength="0" field="Verb_Art" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="V_A_Sonst" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="Lae_Kabel" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="Anzahl_F_A" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="F_A_Reserv" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="Zustand" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="LFD_M_F_A" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="ID_TRASSEN" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="ID_LR" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="ID_START" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="ID_ENDE" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="MP_MBFD_CO" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="MP_DB_ID" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="MP_ID" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="MIT_CAB_ID" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="SM_AUFTRAG" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="debug_errors" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="loeschen" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="GID" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="ID_LIST" unique_strength="0" constraints="0"/>
    <constraint exp_strength="0" notnull_strength="0" field="MIT_CAB_ID_LIST" unique_strength="0" constraints="0"/>
  </constraints>
  <constraintExpressions>
    <constraint desc="" field="Verb_Art" exp=""/>
    <constraint desc="" field="V_A_Sonst" exp=""/>
    <constraint desc="" field="Lae_Kabel" exp=""/>
    <constraint desc="" field="Anzahl_F_A" exp=""/>
    <constraint desc="" field="F_A_Reserv" exp=""/>
    <constraint desc="" field="Zustand" exp=""/>
    <constraint desc="" field="LFD_M_F_A" exp=""/>
    <constraint desc="" field="ID_TRASSEN" exp=""/>
    <constraint desc="" field="ID_LR" exp=""/>
    <constraint desc="" field="ID_START" exp=""/>
    <constraint desc="" field="ID_ENDE" exp=""/>
    <constraint desc="" field="MP_MBFD_CO" exp=""/>
    <constraint desc="" field="MP_DB_ID" exp=""/>
    <constraint desc="" field="MP_ID" exp=""/>
    <constraint desc="" field="MIT_CAB_ID" exp=""/>
    <constraint desc="" field="SM_AUFTRAG" exp=""/>
    <constraint desc="" field="debug_errors" exp=""/>
    <constraint desc="" field="loeschen" exp=""/>
    <constraint desc="" field="GID" exp=""/>
    <constraint desc="" field="ID_LIST" exp=""/>
    <constraint desc="" field="MIT_CAB_ID_LIST" exp=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortExpression="&quot;Verb_Art&quot;" sortOrder="0" actionWidgetStyle="dropDown">
    <columns>
      <column type="actions" hidden="1" width="-1"/>
      <column type="field" hidden="0" width="-1" name="VERB_ART"/>
      <column type="field" hidden="0" width="-1" name="V_A_SONST"/>
      <column type="field" hidden="0" width="-1" name="ANZAHL_VER"/>
      <column type="field" hidden="0" width="-1" name="LAE_KABEL"/>
      <column type="field" hidden="0" width="-1" name="ANZAHL_F_A"/>
      <column type="field" hidden="0" width="-1" name="LFD_M_F_A"/>
      <column type="field" hidden="0" width="-1" name="F_A_RESERV"/>
      <column type="field" hidden="0" width="-1" name="ZUSTAND"/>
      <column type="field" hidden="0" width="-1" name="ID_TRASSEN"/>
      <column type="field" hidden="0" width="-1" name="ID_LR"/>
      <column type="field" hidden="0" width="-1" name="ID_START"/>
      <column type="field" hidden="0" width="-1" name="ID_ENDE"/>
      <column type="field" hidden="0" width="-1" name="E_FNAME"/>
      <column type="field" hidden="0" width="-1" name="E_ORT"/>
      <column type="field" hidden="0" width="-1" name="E_TEL"/>
      <column type="field" hidden="0" width="-1" name="E_E_MAIL"/>
      <column type="field" hidden="0" width="-1" name="MP_MBFD_CO"/>
      <column type="field" hidden="0" width="-1" name="A_VNAME"/>
      <column type="field" hidden="0" width="-1" name="A_ZNAME"/>
      <column type="field" hidden="0" width="-1" name="A_TEL"/>
      <column type="field" hidden="0" width="-1" name="A_E_MAIL"/>
      <column type="field" hidden="0" width="-1" name="MP_DB_ID"/>
      <column type="field" hidden="0" width="-1" name="MP_ID"/>
      <column type="field" hidden="0" width="-1" name="MIT_CAB_ID"/>
      <column type="field" hidden="0" width="-1" name="SM_AUFTRAG"/>
      <column type="field" hidden="0" width="-1" name="ID"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1">C:/Users/A754221/AppData/Roaming</editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath>C:/Users/A754221/AppData/Roaming</editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <attributeEditorForm>
    <attributeEditorField showLabel="1" index="-1" name="ID"/>
    <attributeEditorField showLabel="1" index="0" name="Verb_Art"/>
    <attributeEditorField showLabel="1" index="1" name="V_A_Sonst"/>
    <attributeEditorField showLabel="1" index="2" name="Lae_Kabel"/>
    <attributeEditorField showLabel="1" index="-1" name="Anzahl_Ver"/>
    <attributeEditorField showLabel="1" index="3" name="Anzahl_F_A"/>
    <attributeEditorField showLabel="1" index="4" name="F_A_Reserv"/>
    <attributeEditorField showLabel="1" index="5" name="Zustand"/>
    <attributeEditorField showLabel="1" index="-1" name="ANZAHL_V_1"/>
    <attributeEditorField showLabel="1" index="6" name="LFD_M_F_A"/>
    <attributeEditorField showLabel="1" index="7" name="ID_TRASSEN"/>
    <attributeEditorField showLabel="1" index="8" name="ID_LR"/>
    <attributeEditorField showLabel="1" index="9" name="ID_START"/>
    <attributeEditorField showLabel="1" index="10" name="ID_ENDE"/>
    <attributeEditorField showLabel="1" index="-1" name="E_FNAME"/>
    <attributeEditorField showLabel="1" index="-1" name="E_ORT"/>
    <attributeEditorField showLabel="1" index="-1" name="E_TEL"/>
    <attributeEditorField showLabel="1" index="-1" name="E_E_MAIL"/>
    <attributeEditorField showLabel="1" index="-1" name="A_VNAME"/>
    <attributeEditorField showLabel="1" index="-1" name="A_ZNAME"/>
    <attributeEditorField showLabel="1" index="-1" name="A_TEL"/>
    <attributeEditorField showLabel="1" index="-1" name="A_E_MAIL"/>
    <attributeEditorField showLabel="1" index="12" name="MP_DB_ID"/>
    <attributeEditorField showLabel="1" index="13" name="MP_ID"/>
    <attributeEditorField showLabel="1" index="14" name="MIT_CAB_ID"/>
    <attributeEditorField showLabel="1" index="19" name="ID_LIST"/>
    <attributeEditorField showLabel="1" index="-1" name="MIT_CAB__1"/>
  </attributeEditorForm>
  <editable>
    <field editable="1" name="ANZAHL_F_A"/>
    <field editable="1" name="ANZAHL_VER"/>
    <field editable="1" name="A_E_MAIL"/>
    <field editable="1" name="A_TEL"/>
    <field editable="1" name="A_VNAME"/>
    <field editable="1" name="A_ZNAME"/>
    <field editable="1" name="Anzahl_F_A"/>
    <field editable="1" name="Anzahl_Ver"/>
    <field editable="1" name="E_E_MAIL"/>
    <field editable="1" name="E_FNAME"/>
    <field editable="1" name="E_ORT"/>
    <field editable="1" name="E_TEL"/>
    <field editable="1" name="F_A_RESERV"/>
    <field editable="1" name="F_A_Reserv"/>
    <field editable="1" name="GID"/>
    <field editable="1" name="ID"/>
    <field editable="1" name="ID_ENDE"/>
    <field editable="1" name="ID_LIST"/>
    <field editable="1" name="ID_LR"/>
    <field editable="1" name="ID_START"/>
    <field editable="1" name="ID_TRASSEN"/>
    <field editable="1" name="LAE_KABEL"/>
    <field editable="1" name="LFD_M_F_A"/>
    <field editable="1" name="Lae_Kabel"/>
    <field editable="1" name="MIT_CAB_ID"/>
    <field editable="1" name="MIT_CAB_ID_LIST"/>
    <field editable="1" name="MP_DB_ID"/>
    <field editable="1" name="MP_ID"/>
    <field editable="1" name="MP_MBFD_CO"/>
    <field editable="1" name="SM_AUFTRAG"/>
    <field editable="1" name="VERB_ART"/>
    <field editable="1" name="V_A_SONST"/>
    <field editable="1" name="V_A_Sonst"/>
    <field editable="1" name="Verb_Art"/>
    <field editable="1" name="ZUSTAND"/>
    <field editable="1" name="Zustand"/>
    <field editable="1" name="bezeichnung"/>
    <field editable="1" name="debug_errors"/>
    <field editable="1" name="fid"/>
    <field editable="1" name="laenge_gemessen"/>
    <field editable="1" name="loeschen"/>
    <field editable="1" name="material_nummer"/>
    <field editable="1" name="material_spezifikation"/>
    <field editable="1" name="quelle"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="ANZAHL_F_A"/>
    <field labelOnTop="0" name="ANZAHL_VER"/>
    <field labelOnTop="0" name="A_E_MAIL"/>
    <field labelOnTop="0" name="A_TEL"/>
    <field labelOnTop="0" name="A_VNAME"/>
    <field labelOnTop="0" name="A_ZNAME"/>
    <field labelOnTop="0" name="Anzahl_F_A"/>
    <field labelOnTop="0" name="Anzahl_Ver"/>
    <field labelOnTop="0" name="E_E_MAIL"/>
    <field labelOnTop="0" name="E_FNAME"/>
    <field labelOnTop="0" name="E_ORT"/>
    <field labelOnTop="0" name="E_TEL"/>
    <field labelOnTop="0" name="F_A_RESERV"/>
    <field labelOnTop="0" name="F_A_Reserv"/>
    <field labelOnTop="0" name="GID"/>
    <field labelOnTop="0" name="ID"/>
    <field labelOnTop="0" name="ID_ENDE"/>
    <field labelOnTop="0" name="ID_LIST"/>
    <field labelOnTop="0" name="ID_LR"/>
    <field labelOnTop="0" name="ID_START"/>
    <field labelOnTop="0" name="ID_TRASSEN"/>
    <field labelOnTop="0" name="LAE_KABEL"/>
    <field labelOnTop="0" name="LFD_M_F_A"/>
    <field labelOnTop="0" name="Lae_Kabel"/>
    <field labelOnTop="0" name="MIT_CAB_ID"/>
    <field labelOnTop="0" name="MIT_CAB_ID_LIST"/>
    <field labelOnTop="0" name="MP_DB_ID"/>
    <field labelOnTop="0" name="MP_ID"/>
    <field labelOnTop="0" name="MP_MBFD_CO"/>
    <field labelOnTop="0" name="SM_AUFTRAG"/>
    <field labelOnTop="0" name="VERB_ART"/>
    <field labelOnTop="0" name="V_A_SONST"/>
    <field labelOnTop="0" name="V_A_Sonst"/>
    <field labelOnTop="0" name="Verb_Art"/>
    <field labelOnTop="0" name="ZUSTAND"/>
    <field labelOnTop="0" name="Zustand"/>
    <field labelOnTop="0" name="bezeichnung"/>
    <field labelOnTop="0" name="debug_errors"/>
    <field labelOnTop="0" name="fid"/>
    <field labelOnTop="0" name="laenge_gemessen"/>
    <field labelOnTop="0" name="loeschen"/>
    <field labelOnTop="0" name="material_nummer"/>
    <field labelOnTop="0" name="material_spezifikation"/>
    <field labelOnTop="0" name="quelle"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="ANZAHL_F_A"/>
    <field reuseLastValue="0" name="ANZAHL_VER"/>
    <field reuseLastValue="0" name="A_E_MAIL"/>
    <field reuseLastValue="0" name="A_TEL"/>
    <field reuseLastValue="0" name="A_VNAME"/>
    <field reuseLastValue="0" name="A_ZNAME"/>
    <field reuseLastValue="0" name="Anzahl_F_A"/>
    <field reuseLastValue="0" name="E_E_MAIL"/>
    <field reuseLastValue="0" name="E_FNAME"/>
    <field reuseLastValue="0" name="E_ORT"/>
    <field reuseLastValue="0" name="E_TEL"/>
    <field reuseLastValue="0" name="F_A_RESERV"/>
    <field reuseLastValue="0" name="F_A_Reserv"/>
    <field reuseLastValue="0" name="ID"/>
    <field reuseLastValue="0" name="ID_ENDE"/>
    <field reuseLastValue="0" name="ID_LR"/>
    <field reuseLastValue="0" name="ID_START"/>
    <field reuseLastValue="0" name="ID_TRASSEN"/>
    <field reuseLastValue="0" name="LAE_KABEL"/>
    <field reuseLastValue="0" name="LFD_M_F_A"/>
    <field reuseLastValue="0" name="Lae_Kabel"/>
    <field reuseLastValue="0" name="MIT_CAB_ID"/>
    <field reuseLastValue="0" name="MP_DB_ID"/>
    <field reuseLastValue="0" name="MP_ID"/>
    <field reuseLastValue="0" name="MP_MBFD_CO"/>
    <field reuseLastValue="0" name="SM_AUFTRAG"/>
    <field reuseLastValue="0" name="VERB_ART"/>
    <field reuseLastValue="0" name="V_A_SONST"/>
    <field reuseLastValue="0" name="V_A_Sonst"/>
    <field reuseLastValue="0" name="Verb_Art"/>
    <field reuseLastValue="0" name="ZUSTAND"/>
    <field reuseLastValue="0" name="Zustand"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"VERB_ART"</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>

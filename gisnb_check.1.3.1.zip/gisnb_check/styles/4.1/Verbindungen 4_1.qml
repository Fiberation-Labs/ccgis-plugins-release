<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis simplifyLocal="1" version="3.22.16-Białowieża" simplifyDrawingHints="1" labelsEnabled="1" symbologyReferenceScale="-1" maxScale="0" hasScaleBasedVisibilityFlag="0" readOnly="0" simplifyMaxScale="1" styleCategories="AllStyleCategories" simplifyDrawingTol="1" simplifyAlgorithm="0" minScale="100000000">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal endField="" endExpression="" fixedDuration="0" startField="" startExpression="" durationField="" accumulate="0" enabled="0" mode="0" limitMode="0" durationUnit="min">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <renderer-v2 referencescale="-1" symbollevels="1" type="RuleRenderer" enableorderby="0" forceraster="0">
    <rules key="{25a1cd1a-8e15-44e8-8aa2-8c2503d5288d}">
      <rule label="Struktur" key="{449a9c95-6af4-4724-bce5-250cb466f365}">
        <rule filter="&quot;VERB_ART&quot; IN (5,6,7,8,9,10,11,99)" label="Gf-Kabel" key="{62e1dfb1-18c3-4478-89d3-7778dd876e9c}">
          <rule filter=" &quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' OR &quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )" label="Gf-Kabel u.i." key="{6699a01a-70be-42df-8acb-53977391dc5e}">
            <rule filter="&quot;ZUSTAND&quot; = 1" label="Gf-Kabel u.i. neu" key="{88b3198b-532a-4091-8fe2-1389866f7f17}" symbol="0"/>
            <rule filter="&quot;ZUSTAND&quot; = 2" label="Gf-Kabel u.i. Bestand" key="{31ea56d7-bcb9-43a2-8973-1e24ae4bb1a4}" symbol="1"/>
          </rule>
          <rule filter="&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%'" label="Gf-Kabel o.i." key="{5dfc6b00-a713-4a45-9c36-c8dcf688de58}">
            <rule filter="&quot;ZUSTAND&quot; = 1" label="Gf-Kabel o.i. neu" key="{29dd56ce-1121-4ef0-bd08-73bab0c17aee}" symbol="2"/>
            <rule filter="&quot;ZUSTAND&quot; = 2" label="Gf-Kabel o.i. Bestand" key="{87aa018e-abd8-4a67-b94b-57f7115b3754}" symbol="3"/>
          </rule>
        </rule>
        <rule filter="&quot;VERB_ART&quot; = 1" label="Cu-Kabel" key="{a7573130-4a04-43b0-924d-52b613210ee0}">
          <rule filter=" &quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )" label="Cu-Kabel u.i." key="{a3409e7b-7041-474b-8fc8-6e4aa14204e5}">
            <rule filter="&quot;ZUSTAND&quot; = 1" label="Cu-Kabel u.i. in neu" key="{442ce49f-5eb8-44ea-aefb-ae7e023c7363}" symbol="4"/>
            <rule filter="&quot;ZUSTAND&quot; = 2" label="Cu-Kabel u.i. in Bestand" key="{ca608f35-36fe-45ae-9e0c-bd7a90ccce10}" symbol="5"/>
          </rule>
          <rule filter="&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%'" label="Cu-Kabel o.i." key="{23856506-c018-43a4-9f96-4b8bf313f5e8}">
            <rule filter="&quot;ZUSTAND&quot; = 1" label="Cu-Kabel o.i. neu" key="{0f52aca9-e54d-4814-ac86-e11c119e1e52}" symbol="6"/>
            <rule filter="&quot;ZUSTAND&quot; = 2" label="Cu-Kabel o.i. Bestand" key="{17509443-fb1e-4f18-a4f4-ace95c3966c3}" symbol="7"/>
          </rule>
        </rule>
        <rule filter="&quot;VERB_ART&quot; = 99 AND (&quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )" label="FSP-Kabel" key="{7384fc44-28db-424f-93e4-6a1041e303f2}">
          <rule filter="&quot;ZUSTAND&quot; = 1 " label="FSP-Kabel in neu" key="{b5f680ec-12bc-4deb-b4f0-afdb73a27fa0}" symbol="8"/>
          <rule filter="&quot;ZUSTAND&quot; = 2" label="FSP-Kabel in Bestand" key="{44045546-713a-45de-a98a-5c40d4dd8ccb}" symbol="9"/>
        </rule>
        <rule filter="&quot;VERB_ART&quot; = 2" label="&quot;VERB_ART&quot; 2 > korrigieren" key="{00db33c4-74e7-4dee-adbd-aeb3e0c448ff}" symbol="10"/>
      </rule>
      <rule label="alle Kabel" key="{800d2046-1cd7-4cec-82b1-b1820fe69afa}" checkstate="0" symbol="11"/>
      <rule label="Prüfung" key="{349379fc-5856-4f38-94aa-93b43f1b2411}" checkstate="0">
        <rule filter=" &quot;VERB_ART&quot; NOT IN (1,5,6,7,8,9,10,11,99)" label="Verb_Art unplausibel" key="{a49bdf4c-743c-49a1-8a65-bd2754603254}" checkstate="0" symbol="12"/>
        <rule filter="((&quot;Verb_Art&quot; != 5 AND &quot;Anzahl_F_A&quot; = 6) OR (&quot;Verb_Art&quot; != 6 AND &quot;Anzahl_F_A&quot; = 12) OR (&quot;Verb_Art&quot; != 7 AND &quot;Anzahl_F_A&quot; = 24) OR (&quot;Verb_Art&quot; != 8 AND &quot;Anzahl_F_A&quot; = 48) OR (&quot;Verb_Art&quot; != 9 AND &quot;Anzahl_F_A&quot; = 72) OR (&quot;Verb_Art&quot; != 10 AND &quot;Anzahl_F_A&quot; = 96) OR (&quot;Verb_Art&quot; != 11 AND &quot;Anzahl_F_A&quot; = 144)) OR ((&quot;Verb_Art&quot; = 5 AND &quot;Anzahl_F_A&quot; != 6) OR (&quot;Verb_Art&quot; = 6 AND &quot;Anzahl_F_A&quot; != 12) OR (&quot;Verb_Art&quot; = 7 AND &quot;Anzahl_F_A&quot; != 24) OR (&quot;Verb_Art&quot; = 8 AND &quot;Anzahl_F_A&quot; != 48) OR (&quot;Verb_Art&quot; = 9 AND &quot;Anzahl_F_A&quot; != 72) OR (&quot;Verb_Art&quot; = 10 AND &quot;Anzahl_F_A&quot; != 96) OR (&quot;Verb_Art&quot; = 11 AND &quot;Anzahl_F_A&quot; != 144))" label="Gf: Anzahl_F_A entspricht nicht Verb_ Art" key="{715c05cc-a471-4d3e-9b18-03910ed20172}" checkstate="0" symbol="13"/>
        <rule filter="((&quot;Verb_Art&quot; = 1 AND &quot;Anzahl_F_A&quot; NOT IN (2,10,20,30,40,50,70,100,150,200,250,300,500,1000))) OR ((&quot;Verb_Art&quot; != 1 AND &quot;Anzahl_F_A&quot; IN (2,10,20,30,40,50,70,100,150,200,250,300,500,1000))) AND NOT (&quot;VERB_ART&quot; = 99 AND (&quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%'))" label="Cu: Anzahl_F_A entspricht nicht Verb_ Art" key="{22d38f42-194a-4346-bbe7-52ce15a2e5ea}" checkstate="0" symbol="14"/>
        <rule filter=" &quot;F_A_RESERV&quot; >= &quot;ANZAHL_F_A&quot; " label="F_A_Reserve größer od. gleich ANZAHL_F_A" key="{eeb89f6f-50fd-4378-9cdf-0f08ad132636}" checkstate="0" symbol="15"/>
        <rule filter=" &quot;F_A_RESERV&quot; &lt; 0" label="F_A_Reserve kleiner 0" key="{4c243821-e8ab-4700-9936-2a7d615038ff}" checkstate="0" symbol="16"/>
        <rule filter=" &quot;ZUSTAND&quot; = 2 AND  &quot;F_A_RESERV&quot;  != 0" label="F_A_Reserve bei Bestand nicht  '0'" key="{f79bf7a4-1276-4c17-abbd-b8b71418ed3e}" checkstate="0" symbol="17"/>
        <rule filter=" &quot;Verb_Art&quot; != 1 AND &quot;ZUSTAND&quot; = 1 AND  &quot;F_A_RESERV&quot; = 0" label="Wirklich F_A_Reserve bei neu = '0'?" key="{34748ed0-af2c-4b4f-ad81-61d1d828452a}" checkstate="0" symbol="18"/>
        <rule filter=" &quot;Verb_Art&quot; IS NULL OR &quot;Lae_Kabel&quot; IS NULL OR &quot;Anzahl_F_A&quot; IS NULL OR &quot;F_A_Reserv&quot; IS NULL OR &quot;Zustand&quot; IS NULL" label="Fehlende Attribute" key="{5f67dee0-aa9f-4edf-9990-cbf46058a469}" checkstate="0" symbol="19"/>
      </rule>
    </rules>
    <symbols>
      <symbol alpha="1" type="line" force_rhr="0" name="0" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="7" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="255,0,0,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="1" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="255,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="1"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="73,190,253,255" name="single_color"/>
                <Option type="QString" value="1" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="73,190,253,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="0.146" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="0.146"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.386" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="253,253,253,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.386"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="253,253,253,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="7" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="73,190,253,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="73,190,253,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="1" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="6" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="0,0,0,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="0,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="6" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="73,190,253,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="73,190,253,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="10" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="163,3,255,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="1.36" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.466" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,0,0,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,187,5,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.985641" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="11" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="163,3,255,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="1.36" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,187,5,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.985641" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="12" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="163,3,255,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="1.36" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.466" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,0,0,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,187,5,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.985641" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="13" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="163,3,255,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="1.36" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.466" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,0,0,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,187,5,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.985641" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="14" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="163,3,255,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="1.36" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.466" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,0,0,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,187,5,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.985641" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="15" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="163,3,255,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="1.36" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.466" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,0,0,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,187,5,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.985641" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="16" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="163,3,255,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="1.36" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.466" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,0,0,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,187,5,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.985641" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="17" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="163,3,255,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="1.36" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.466" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,0,0,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,187,5,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.985641" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="18" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="163,3,255,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="1.36" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.466" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,0,0,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,187,5,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.985641" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="19" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="163,3,255,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="1.36" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="163,3,255,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="1.36"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="1">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.466" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,0,0,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.466"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,0,0,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="12" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,187,5,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.985641" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.985641"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="2" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="11" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="255,0,0,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="1" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="255,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="1"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="73,190,253,255" name="single_color"/>
                <Option type="QString" value="1" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="73,190,253,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="0.146" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="0.146"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.386" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="253,253,253,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.386"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="253,253,253,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="11" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="150,28,150,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="150,28,150,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="3" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="10" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="0,0,0,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="1" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="0,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="1"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="239,0,4,255" name="single_color"/>
                <Option type="QString" value="1" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="239,0,4,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="0.146" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="0.146"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.386" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="253,253,253,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.386"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="253,253,253,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="10" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="236,82,239,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.504" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="236,82,239,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.504"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="4" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="5" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="255,0,0,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="255,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="239,0,4,255" name="single_color"/>
                <Option type="QString" value="1" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="239,0,4,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="5" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,187,5,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="5" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="4" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="0,0,0,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="0,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="4" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,187,5,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,187,5,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="6" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="9" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="255,0,0,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="1" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="255,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="1"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="0,239,39,255" name="single_color"/>
                <Option type="QString" value="1" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="0,239,39,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="0.146" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="0.146"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.386" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="253,253,253,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.386"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="253,253,253,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="9" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,239,39,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="0,239,39,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="7" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="8" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="0,0,0,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="1" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="0,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="1"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="239,0,4,255" name="single_color"/>
                <Option type="QString" value="1" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="239,0,4,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="0.146" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="0.146"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.386" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="253,253,253,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.386"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="253,253,253,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="0" pass="8" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="square" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="0,239,39,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="square"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="0,239,39,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="8" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="3" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="255,0,0,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="255,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="239,0,4,255" name="single_color"/>
                <Option type="QString" value="1" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="239,0,4,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="3" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,238,27,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,238,27,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol alpha="1" type="line" force_rhr="0" name="9" clip_to_extent="1">
        <data_defined_properties>
          <Option type="Map">
            <Option type="QString" value="" name="name"/>
            <Option name="properties"/>
            <Option type="QString" value="collection" name="type"/>
          </Option>
        </data_defined_properties>
        <layer locked="0" pass="2" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="round" name="joinstyle"/>
            <Option type="QString" value="0,0,0,255" name="line_color"/>
            <Option type="QString" value="solid" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="round"/>
          <prop k="line_color" v="0,0,0,255"/>
          <prop k="line_style" v="solid"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <effect type="effectStack" enabled="0">
            <effect type="dropShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="239,0,4,255" name="single_color"/>
                <Option type="QString" value="1" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="239,0,4,255"/>
              <prop k="spread" v="1"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="1" name="enabled"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="1"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option type="QString" value="13" name="blend_mode"/>
                <Option type="QString" value="2.645" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,0,255" name="color"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="135" name="offset_angle"/>
                <Option type="QString" value="2" name="offset_distance"/>
                <Option type="QString" value="MM" name="offset_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_unit_scale"/>
                <Option type="QString" value="1" name="opacity"/>
              </Option>
              <prop k="blend_mode" v="13"/>
              <prop k="blur_level" v="2.645"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color" v="0,0,0,255"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="offset_angle" v="135"/>
              <prop k="offset_distance" v="2"/>
              <prop k="offset_unit" v="MM"/>
              <prop k="offset_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="opacity" v="1"/>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option type="QString" value="0" name="blend_mode"/>
                <Option type="QString" value="0.7935" name="blur_level"/>
                <Option type="QString" value="MM" name="blur_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="blur_unit_scale"/>
                <Option type="QString" value="0,0,255,255" name="color1"/>
                <Option type="QString" value="0,255,0,255" name="color2"/>
                <Option type="QString" value="0" name="color_type"/>
                <Option type="QString" value="0" name="discrete"/>
                <Option type="QString" value="2" name="draw_mode"/>
                <Option type="QString" value="0" name="enabled"/>
                <Option type="QString" value="0.5" name="opacity"/>
                <Option type="QString" value="gradient" name="rampType"/>
                <Option type="QString" value="255,255,255,255" name="single_color"/>
                <Option type="QString" value="2" name="spread"/>
                <Option type="QString" value="MM" name="spread_unit"/>
                <Option type="QString" value="3x:0,0,0,0,0,0" name="spread_unit_scale"/>
              </Option>
              <prop k="blend_mode" v="0"/>
              <prop k="blur_level" v="0.7935"/>
              <prop k="blur_unit" v="MM"/>
              <prop k="blur_unit_scale" v="3x:0,0,0,0,0,0"/>
              <prop k="color1" v="0,0,255,255"/>
              <prop k="color2" v="0,255,0,255"/>
              <prop k="color_type" v="0"/>
              <prop k="discrete" v="0"/>
              <prop k="draw_mode" v="2"/>
              <prop k="enabled" v="0"/>
              <prop k="opacity" v="0.5"/>
              <prop k="rampType" v="gradient"/>
              <prop k="single_color" v="255,255,255,255"/>
              <prop k="spread" v="2"/>
              <prop k="spread_unit" v="MM"/>
              <prop k="spread_unit_scale" v="3x:0,0,0,0,0,0"/>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer locked="1" pass="2" class="SimpleLine" enabled="1">
          <Option type="Map">
            <Option type="QString" value="0" name="align_dash_pattern"/>
            <Option type="QString" value="round" name="capstyle"/>
            <Option type="QString" value="5;2" name="customdash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
            <Option type="QString" value="MM" name="customdash_unit"/>
            <Option type="QString" value="0" name="dash_pattern_offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
            <Option type="QString" value="0" name="draw_inside_polygon"/>
            <Option type="QString" value="bevel" name="joinstyle"/>
            <Option type="QString" value="253,238,27,255" name="line_color"/>
            <Option type="QString" value="dot" name="line_style"/>
            <Option type="QString" value="0.7" name="line_width"/>
            <Option type="QString" value="MM" name="line_width_unit"/>
            <Option type="QString" value="0" name="offset"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
            <Option type="QString" value="MM" name="offset_unit"/>
            <Option type="QString" value="0" name="ring_filter"/>
            <Option type="QString" value="0" name="trim_distance_end"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_end_unit"/>
            <Option type="QString" value="0" name="trim_distance_start"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
            <Option type="QString" value="MM" name="trim_distance_start_unit"/>
            <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
            <Option type="QString" value="0" name="use_custom_dash"/>
            <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
          </Option>
          <prop k="align_dash_pattern" v="0"/>
          <prop k="capstyle" v="round"/>
          <prop k="customdash" v="5;2"/>
          <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="customdash_unit" v="MM"/>
          <prop k="dash_pattern_offset" v="0"/>
          <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="dash_pattern_offset_unit" v="MM"/>
          <prop k="draw_inside_polygon" v="0"/>
          <prop k="joinstyle" v="bevel"/>
          <prop k="line_color" v="253,238,27,255"/>
          <prop k="line_style" v="dot"/>
          <prop k="line_width" v="0.7"/>
          <prop k="line_width_unit" v="MM"/>
          <prop k="offset" v="0"/>
          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="offset_unit" v="MM"/>
          <prop k="ring_filter" v="0"/>
          <prop k="trim_distance_end" v="0"/>
          <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_end_unit" v="MM"/>
          <prop k="trim_distance_start" v="0"/>
          <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <prop k="trim_distance_start_unit" v="MM"/>
          <prop k="tweak_dash_pattern_on_corners" v="0"/>
          <prop k="use_custom_dash" v="0"/>
          <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <labeling type="rule-based">
    <rules key="{ff8e5da2-f8b7-48df-bd7d-e8dedb2ee158}">
      <rule description="ohne Reserve" filter="1" key="{561969e0-effd-4d4f-ab12-19554725606d}">
        <rule description="Gf-Kabel" filter="&quot;VERB_ART&quot; IN (5,6,7,8,9,10,11,99)" key="{39c4158a-90c1-4cec-a108-af7f9a9df645}" scalemindenom="1" scalemaxdenom="4000">
          <rule description="u.i." key="{82831ed3-e29a-4ce4-8d51-d19ffe5327c3}">
            <rule description="Bezeichnung ist vorhanden" filter="(&quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' OR &quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )) AND NOT (&quot;bezeichnung&quot; IS NULL)" key="{1076aa92-eb23-4a81-ae57-acb8bf9c76fd}">
              <rule description="Gf-Kabel u.i. neu" filter="&quot;ZUSTAND&quot; = 1" key="{91158631-5205-45c7-ae99-38c76e06f334}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  FS ' || '(' || &quot;bezeichnung&quot;  || ') '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="0,0,0,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="255,206,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="190,207,80,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="190,207,80,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="255,206,255,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="255,206,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Gf-Kabel u.i. Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{7eb99752-f448-47ed-a80c-fb7b76555c61}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  FS ' || '(' || &quot;bezeichnung&quot;  || ') '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="Point" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="152,125,183,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="152,125,183,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="0,0,0,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
            <rule description="Bezeichnung is NULL" filter="(&quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' OR &quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )) AND (&quot;bezeichnung&quot; IS NULL)" key="{057bbaa0-86df-4b7b-851d-7ea66e68a6ba}">
              <rule description="Gf-Kabel u.i. neu" filter="&quot;ZUSTAND&quot; = 1" key="{4c3801aa-f7c8-467d-ba85-fa0d7afab932}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  FS '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="0,0,0,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="255,206,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="190,207,80,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="190,207,80,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="255,206,255,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="255,206,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Gf-Kabel u.i. Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{9bb8eb9c-2524-4411-b7dc-5378dd824ce1}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  FS '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="Point" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="152,125,183,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="152,125,183,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="0,0,0,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
          </rule>
          <rule description="o.i." key="{f60dff8c-c291-4860-b80b-b3f988865b61}">
            <rule description="Bezeichnung ist vorhanden" filter="(&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%') AND NOT (&quot;bezeichnung&quot; IS NULL)" key="{c7277957-47fc-4f9d-b75f-3d117ad25872}">
              <rule description="Gf-Kabel o.i. neu" filter="&quot;ZUSTAND&quot; = 1" key="{8ba01233-8659-45fc-9e44-0f1f39dad847}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  FS ' || '(' || &quot;bezeichnung&quot;  || ') '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="0,0,0,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="255,206,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="225,89,137,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="225,89,137,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="255,206,255,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="255,206,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Gf-Kabel o.i. Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{16a6e591-8582-4355-9144-30f1a9f76172}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  FS ' || '(' || &quot;bezeichnung&quot;  || ') '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="183,72,75,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="183,72,75,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="0,0,0,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="u.i." key="{b71429b1-9d2b-47bf-ae9e-54dcad744e90}"/>
            </rule>
            <rule description="Bezeichnung is NULL" filter="(&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%') AND (&quot;bezeichnung&quot; IS NULL)" key="{d47bf388-220a-4fc7-91a9-b556c0eb0826}">
              <rule description="Gf-Kabel o.i. neu" filter="&quot;ZUSTAND&quot; = 1" key="{97d44532-2283-4686-ba8b-3ea3a8bbb541}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  FS '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="0,0,0,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="255,206,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="225,89,137,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="225,89,137,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="255,206,255,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="255,206,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Gf-Kabel o.i. Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{d730b77a-4e40-492b-a0f7-6905194ea9cd}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  FS '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="183,72,75,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="183,72,75,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="0,0,0,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
          </rule>
        </rule>
        <rule description="Cu-Kabel" filter="&quot;VERB_ART&quot; = 1" key="{421b6b45-759e-4977-9be3-534cecb2a338}" scalemindenom="1" scalemaxdenom="4000">
          <rule description="u.i." key="{01c1917d-f532-477b-adf7-d3e1e32e8097}">
            <rule description="Bezeichnung ist vorhanden" filter="(&quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )) AND NOT (&quot;bezeichnung&quot; IS NULL)" key="{f6f2560d-e509-4c0e-9cdf-7c53ec7ed65d}">
              <rule description="Cu-Kabel u.i. in neu" filter="&quot;ZUSTAND&quot; = 1" key="{e869b188-bf17-47f1-bc08-6bbf2f6c6c5b}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  DA' || '(' || &quot;bezeichnung&quot;  || ') '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="194,50,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="255,158,23,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="255,158,23,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="194,50,255,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="194,50,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Cu-Kabel u.i. in Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{71f16a87-9ff4-48a8-8d48-b3d944bf3a61}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  DA' || '(' || &quot;bezeichnung&quot;  || ') '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="141,90,153,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="141,90,153,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="0,0,0,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
            <rule description="Bezeichnung is NULL" filter="(&quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )) AND (&quot;bezeichnung&quot; IS NULL)" key="{13318dc7-1020-4898-b25c-d4a889d3a75c}">
              <rule description="Cu-Kabel u.i. in neu" filter="&quot;ZUSTAND&quot; = 1" key="{dbdfbca6-bc76-4e23-96fa-1e9276d0b8a8}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  DA'" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="194,50,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="255,158,23,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="255,158,23,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="194,50,255,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="194,50,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Cu-Kabel u.i. in Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{c9ea4697-cf56-4a1d-b928-f7a6e896e01e}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  DA'" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="141,90,153,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="141,90,153,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="0,0,0,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
          </rule>
          <rule description="o.i." key="{3dac24c5-1c76-4274-88c9-daecd7224300}">
            <rule description="Bezeichnung ist vorhanden" filter="(&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%') AND NOT (&quot;bezeichnung&quot; IS NULL)" key="{d144294f-101d-40ff-a814-b4537700dc88}">
              <rule description="Cu-Kabel o.i. neu" filter="&quot;ZUSTAND&quot; = 1" key="{f6d294f1-de9e-4b0f-a38c-bd812c1f2567}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA ' || '(' || &quot;bezeichnung&quot;  || ') '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="194,50,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="243,166,178,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="243,166,178,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="194,50,255,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="194,50,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Cu-Kabel o.i. Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{eaa476ab-7974-44ee-975d-18e384ba2f38}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA ' || '(' || &quot;bezeichnung&quot;  || ') '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="213,180,60,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="213,180,60,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="0,0,0,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
            <rule description="Bezeichnung is NULL" filter="(&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%') AND (&quot;bezeichnung&quot; IS NULL)" key="{e9b45581-d419-469b-983d-1d90e05ffc1b}">
              <rule description="Cu-Kabel o.i. neu" filter="&quot;ZUSTAND&quot; = 1" key="{36afa1e6-0e82-43bc-b2bd-1f0379ed57c4}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="194,50,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="243,166,178,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="243,166,178,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="194,50,255,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="194,50,255,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
              <rule description="Cu-Kabel o.i. Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{e6e10709-20f0-46f5-85fb-9794b5e4bbef}">
                <settings calloutType="simple">
                  <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                    <families/>
                    <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                    <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                    <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                      <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="0" name="angle"/>
                            <Option type="QString" value="square" name="cap_style"/>
                            <Option type="QString" value="213,180,60,255" name="color"/>
                            <Option type="QString" value="1" name="horizontal_anchor_point"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="circle" name="name"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="35,35,35,255" name="outline_color"/>
                            <Option type="QString" value="solid" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="diameter" name="scale_method"/>
                            <Option type="QString" value="2" name="size"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                            <Option type="QString" value="MM" name="size_unit"/>
                            <Option type="QString" value="1" name="vertical_anchor_point"/>
                          </Option>
                          <prop k="angle" v="0"/>
                          <prop k="cap_style" v="square"/>
                          <prop k="color" v="213,180,60,255"/>
                          <prop k="horizontal_anchor_point" v="1"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="name" v="circle"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="35,35,35,255"/>
                          <prop k="outline_style" v="solid"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="scale_method" v="diameter"/>
                          <prop k="size" v="2"/>
                          <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="size_unit" v="MM"/>
                          <prop k="vertical_anchor_point" v="1"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                      <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                        <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                          <Option type="Map">
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                            <Option type="QString" value="0,0,0,255" name="color"/>
                            <Option type="QString" value="bevel" name="joinstyle"/>
                            <Option type="QString" value="0,0" name="offset"/>
                            <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                            <Option type="QString" value="MM" name="offset_unit"/>
                            <Option type="QString" value="128,128,128,255" name="outline_color"/>
                            <Option type="QString" value="no" name="outline_style"/>
                            <Option type="QString" value="0" name="outline_width"/>
                            <Option type="QString" value="MM" name="outline_width_unit"/>
                            <Option type="QString" value="solid" name="style"/>
                          </Option>
                          <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="color" v="0,0,0,255"/>
                          <prop k="joinstyle" v="bevel"/>
                          <prop k="offset" v="0,0"/>
                          <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                          <prop k="offset_unit" v="MM"/>
                          <prop k="outline_color" v="128,128,128,255"/>
                          <prop k="outline_style" v="no"/>
                          <prop k="outline_width" v="0"/>
                          <prop k="outline_width_unit" v="MM"/>
                          <prop k="style" v="solid"/>
                          <data_defined_properties>
                            <Option type="Map">
                              <Option type="QString" value="" name="name"/>
                              <Option name="properties"/>
                              <Option type="QString" value="collection" name="type"/>
                            </Option>
                          </data_defined_properties>
                        </layer>
                      </symbol>
                    </background>
                    <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                    <dd_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </dd_properties>
                    <substitutions/>
                  </text-style>
                  <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                  <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                  <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <callout type="simple">
                    <Option type="Map">
                      <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                      <Option type="int" value="0" name="blendMode"/>
                      <Option type="Map" name="ddProperties">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                      <Option type="bool" value="false" name="drawToAllParts"/>
                      <Option type="QString" value="0" name="enabled"/>
                      <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                      <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                      <Option type="double" value="0" name="minLength"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                      <Option type="QString" value="MM" name="minLengthUnit"/>
                      <Option type="double" value="0" name="offsetFromAnchor"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                      <Option type="double" value="0" name="offsetFromLabel"/>
                      <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                      <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                    </Option>
                  </callout>
                </settings>
              </rule>
            </rule>
          </rule>
        </rule>
        <rule description="FSP-Kabel" filter="&quot;VERB_ART&quot; = 99 AND (&quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )" key="{3b0fdee9-9e89-4eba-a0f2-9cfcc75dd803}" scalemindenom="1" scalemaxdenom="4000">
          <rule description="FSP-Kabel in neu" filter="&quot;ZUSTAND&quot; = 1" key="{9496c8e2-dcf8-4e49-aae1-f37e5922cd1d}">
            <settings calloutType="simple">
              <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' FSP '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                <families/>
                <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="194,50,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                  <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </data_defined_properties>
                    <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                      <Option type="Map">
                        <Option type="QString" value="0" name="angle"/>
                        <Option type="QString" value="square" name="cap_style"/>
                        <Option type="QString" value="125,139,143,255" name="color"/>
                        <Option type="QString" value="1" name="horizontal_anchor_point"/>
                        <Option type="QString" value="bevel" name="joinstyle"/>
                        <Option type="QString" value="circle" name="name"/>
                        <Option type="QString" value="0,0" name="offset"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                        <Option type="QString" value="MM" name="offset_unit"/>
                        <Option type="QString" value="35,35,35,255" name="outline_color"/>
                        <Option type="QString" value="solid" name="outline_style"/>
                        <Option type="QString" value="0" name="outline_width"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                        <Option type="QString" value="MM" name="outline_width_unit"/>
                        <Option type="QString" value="diameter" name="scale_method"/>
                        <Option type="QString" value="2" name="size"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                        <Option type="QString" value="MM" name="size_unit"/>
                        <Option type="QString" value="1" name="vertical_anchor_point"/>
                      </Option>
                      <prop k="angle" v="0"/>
                      <prop k="cap_style" v="square"/>
                      <prop k="color" v="125,139,143,255"/>
                      <prop k="horizontal_anchor_point" v="1"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="name" v="circle"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="35,35,35,255"/>
                      <prop k="outline_style" v="solid"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="scale_method" v="diameter"/>
                      <prop k="size" v="2"/>
                      <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="size_unit" v="MM"/>
                      <prop k="vertical_anchor_point" v="1"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                  <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </data_defined_properties>
                    <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                      <Option type="Map">
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                        <Option type="QString" value="194,50,255,255" name="color"/>
                        <Option type="QString" value="bevel" name="joinstyle"/>
                        <Option type="QString" value="0,0" name="offset"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                        <Option type="QString" value="MM" name="offset_unit"/>
                        <Option type="QString" value="128,128,128,255" name="outline_color"/>
                        <Option type="QString" value="no" name="outline_style"/>
                        <Option type="QString" value="0" name="outline_width"/>
                        <Option type="QString" value="MM" name="outline_width_unit"/>
                        <Option type="QString" value="solid" name="style"/>
                      </Option>
                      <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="color" v="194,50,255,255"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="128,128,128,255"/>
                      <prop k="outline_style" v="no"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="style" v="solid"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                </background>
                <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                </dd_properties>
                <substitutions/>
              </text-style>
              <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
              <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
              <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
              <dd_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name"/>
                  <Option name="properties"/>
                  <Option type="QString" value="collection" name="type"/>
                </Option>
              </dd_properties>
              <callout type="simple">
                <Option type="Map">
                  <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                  <Option type="int" value="0" name="blendMode"/>
                  <Option type="Map" name="ddProperties">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                  <Option type="bool" value="false" name="drawToAllParts"/>
                  <Option type="QString" value="0" name="enabled"/>
                  <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                  <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                  <Option type="double" value="0" name="minLength"/>
                  <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                  <Option type="QString" value="MM" name="minLengthUnit"/>
                  <Option type="double" value="0" name="offsetFromAnchor"/>
                  <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                  <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                  <Option type="double" value="0" name="offsetFromLabel"/>
                  <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                  <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                </Option>
              </callout>
            </settings>
          </rule>
          <rule description="FSP-Kabel in Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{d6c6fa1d-8bb3-48cc-aff6-ec3d89031588}">
            <settings calloutType="simple">
              <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' FSP '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                <families/>
                <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                  <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </data_defined_properties>
                    <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                      <Option type="Map">
                        <Option type="QString" value="0" name="angle"/>
                        <Option type="QString" value="square" name="cap_style"/>
                        <Option type="QString" value="133,182,111,255" name="color"/>
                        <Option type="QString" value="1" name="horizontal_anchor_point"/>
                        <Option type="QString" value="bevel" name="joinstyle"/>
                        <Option type="QString" value="circle" name="name"/>
                        <Option type="QString" value="0,0" name="offset"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                        <Option type="QString" value="MM" name="offset_unit"/>
                        <Option type="QString" value="35,35,35,255" name="outline_color"/>
                        <Option type="QString" value="solid" name="outline_style"/>
                        <Option type="QString" value="0" name="outline_width"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                        <Option type="QString" value="MM" name="outline_width_unit"/>
                        <Option type="QString" value="diameter" name="scale_method"/>
                        <Option type="QString" value="2" name="size"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                        <Option type="QString" value="MM" name="size_unit"/>
                        <Option type="QString" value="1" name="vertical_anchor_point"/>
                      </Option>
                      <prop k="angle" v="0"/>
                      <prop k="cap_style" v="square"/>
                      <prop k="color" v="133,182,111,255"/>
                      <prop k="horizontal_anchor_point" v="1"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="name" v="circle"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="35,35,35,255"/>
                      <prop k="outline_style" v="solid"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="scale_method" v="diameter"/>
                      <prop k="size" v="2"/>
                      <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="size_unit" v="MM"/>
                      <prop k="vertical_anchor_point" v="1"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                  <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </data_defined_properties>
                    <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                      <Option type="Map">
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                        <Option type="QString" value="0,0,0,255" name="color"/>
                        <Option type="QString" value="bevel" name="joinstyle"/>
                        <Option type="QString" value="0,0" name="offset"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                        <Option type="QString" value="MM" name="offset_unit"/>
                        <Option type="QString" value="128,128,128,255" name="outline_color"/>
                        <Option type="QString" value="no" name="outline_style"/>
                        <Option type="QString" value="0" name="outline_width"/>
                        <Option type="QString" value="MM" name="outline_width_unit"/>
                        <Option type="QString" value="solid" name="style"/>
                      </Option>
                      <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="color" v="0,0,0,255"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="128,128,128,255"/>
                      <prop k="outline_style" v="no"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="style" v="solid"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                </background>
                <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                </dd_properties>
                <substitutions/>
              </text-style>
              <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
              <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
              <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
              <dd_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name"/>
                  <Option name="properties"/>
                  <Option type="QString" value="collection" name="type"/>
                </Option>
              </dd_properties>
              <callout type="simple">
                <Option type="Map">
                  <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                  <Option type="int" value="0" name="blendMode"/>
                  <Option type="Map" name="ddProperties">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                  <Option type="bool" value="false" name="drawToAllParts"/>
                  <Option type="QString" value="0" name="enabled"/>
                  <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                  <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                  <Option type="double" value="0" name="minLength"/>
                  <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                  <Option type="QString" value="MM" name="minLengthUnit"/>
                  <Option type="double" value="0" name="offsetFromAnchor"/>
                  <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                  <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                  <Option type="double" value="0" name="offsetFromLabel"/>
                  <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                  <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                </Option>
              </callout>
            </settings>
          </rule>
        </rule>
      </rule>
      <rule description="mit Reserve" filter="0" key="{77608cdc-9c4c-4f83-a474-18476080e80b}">
        <rule description="Gf-Kabel" filter="&quot;VERB_ART&quot; IN (5,6,7,8,9,10,11,99)" key="{6b24d361-a64e-40f7-858f-c03b08cec7af}" scalemindenom="1" scalemaxdenom="4000">
          <rule description="Gf-Kabel u.i." filter=" &quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' OR &quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )" key="{8a4f604b-0ade-4df9-a530-69709cb4a47f}">
            <rule description="Gf-Kabel u.i. neu" filter="&quot;ZUSTAND&quot; = 1" key="{2dd9b057-80f9-4c65-a5fe-385bebf27e7a}" active="0">
              <settings calloutType="simple">
                <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  FS l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="0,0,0,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                  <families/>
                  <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                  <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                  <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="255,206,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                    <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="0" name="angle"/>
                          <Option type="QString" value="square" name="cap_style"/>
                          <Option type="QString" value="190,207,80,255" name="color"/>
                          <Option type="QString" value="1" name="horizontal_anchor_point"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="circle" name="name"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="35,35,35,255" name="outline_color"/>
                          <Option type="QString" value="solid" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="diameter" name="scale_method"/>
                          <Option type="QString" value="2" name="size"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                          <Option type="QString" value="MM" name="size_unit"/>
                          <Option type="QString" value="1" name="vertical_anchor_point"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="190,207,80,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                          <Option type="QString" value="255,206,255,255" name="color"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="128,128,128,255" name="outline_color"/>
                          <Option type="QString" value="no" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="solid" name="style"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="255,206,255,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                    <Option type="int" value="0" name="blendMode"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                    <Option type="bool" value="false" name="drawToAllParts"/>
                    <Option type="QString" value="0" name="enabled"/>
                    <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                    <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                    <Option type="double" value="0" name="minLength"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                    <Option type="QString" value="MM" name="minLengthUnit"/>
                    <Option type="double" value="0" name="offsetFromAnchor"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                    <Option type="double" value="0" name="offsetFromLabel"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                  </Option>
                </callout>
              </settings>
            </rule>
            <rule description="Gf-Kabel u.i. Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{a6341a6e-48af-4d5f-94c1-20ea2719d15a}" active="0">
              <settings calloutType="simple">
                <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  FS l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                  <families/>
                  <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                  <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                  <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="Point" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                    <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="0" name="angle"/>
                          <Option type="QString" value="square" name="cap_style"/>
                          <Option type="QString" value="152,125,183,255" name="color"/>
                          <Option type="QString" value="1" name="horizontal_anchor_point"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="circle" name="name"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="35,35,35,255" name="outline_color"/>
                          <Option type="QString" value="solid" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="diameter" name="scale_method"/>
                          <Option type="QString" value="2" name="size"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                          <Option type="QString" value="MM" name="size_unit"/>
                          <Option type="QString" value="1" name="vertical_anchor_point"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="152,125,183,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                          <Option type="QString" value="0,0,0,255" name="color"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="128,128,128,255" name="outline_color"/>
                          <Option type="QString" value="no" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="solid" name="style"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="0,0,0,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                    <Option type="int" value="0" name="blendMode"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                    <Option type="bool" value="false" name="drawToAllParts"/>
                    <Option type="QString" value="0" name="enabled"/>
                    <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                    <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                    <Option type="double" value="0" name="minLength"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                    <Option type="QString" value="MM" name="minLengthUnit"/>
                    <Option type="double" value="0" name="offsetFromAnchor"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                    <Option type="double" value="0" name="offsetFromLabel"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                  </Option>
                </callout>
              </settings>
            </rule>
          </rule>
          <rule description="Gf-Kabel o.i." filter="&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%'" key="{1e5f5c7a-6a6b-4992-8a53-d97759a3eb99}">
            <rule description="Gf-Kabel o.i. neu" filter="&quot;ZUSTAND&quot; = 1" key="{f244477d-0b7e-4ed5-8b9d-dfd4fb240bc2}" active="0">
              <settings calloutType="simple">
                <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  FS l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="0,0,0,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                  <families/>
                  <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                  <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                  <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="255,206,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                    <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="0" name="angle"/>
                          <Option type="QString" value="square" name="cap_style"/>
                          <Option type="QString" value="225,89,137,255" name="color"/>
                          <Option type="QString" value="1" name="horizontal_anchor_point"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="circle" name="name"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="35,35,35,255" name="outline_color"/>
                          <Option type="QString" value="solid" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="diameter" name="scale_method"/>
                          <Option type="QString" value="2" name="size"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                          <Option type="QString" value="MM" name="size_unit"/>
                          <Option type="QString" value="1" name="vertical_anchor_point"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="225,89,137,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                          <Option type="QString" value="255,206,255,255" name="color"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="128,128,128,255" name="outline_color"/>
                          <Option type="QString" value="no" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="solid" name="style"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="255,206,255,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                    <Option type="int" value="0" name="blendMode"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                    <Option type="bool" value="false" name="drawToAllParts"/>
                    <Option type="QString" value="0" name="enabled"/>
                    <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                    <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                    <Option type="double" value="0" name="minLength"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                    <Option type="QString" value="MM" name="minLengthUnit"/>
                    <Option type="double" value="0" name="offsetFromAnchor"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                    <Option type="double" value="0" name="offsetFromLabel"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                  </Option>
                </callout>
              </settings>
            </rule>
            <rule description="Gf-Kabel o.i. Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{6d893021-39c9-44bd-b674-10918313a12a}" active="0">
              <settings calloutType="simple">
                <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  FS l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                  <families/>
                  <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                  <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                  <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                    <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="0" name="angle"/>
                          <Option type="QString" value="square" name="cap_style"/>
                          <Option type="QString" value="183,72,75,255" name="color"/>
                          <Option type="QString" value="1" name="horizontal_anchor_point"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="circle" name="name"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="35,35,35,255" name="outline_color"/>
                          <Option type="QString" value="solid" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="diameter" name="scale_method"/>
                          <Option type="QString" value="2" name="size"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                          <Option type="QString" value="MM" name="size_unit"/>
                          <Option type="QString" value="1" name="vertical_anchor_point"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="183,72,75,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                          <Option type="QString" value="0,0,0,255" name="color"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="128,128,128,255" name="outline_color"/>
                          <Option type="QString" value="no" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="solid" name="style"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="0,0,0,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                    <Option type="int" value="0" name="blendMode"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                    <Option type="bool" value="false" name="drawToAllParts"/>
                    <Option type="QString" value="0" name="enabled"/>
                    <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                    <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                    <Option type="double" value="0" name="minLength"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                    <Option type="QString" value="MM" name="minLengthUnit"/>
                    <Option type="double" value="0" name="offsetFromAnchor"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                    <Option type="double" value="0" name="offsetFromLabel"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                  </Option>
                </callout>
              </settings>
            </rule>
          </rule>
        </rule>
        <rule description="Cu-Kabel" filter="&quot;VERB_ART&quot; = 1" key="{20e31bb5-4539-463a-864e-e45e7249923f}" scalemindenom="1" scalemaxdenom="4000">
          <rule description="Cu-Kabel u.i." filter=" &quot;V_A_SONST&quot; IS NULL OR NOT (&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%' )" key="{414fdb55-24fa-485d-b27e-8a6bd00f3708}">
            <rule description="Cu-Kabel u.i. in neu" filter="&quot;ZUSTAND&quot; = 1" key="{3d599dd8-c589-43cf-afa8-27524b20fa20}" active="0">
              <settings calloutType="simple">
                <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  DA l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                  <families/>
                  <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                  <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                  <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="194,50,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                    <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="0" name="angle"/>
                          <Option type="QString" value="square" name="cap_style"/>
                          <Option type="QString" value="255,158,23,255" name="color"/>
                          <Option type="QString" value="1" name="horizontal_anchor_point"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="circle" name="name"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="35,35,35,255" name="outline_color"/>
                          <Option type="QString" value="solid" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="diameter" name="scale_method"/>
                          <Option type="QString" value="2" name="size"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                          <Option type="QString" value="MM" name="size_unit"/>
                          <Option type="QString" value="1" name="vertical_anchor_point"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="255,158,23,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                          <Option type="QString" value="194,50,255,255" name="color"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="128,128,128,255" name="outline_color"/>
                          <Option type="QString" value="no" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="solid" name="style"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="194,50,255,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                    <Option type="int" value="0" name="blendMode"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                    <Option type="bool" value="false" name="drawToAllParts"/>
                    <Option type="QString" value="0" name="enabled"/>
                    <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                    <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                    <Option type="double" value="0" name="minLength"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                    <Option type="QString" value="MM" name="minLengthUnit"/>
                    <Option type="double" value="0" name="offsetFromAnchor"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                    <Option type="double" value="0" name="offsetFromLabel"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                  </Option>
                </callout>
              </settings>
            </rule>
            <rule description="Cu-Kabel u.i. in Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{a062691e-9e8b-46a3-a2c3-8c50e4e3759d}" active="0">
              <settings calloutType="simple">
                <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName="' '||&quot;ANZAHL_F_A&quot;  || '  DA l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                  <families/>
                  <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                  <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                  <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                    <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="0" name="angle"/>
                          <Option type="QString" value="square" name="cap_style"/>
                          <Option type="QString" value="141,90,153,255" name="color"/>
                          <Option type="QString" value="1" name="horizontal_anchor_point"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="circle" name="name"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="35,35,35,255" name="outline_color"/>
                          <Option type="QString" value="solid" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="diameter" name="scale_method"/>
                          <Option type="QString" value="2" name="size"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                          <Option type="QString" value="MM" name="size_unit"/>
                          <Option type="QString" value="1" name="vertical_anchor_point"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="141,90,153,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                          <Option type="QString" value="0,0,0,255" name="color"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="128,128,128,255" name="outline_color"/>
                          <Option type="QString" value="no" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="solid" name="style"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="0,0,0,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                    <Option type="int" value="0" name="blendMode"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                    <Option type="bool" value="false" name="drawToAllParts"/>
                    <Option type="QString" value="0" name="enabled"/>
                    <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                    <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                    <Option type="double" value="0" name="minLength"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                    <Option type="QString" value="MM" name="minLengthUnit"/>
                    <Option type="double" value="0" name="offsetFromAnchor"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                    <Option type="double" value="0" name="offsetFromLabel"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                  </Option>
                </callout>
              </settings>
            </rule>
          </rule>
          <rule description="Cu-Kabel o.i." filter="&quot;V_A_SONST&quot; ILIKE '%oberirdisch%' OR &quot;V_A_Sonst&quot; ILIKE '%o.i.%'" key="{34a04a8b-d14d-49ab-93a3-46b1ac8d8b95}">
            <rule description="Cu-Kabel o.i. neu" filter="&quot;ZUSTAND&quot; = 1" key="{74cceb27-290e-4821-89c5-cf57267d1647}" active="0">
              <settings calloutType="simple">
                <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                  <families/>
                  <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                  <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                  <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="194,50,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                    <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="0" name="angle"/>
                          <Option type="QString" value="square" name="cap_style"/>
                          <Option type="QString" value="243,166,178,255" name="color"/>
                          <Option type="QString" value="1" name="horizontal_anchor_point"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="circle" name="name"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="35,35,35,255" name="outline_color"/>
                          <Option type="QString" value="solid" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="diameter" name="scale_method"/>
                          <Option type="QString" value="2" name="size"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                          <Option type="QString" value="MM" name="size_unit"/>
                          <Option type="QString" value="1" name="vertical_anchor_point"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="243,166,178,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                          <Option type="QString" value="194,50,255,255" name="color"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="128,128,128,255" name="outline_color"/>
                          <Option type="QString" value="no" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="solid" name="style"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="194,50,255,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                    <Option type="int" value="0" name="blendMode"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                    <Option type="bool" value="false" name="drawToAllParts"/>
                    <Option type="QString" value="0" name="enabled"/>
                    <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                    <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                    <Option type="double" value="0" name="minLength"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                    <Option type="QString" value="MM" name="minLengthUnit"/>
                    <Option type="double" value="0" name="offsetFromAnchor"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                    <Option type="double" value="0" name="offsetFromLabel"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                  </Option>
                </callout>
              </settings>
            </rule>
            <rule description="Cu-Kabel o.i. Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{da2206e1-b5e2-4583-b004-1bb06cb0a8b7}" active="0">
              <settings calloutType="simple">
                <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' o.i. ' || &quot;ANZAHL_F_A&quot;  || '  DA l Res.: ' ||  &quot;F_A_RESERV&quot;  || ' '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                  <families/>
                  <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                  <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                  <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                    <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="0" name="angle"/>
                          <Option type="QString" value="square" name="cap_style"/>
                          <Option type="QString" value="213,180,60,255" name="color"/>
                          <Option type="QString" value="1" name="horizontal_anchor_point"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="circle" name="name"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="35,35,35,255" name="outline_color"/>
                          <Option type="QString" value="solid" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="diameter" name="scale_method"/>
                          <Option type="QString" value="2" name="size"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                          <Option type="QString" value="MM" name="size_unit"/>
                          <Option type="QString" value="1" name="vertical_anchor_point"/>
                        </Option>
                        <prop k="angle" v="0"/>
                        <prop k="cap_style" v="square"/>
                        <prop k="color" v="213,180,60,255"/>
                        <prop k="horizontal_anchor_point" v="1"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="name" v="circle"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="35,35,35,255"/>
                        <prop k="outline_style" v="solid"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="scale_method" v="diameter"/>
                        <prop k="size" v="2"/>
                        <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="size_unit" v="MM"/>
                        <prop k="vertical_anchor_point" v="1"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                    <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                      <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                        <Option type="Map">
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                          <Option type="QString" value="0,0,0,255" name="color"/>
                          <Option type="QString" value="bevel" name="joinstyle"/>
                          <Option type="QString" value="0,0" name="offset"/>
                          <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                          <Option type="QString" value="MM" name="offset_unit"/>
                          <Option type="QString" value="128,128,128,255" name="outline_color"/>
                          <Option type="QString" value="no" name="outline_style"/>
                          <Option type="QString" value="0" name="outline_width"/>
                          <Option type="QString" value="MM" name="outline_width_unit"/>
                          <Option type="QString" value="solid" name="style"/>
                        </Option>
                        <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="color" v="0,0,0,255"/>
                        <prop k="joinstyle" v="bevel"/>
                        <prop k="offset" v="0,0"/>
                        <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                        <prop k="offset_unit" v="MM"/>
                        <prop k="outline_color" v="128,128,128,255"/>
                        <prop k="outline_style" v="no"/>
                        <prop k="outline_width" v="0"/>
                        <prop k="outline_width_unit" v="MM"/>
                        <prop k="style" v="solid"/>
                        <data_defined_properties>
                          <Option type="Map">
                            <Option type="QString" value="" name="name"/>
                            <Option name="properties"/>
                            <Option type="QString" value="collection" name="type"/>
                          </Option>
                        </data_defined_properties>
                      </layer>
                    </symbol>
                  </background>
                  <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                  <dd_properties>
                    <Option type="Map">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                  </dd_properties>
                  <substitutions/>
                </text-style>
                <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
                <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
                <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                </dd_properties>
                <callout type="simple">
                  <Option type="Map">
                    <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                    <Option type="int" value="0" name="blendMode"/>
                    <Option type="Map" name="ddProperties">
                      <Option type="QString" value="" name="name"/>
                      <Option name="properties"/>
                      <Option type="QString" value="collection" name="type"/>
                    </Option>
                    <Option type="bool" value="false" name="drawToAllParts"/>
                    <Option type="QString" value="0" name="enabled"/>
                    <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                    <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                    <Option type="double" value="0" name="minLength"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                    <Option type="QString" value="MM" name="minLengthUnit"/>
                    <Option type="double" value="0" name="offsetFromAnchor"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                    <Option type="double" value="0" name="offsetFromLabel"/>
                    <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                    <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                  </Option>
                </callout>
              </settings>
            </rule>
          </rule>
        </rule>
        <rule description="FSP-Kabel" filter="&quot;VERB_ART&quot; = 99 AND (&quot;V_A_Sonst&quot; ILIKE '%FSP%' OR &quot;V_A_Sonst&quot; ILIKE '%Fernspeisekabel%' )" key="{78040bff-1083-46da-b56f-37b6eb1d64f9}" scalemindenom="1" scalemaxdenom="4000">
          <rule description="FSP-Kabel in neu" filter="&quot;ZUSTAND&quot; = 1" key="{bd6e06db-7e24-43b9-a414-6ded24fd4f94}" active="0">
            <settings calloutType="simple">
              <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' FSP '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                <families/>
                <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="194,50,255,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                  <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </data_defined_properties>
                    <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                      <Option type="Map">
                        <Option type="QString" value="0" name="angle"/>
                        <Option type="QString" value="square" name="cap_style"/>
                        <Option type="QString" value="125,139,143,255" name="color"/>
                        <Option type="QString" value="1" name="horizontal_anchor_point"/>
                        <Option type="QString" value="bevel" name="joinstyle"/>
                        <Option type="QString" value="circle" name="name"/>
                        <Option type="QString" value="0,0" name="offset"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                        <Option type="QString" value="MM" name="offset_unit"/>
                        <Option type="QString" value="35,35,35,255" name="outline_color"/>
                        <Option type="QString" value="solid" name="outline_style"/>
                        <Option type="QString" value="0" name="outline_width"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                        <Option type="QString" value="MM" name="outline_width_unit"/>
                        <Option type="QString" value="diameter" name="scale_method"/>
                        <Option type="QString" value="2" name="size"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                        <Option type="QString" value="MM" name="size_unit"/>
                        <Option type="QString" value="1" name="vertical_anchor_point"/>
                      </Option>
                      <prop k="angle" v="0"/>
                      <prop k="cap_style" v="square"/>
                      <prop k="color" v="125,139,143,255"/>
                      <prop k="horizontal_anchor_point" v="1"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="name" v="circle"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="35,35,35,255"/>
                      <prop k="outline_style" v="solid"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="scale_method" v="diameter"/>
                      <prop k="size" v="2"/>
                      <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="size_unit" v="MM"/>
                      <prop k="vertical_anchor_point" v="1"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                  <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </data_defined_properties>
                    <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                      <Option type="Map">
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                        <Option type="QString" value="194,50,255,255" name="color"/>
                        <Option type="QString" value="bevel" name="joinstyle"/>
                        <Option type="QString" value="0,0" name="offset"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                        <Option type="QString" value="MM" name="offset_unit"/>
                        <Option type="QString" value="128,128,128,255" name="outline_color"/>
                        <Option type="QString" value="no" name="outline_style"/>
                        <Option type="QString" value="0" name="outline_width"/>
                        <Option type="QString" value="MM" name="outline_width_unit"/>
                        <Option type="QString" value="solid" name="style"/>
                      </Option>
                      <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="color" v="194,50,255,255"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="128,128,128,255"/>
                      <prop k="outline_style" v="no"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="style" v="solid"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                </background>
                <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                </dd_properties>
                <substitutions/>
              </text-style>
              <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
              <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="10" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
              <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
              <dd_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name"/>
                  <Option name="properties"/>
                  <Option type="QString" value="collection" name="type"/>
                </Option>
              </dd_properties>
              <callout type="simple">
                <Option type="Map">
                  <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                  <Option type="int" value="0" name="blendMode"/>
                  <Option type="Map" name="ddProperties">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                  <Option type="bool" value="false" name="drawToAllParts"/>
                  <Option type="QString" value="0" name="enabled"/>
                  <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                  <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                  <Option type="double" value="0" name="minLength"/>
                  <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                  <Option type="QString" value="MM" name="minLengthUnit"/>
                  <Option type="double" value="0" name="offsetFromAnchor"/>
                  <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                  <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                  <Option type="double" value="0" name="offsetFromLabel"/>
                  <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                  <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                </Option>
              </callout>
            </settings>
          </rule>
          <rule description="FSP-Kabel in Bestand" filter="&quot;ZUSTAND&quot; = 2" key="{1045bcbb-8800-454b-8389-1d92f1375e56}" active="0">
            <settings calloutType="simple">
              <text-style fontSizeMapUnitScale="3x:0,0,0,0,0,0" fontKerning="1" isExpression="1" fontItalic="0" useSubstitutions="0" textOpacity="1" fieldName=" ' FSP '" fontFamily="MS Shell Dlg 2" blendMode="0" fontWordSpacing="0" fontStrikeout="0" textColor="255,255,255,255" fontLetterSpacing="0" fontUnderline="0" legendString="Aa" allowHtml="0" previewBkgrdColor="255,255,255,255" capitalization="0" namedStyle="Standard" fontSize="10" multilineHeight="1" fontWeight="50" fontSizeUnit="Point" textOrientation="horizontal">
                <families/>
                <text-buffer bufferOpacity="1" bufferColor="255,255,255,255" bufferNoFill="1" bufferBlendMode="0" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferSize="1" bufferJoinStyle="128" bufferDraw="0" bufferSizeUnits="MM"/>
                <text-mask maskSizeUnits="MM" maskedSymbolLayers="" maskSize="1.5" maskEnabled="0" maskJoinStyle="128" maskOpacity="1" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskType="0"/>
                <background shapeOffsetY="0" shapeOffsetUnit="MM" shapeBorderWidth="0" shapeBorderWidthUnit="MM" shapeDraw="1" shapeSVGFile="" shapeSizeX="0" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOpacity="1" shapeSizeY="0" shapeSizeType="0" shapeSizeUnit="MM" shapeOffsetX="0" shapeRadiiY="0" shapeJoinStyle="64" shapeRadiiUnit="MM" shapeRotation="0" shapeType="0" shapeRotationType="0" shapeRadiiX="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBlendMode="0" shapeFillColor="0,0,0,255" shapeBorderColor="128,128,128,255" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0">
                  <symbol alpha="1" type="marker" force_rhr="0" name="markerSymbol" clip_to_extent="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </data_defined_properties>
                    <layer locked="0" pass="0" class="SimpleMarker" enabled="1">
                      <Option type="Map">
                        <Option type="QString" value="0" name="angle"/>
                        <Option type="QString" value="square" name="cap_style"/>
                        <Option type="QString" value="133,182,111,255" name="color"/>
                        <Option type="QString" value="1" name="horizontal_anchor_point"/>
                        <Option type="QString" value="bevel" name="joinstyle"/>
                        <Option type="QString" value="circle" name="name"/>
                        <Option type="QString" value="0,0" name="offset"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                        <Option type="QString" value="MM" name="offset_unit"/>
                        <Option type="QString" value="35,35,35,255" name="outline_color"/>
                        <Option type="QString" value="solid" name="outline_style"/>
                        <Option type="QString" value="0" name="outline_width"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale"/>
                        <Option type="QString" value="MM" name="outline_width_unit"/>
                        <Option type="QString" value="diameter" name="scale_method"/>
                        <Option type="QString" value="2" name="size"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="size_map_unit_scale"/>
                        <Option type="QString" value="MM" name="size_unit"/>
                        <Option type="QString" value="1" name="vertical_anchor_point"/>
                      </Option>
                      <prop k="angle" v="0"/>
                      <prop k="cap_style" v="square"/>
                      <prop k="color" v="133,182,111,255"/>
                      <prop k="horizontal_anchor_point" v="1"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="name" v="circle"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="35,35,35,255"/>
                      <prop k="outline_style" v="solid"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="scale_method" v="diameter"/>
                      <prop k="size" v="2"/>
                      <prop k="size_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="size_unit" v="MM"/>
                      <prop k="vertical_anchor_point" v="1"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                  <symbol alpha="1" type="fill" force_rhr="0" name="fillSymbol" clip_to_extent="1">
                    <data_defined_properties>
                      <Option type="Map">
                        <Option type="QString" value="" name="name"/>
                        <Option name="properties"/>
                        <Option type="QString" value="collection" name="type"/>
                      </Option>
                    </data_defined_properties>
                    <layer locked="0" pass="0" class="SimpleFill" enabled="1">
                      <Option type="Map">
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale"/>
                        <Option type="QString" value="0,0,0,255" name="color"/>
                        <Option type="QString" value="bevel" name="joinstyle"/>
                        <Option type="QString" value="0,0" name="offset"/>
                        <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
                        <Option type="QString" value="MM" name="offset_unit"/>
                        <Option type="QString" value="128,128,128,255" name="outline_color"/>
                        <Option type="QString" value="no" name="outline_style"/>
                        <Option type="QString" value="0" name="outline_width"/>
                        <Option type="QString" value="MM" name="outline_width_unit"/>
                        <Option type="QString" value="solid" name="style"/>
                      </Option>
                      <prop k="border_width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="color" v="0,0,0,255"/>
                      <prop k="joinstyle" v="bevel"/>
                      <prop k="offset" v="0,0"/>
                      <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
                      <prop k="offset_unit" v="MM"/>
                      <prop k="outline_color" v="128,128,128,255"/>
                      <prop k="outline_style" v="no"/>
                      <prop k="outline_width" v="0"/>
                      <prop k="outline_width_unit" v="MM"/>
                      <prop k="style" v="solid"/>
                      <data_defined_properties>
                        <Option type="Map">
                          <Option type="QString" value="" name="name"/>
                          <Option name="properties"/>
                          <Option type="QString" value="collection" name="type"/>
                        </Option>
                      </data_defined_properties>
                    </layer>
                  </symbol>
                </background>
                <shadow shadowOffsetAngle="135" shadowOffsetUnit="MM" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowOffsetDist="1" shadowRadiusAlphaOnly="0" shadowOpacity="0.69999999999999996" shadowUnder="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowDraw="0" shadowOffsetGlobal="1" shadowRadiusUnit="MM" shadowColor="0,0,0,255" shadowBlendMode="6" shadowRadius="1.5" shadowScale="100"/>
                <dd_properties>
                  <Option type="Map">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                </dd_properties>
                <substitutions/>
              </text-style>
              <text-format autoWrapLength="0" multilineAlign="0" placeDirectionSymbol="0" decimals="3" wrapChar="" leftDirectionSymbol="&lt;" formatNumbers="0" rightDirectionSymbol=">" reverseDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" addDirectionSymbol="0" plussign="0"/>
              <placement rotationAngle="0" quadOffset="4" layerType="LineGeometry" overrunDistance="0" offsetType="0" maxCurvedCharAngleOut="-25" distMapUnitScale="3x:0,0,0,0,0,0" maxCurvedCharAngleIn="25" yOffset="0" polygonPlacementFlags="2" geometryGeneratorEnabled="0" dist="5" xOffset="0" lineAnchorPercent="0.5" rotationUnit="AngleDegrees" repeatDistance="0" fitInPolygonOnly="0" placement="2" priority="5" geometryGeneratorType="PointGeometry" distUnits="Pixel" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" preserveRotation="1" centroidWhole="0" geometryGenerator="" offsetUnits="MM" lineAnchorType="0" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" overrunDistanceUnit="MM" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0" placementFlags="12" centroidInside="0" lineAnchorClipping="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" repeatDistanceUnits="MM"/>
              <rendering obstacle="1" mergeLines="0" zIndex="0" fontMinPixelSize="3" displayAll="0" drawLabels="1" minFeatureSize="0" obstacleFactor="1" unplacedVisibility="0" obstacleType="1" maxNumLabels="2000" fontLimitPixelSize="0" scaleVisibility="0" fontMaxPixelSize="10000" scaleMin="0" labelPerPart="0" scaleMax="0" upsidedownLabels="0" limitNumLabels="0"/>
              <dd_properties>
                <Option type="Map">
                  <Option type="QString" value="" name="name"/>
                  <Option name="properties"/>
                  <Option type="QString" value="collection" name="type"/>
                </Option>
              </dd_properties>
              <callout type="simple">
                <Option type="Map">
                  <Option type="QString" value="pole_of_inaccessibility" name="anchorPoint"/>
                  <Option type="int" value="0" name="blendMode"/>
                  <Option type="Map" name="ddProperties">
                    <Option type="QString" value="" name="name"/>
                    <Option name="properties"/>
                    <Option type="QString" value="collection" name="type"/>
                  </Option>
                  <Option type="bool" value="false" name="drawToAllParts"/>
                  <Option type="QString" value="0" name="enabled"/>
                  <Option type="QString" value="point_on_exterior" name="labelAnchorPoint"/>
                  <Option type="QString" value="&lt;symbol alpha=&quot;1&quot; type=&quot;line&quot; force_rhr=&quot;0&quot; name=&quot;symbol&quot; clip_to_extent=&quot;1&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; enabled=&quot;1&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;align_dash_pattern&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;square&quot; name=&quot;capstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;5;2&quot; name=&quot;customdash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;customdash_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;dash_pattern_offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;draw_inside_polygon&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;bevel&quot; name=&quot;joinstyle&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;60,60,60,255&quot; name=&quot;line_color&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;solid&quot; name=&quot;line_style&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0.3&quot; name=&quot;line_width&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;line_width_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;offset&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;offset_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;ring_filter&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_end&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;trim_distance_start&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;0&quot; name=&quot;use_custom_dash&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot;/>&lt;/Option>&lt;prop k=&quot;align_dash_pattern&quot; v=&quot;0&quot;/>&lt;prop k=&quot;capstyle&quot; v=&quot;square&quot;/>&lt;prop k=&quot;customdash&quot; v=&quot;5;2&quot;/>&lt;prop k=&quot;customdash_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;customdash_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;dash_pattern_offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;dash_pattern_offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;dash_pattern_offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;draw_inside_polygon&quot; v=&quot;0&quot;/>&lt;prop k=&quot;joinstyle&quot; v=&quot;bevel&quot;/>&lt;prop k=&quot;line_color&quot; v=&quot;60,60,60,255&quot;/>&lt;prop k=&quot;line_style&quot; v=&quot;solid&quot;/>&lt;prop k=&quot;line_width&quot; v=&quot;0.3&quot;/>&lt;prop k=&quot;line_width_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;offset&quot; v=&quot;0&quot;/>&lt;prop k=&quot;offset_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;offset_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;ring_filter&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_end_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_end_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;trim_distance_start&quot; v=&quot;0&quot;/>&lt;prop k=&quot;trim_distance_start_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;prop k=&quot;trim_distance_start_unit&quot; v=&quot;MM&quot;/>&lt;prop k=&quot;tweak_dash_pattern_on_corners&quot; v=&quot;0&quot;/>&lt;prop k=&quot;use_custom_dash&quot; v=&quot;0&quot;/>&lt;prop k=&quot;width_map_unit_scale&quot; v=&quot;3x:0,0,0,0,0,0&quot;/>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option type=&quot;QString&quot; value=&quot;&quot; name=&quot;name&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option type=&quot;QString&quot; value=&quot;collection&quot; name=&quot;type&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol"/>
                  <Option type="double" value="0" name="minLength"/>
                  <Option type="QString" value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale"/>
                  <Option type="QString" value="MM" name="minLengthUnit"/>
                  <Option type="double" value="0" name="offsetFromAnchor"/>
                  <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale"/>
                  <Option type="QString" value="MM" name="offsetFromAnchorUnit"/>
                  <Option type="double" value="0" name="offsetFromLabel"/>
                  <Option type="QString" value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale"/>
                  <Option type="QString" value="MM" name="offsetFromLabelUnit"/>
                </Option>
              </callout>
            </settings>
          </rule>
        </rule>
      </rule>
    </rules>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option type="QString" value="Verb_Art" name="dualview/previewExpressions"/>
      <Option type="QString" value="0" name="embeddedWidgets/count"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory penColor="#000000" scaleBasedVisibility="0" enabled="0" maxScaleDenominator="1e+08" direction="1" labelPlacementMethod="XHeight" scaleDependency="Area" height="15" width="15" spacingUnitScale="3x:0,0,0,0,0,0" rotationOffset="270" spacing="0" opacity="1" sizeScale="3x:0,0,0,0,0,0" lineSizeType="MM" diagramOrientation="Up" lineSizeScale="3x:0,0,0,0,0,0" barWidth="5" penAlpha="255" backgroundAlpha="255" penWidth="0" sizeType="MM" showAxis="0" spacingUnit="MM" backgroundColor="#ffffff" minScaleDenominator="0" minimumSize="0">
      <fontProperties description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" style=""/>
      <attribute field="" label="" color="#000000" colorOpacity="1"/>
      <axisSymbol>
        <symbol alpha="1" type="line" force_rhr="0" name="" clip_to_extent="1">
          <data_defined_properties>
            <Option type="Map">
              <Option type="QString" value="" name="name"/>
              <Option name="properties"/>
              <Option type="QString" value="collection" name="type"/>
            </Option>
          </data_defined_properties>
          <layer locked="0" pass="0" class="SimpleLine" enabled="1">
            <Option type="Map">
              <Option type="QString" value="0" name="align_dash_pattern"/>
              <Option type="QString" value="square" name="capstyle"/>
              <Option type="QString" value="5;2" name="customdash"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale"/>
              <Option type="QString" value="MM" name="customdash_unit"/>
              <Option type="QString" value="0" name="dash_pattern_offset"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale"/>
              <Option type="QString" value="MM" name="dash_pattern_offset_unit"/>
              <Option type="QString" value="0" name="draw_inside_polygon"/>
              <Option type="QString" value="bevel" name="joinstyle"/>
              <Option type="QString" value="35,35,35,255" name="line_color"/>
              <Option type="QString" value="solid" name="line_style"/>
              <Option type="QString" value="0.26" name="line_width"/>
              <Option type="QString" value="MM" name="line_width_unit"/>
              <Option type="QString" value="0" name="offset"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="offset_map_unit_scale"/>
              <Option type="QString" value="MM" name="offset_unit"/>
              <Option type="QString" value="0" name="ring_filter"/>
              <Option type="QString" value="0" name="trim_distance_end"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale"/>
              <Option type="QString" value="MM" name="trim_distance_end_unit"/>
              <Option type="QString" value="0" name="trim_distance_start"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale"/>
              <Option type="QString" value="MM" name="trim_distance_start_unit"/>
              <Option type="QString" value="0" name="tweak_dash_pattern_on_corners"/>
              <Option type="QString" value="0" name="use_custom_dash"/>
              <Option type="QString" value="3x:0,0,0,0,0,0" name="width_map_unit_scale"/>
            </Option>
            <prop k="align_dash_pattern" v="0"/>
            <prop k="capstyle" v="square"/>
            <prop k="customdash" v="5;2"/>
            <prop k="customdash_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="customdash_unit" v="MM"/>
            <prop k="dash_pattern_offset" v="0"/>
            <prop k="dash_pattern_offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="dash_pattern_offset_unit" v="MM"/>
            <prop k="draw_inside_polygon" v="0"/>
            <prop k="joinstyle" v="bevel"/>
            <prop k="line_color" v="35,35,35,255"/>
            <prop k="line_style" v="solid"/>
            <prop k="line_width" v="0.26"/>
            <prop k="line_width_unit" v="MM"/>
            <prop k="offset" v="0"/>
            <prop k="offset_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="offset_unit" v="MM"/>
            <prop k="ring_filter" v="0"/>
            <prop k="trim_distance_end" v="0"/>
            <prop k="trim_distance_end_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="trim_distance_end_unit" v="MM"/>
            <prop k="trim_distance_start" v="0"/>
            <prop k="trim_distance_start_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <prop k="trim_distance_start_unit" v="MM"/>
            <prop k="tweak_dash_pattern_on_corners" v="0"/>
            <prop k="use_custom_dash" v="0"/>
            <prop k="width_map_unit_scale" v="3x:0,0,0,0,0,0"/>
            <data_defined_properties>
              <Option type="Map">
                <Option type="QString" value="" name="name"/>
                <Option name="properties"/>
                <Option type="QString" value="collection" name="type"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings zIndex="0" obstacle="0" placement="2" showAll="1" dist="0" linePlacementFlags="18" priority="0">
    <properties>
      <Option type="Map">
        <Option type="QString" value="" name="name"/>
        <Option name="properties"/>
        <Option type="QString" value="collection" name="type"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="None" name="ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="VERB_ART">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="V_A_SONST">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ANZAHL_VER">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LAE_KABEL">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ANZAHL_F_A">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="LFD_M_F_A">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="F_A_RESERV">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ZUSTAND">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_TRASSEN">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_LR">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_START">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="ID_ENDE">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="E_FNAME">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="E_ORT">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="E_TEL">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="E_E_MAIL">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MP_MBFD_CO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="A_VNAME">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="A_ZNAME">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="A_TEL">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="A_E_MAIL">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MP_DB_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MP_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="MIT_CAB_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="None" name="SM_AUFTRAG">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias field="ID" index="0" name=""/>
    <alias field="VERB_ART" index="1" name=""/>
    <alias field="V_A_SONST" index="2" name=""/>
    <alias field="ANZAHL_VER" index="3" name=""/>
    <alias field="LAE_KABEL" index="4" name=""/>
    <alias field="ANZAHL_F_A" index="5" name=""/>
    <alias field="LFD_M_F_A" index="6" name=""/>
    <alias field="F_A_RESERV" index="7" name=""/>
    <alias field="ZUSTAND" index="8" name=""/>
    <alias field="ID_TRASSEN" index="9" name=""/>
    <alias field="ID_LR" index="10" name=""/>
    <alias field="ID_START" index="11" name=""/>
    <alias field="ID_ENDE" index="12" name=""/>
    <alias field="E_FNAME" index="13" name=""/>
    <alias field="E_ORT" index="14" name=""/>
    <alias field="E_TEL" index="15" name=""/>
    <alias field="E_E_MAIL" index="16" name=""/>
    <alias field="MP_MBFD_CO" index="17" name=""/>
    <alias field="A_VNAME" index="18" name=""/>
    <alias field="A_ZNAME" index="19" name=""/>
    <alias field="A_TEL" index="20" name=""/>
    <alias field="A_E_MAIL" index="21" name=""/>
    <alias field="MP_DB_ID" index="22" name=""/>
    <alias field="MP_ID" index="23" name=""/>
    <alias field="MIT_CAB_ID" index="24" name=""/>
    <alias field="SM_AUFTRAG" index="25" name=""/>
  </aliases>
  <defaults>
    <default field="ID" expression="" applyOnUpdate="0"/>
    <default field="VERB_ART" expression="" applyOnUpdate="0"/>
    <default field="V_A_SONST" expression="" applyOnUpdate="0"/>
    <default field="ANZAHL_VER" expression="" applyOnUpdate="0"/>
    <default field="LAE_KABEL" expression="" applyOnUpdate="0"/>
    <default field="ANZAHL_F_A" expression="" applyOnUpdate="0"/>
    <default field="LFD_M_F_A" expression="" applyOnUpdate="0"/>
    <default field="F_A_RESERV" expression="" applyOnUpdate="0"/>
    <default field="ZUSTAND" expression="" applyOnUpdate="0"/>
    <default field="ID_TRASSEN" expression="" applyOnUpdate="0"/>
    <default field="ID_LR" expression="" applyOnUpdate="0"/>
    <default field="ID_START" expression="" applyOnUpdate="0"/>
    <default field="ID_ENDE" expression="" applyOnUpdate="0"/>
    <default field="E_FNAME" expression="" applyOnUpdate="0"/>
    <default field="E_ORT" expression="" applyOnUpdate="0"/>
    <default field="E_TEL" expression="" applyOnUpdate="0"/>
    <default field="E_E_MAIL" expression="" applyOnUpdate="0"/>
    <default field="MP_MBFD_CO" expression="" applyOnUpdate="0"/>
    <default field="A_VNAME" expression="" applyOnUpdate="0"/>
    <default field="A_ZNAME" expression="" applyOnUpdate="0"/>
    <default field="A_TEL" expression="" applyOnUpdate="0"/>
    <default field="A_E_MAIL" expression="" applyOnUpdate="0"/>
    <default field="MP_DB_ID" expression="" applyOnUpdate="0"/>
    <default field="MP_ID" expression="" applyOnUpdate="0"/>
    <default field="MIT_CAB_ID" expression="" applyOnUpdate="0"/>
    <default field="SM_AUFTRAG" expression="" applyOnUpdate="0"/>
  </defaults>
  <constraints>
    <constraint field="ID" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="VERB_ART" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="V_A_SONST" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="ANZAHL_VER" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="LAE_KABEL" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="ANZAHL_F_A" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="LFD_M_F_A" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="F_A_RESERV" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="ZUSTAND" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="ID_TRASSEN" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="ID_LR" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="ID_START" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="ID_ENDE" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="E_FNAME" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="E_ORT" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="E_TEL" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="E_E_MAIL" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="MP_MBFD_CO" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="A_VNAME" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="A_ZNAME" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="A_TEL" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="A_E_MAIL" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="MP_DB_ID" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="MP_ID" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="MIT_CAB_ID" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
    <constraint field="SM_AUFTRAG" exp_strength="0" unique_strength="0" constraints="0" notnull_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint field="ID" exp="" desc=""/>
    <constraint field="VERB_ART" exp="" desc=""/>
    <constraint field="V_A_SONST" exp="" desc=""/>
    <constraint field="ANZAHL_VER" exp="" desc=""/>
    <constraint field="LAE_KABEL" exp="" desc=""/>
    <constraint field="ANZAHL_F_A" exp="" desc=""/>
    <constraint field="LFD_M_F_A" exp="" desc=""/>
    <constraint field="F_A_RESERV" exp="" desc=""/>
    <constraint field="ZUSTAND" exp="" desc=""/>
    <constraint field="ID_TRASSEN" exp="" desc=""/>
    <constraint field="ID_LR" exp="" desc=""/>
    <constraint field="ID_START" exp="" desc=""/>
    <constraint field="ID_ENDE" exp="" desc=""/>
    <constraint field="E_FNAME" exp="" desc=""/>
    <constraint field="E_ORT" exp="" desc=""/>
    <constraint field="E_TEL" exp="" desc=""/>
    <constraint field="E_E_MAIL" exp="" desc=""/>
    <constraint field="MP_MBFD_CO" exp="" desc=""/>
    <constraint field="A_VNAME" exp="" desc=""/>
    <constraint field="A_ZNAME" exp="" desc=""/>
    <constraint field="A_TEL" exp="" desc=""/>
    <constraint field="A_E_MAIL" exp="" desc=""/>
    <constraint field="MP_DB_ID" exp="" desc=""/>
    <constraint field="MP_ID" exp="" desc=""/>
    <constraint field="MIT_CAB_ID" exp="" desc=""/>
    <constraint field="SM_AUFTRAG" exp="" desc=""/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction key="Canvas" value="{00000000-0000-0000-0000-000000000000}"/>
  </attributeactions>
  <attributetableconfig sortOrder="0" sortExpression="&quot;MP_DB_ID&quot;" actionWidgetStyle="dropDown">
    <columns>
      <column type="actions" hidden="1" width="-1"/>
      <column type="field" hidden="0" name="MP_DB_ID" width="-1"/>
      <column type="field" hidden="0" name="MP_ID" width="-1"/>
      <column type="field" hidden="0" name="MIT_CAB_ID" width="-1"/>
      <column type="field" hidden="0" name="LFD_M_F_A" width="-1"/>
      <column type="field" hidden="0" name="ID_TRASSEN" width="-1"/>
      <column type="field" hidden="0" name="ID_LR" width="-1"/>
      <column type="field" hidden="0" name="ID_START" width="-1"/>
      <column type="field" hidden="0" name="ID_ENDE" width="-1"/>
      <column type="field" hidden="0" name="ID" width="-1"/>
      <column type="field" hidden="0" name="VERB_ART" width="-1"/>
      <column type="field" hidden="0" name="V_A_SONST" width="-1"/>
      <column type="field" hidden="0" name="ANZAHL_VER" width="-1"/>
      <column type="field" hidden="0" name="LAE_KABEL" width="-1"/>
      <column type="field" hidden="0" name="ANZAHL_F_A" width="-1"/>
      <column type="field" hidden="0" name="F_A_RESERV" width="-1"/>
      <column type="field" hidden="0" name="ZUSTAND" width="-1"/>
      <column type="field" hidden="0" name="E_FNAME" width="-1"/>
      <column type="field" hidden="0" name="E_ORT" width="-1"/>
      <column type="field" hidden="0" name="E_TEL" width="-1"/>
      <column type="field" hidden="0" name="E_E_MAIL" width="-1"/>
      <column type="field" hidden="0" name="MP_MBFD_CO" width="-1"/>
      <column type="field" hidden="0" name="A_VNAME" width="-1"/>
      <column type="field" hidden="0" name="A_ZNAME" width="-1"/>
      <column type="field" hidden="0" name="A_TEL" width="-1"/>
      <column type="field" hidden="0" name="A_E_MAIL" width="-1"/>
      <column type="field" hidden="0" name="SM_AUFTRAG" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1">C:/Users/A754221/AppData/Roaming</editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath>C:/Users/A754221/AppData/Roaming</editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <attributeEditorForm>
    <attributeEditorField showLabel="1" index="0" name="ID"/>
    <attributeEditorField showLabel="1" index="1" name="Verb_Art"/>
    <attributeEditorField showLabel="1" index="2" name="V_A_Sonst"/>
    <attributeEditorField showLabel="1" index="4" name="Lae_Kabel"/>
    <attributeEditorField showLabel="1" index="3" name="Anzahl_Ver"/>
    <attributeEditorField showLabel="1" index="5" name="Anzahl_F_A"/>
    <attributeEditorField showLabel="1" index="7" name="F_A_Reserv"/>
    <attributeEditorField showLabel="1" index="8" name="Zustand"/>
    <attributeEditorField showLabel="1" index="-1" name="ANZAHL_V_1"/>
    <attributeEditorField showLabel="1" index="6" name="LFD_M_F_A"/>
    <attributeEditorField showLabel="1" index="9" name="ID_TRASSEN"/>
    <attributeEditorField showLabel="1" index="10" name="ID_LR"/>
    <attributeEditorField showLabel="1" index="11" name="ID_START"/>
    <attributeEditorField showLabel="1" index="12" name="ID_ENDE"/>
    <attributeEditorField showLabel="1" index="13" name="E_FNAME"/>
    <attributeEditorField showLabel="1" index="14" name="E_ORT"/>
    <attributeEditorField showLabel="1" index="15" name="E_TEL"/>
    <attributeEditorField showLabel="1" index="16" name="E_E_MAIL"/>
    <attributeEditorField showLabel="1" index="18" name="A_VNAME"/>
    <attributeEditorField showLabel="1" index="19" name="A_ZNAME"/>
    <attributeEditorField showLabel="1" index="20" name="A_TEL"/>
    <attributeEditorField showLabel="1" index="21" name="A_E_MAIL"/>
    <attributeEditorField showLabel="1" index="22" name="MP_DB_ID"/>
    <attributeEditorField showLabel="1" index="23" name="MP_ID"/>
    <attributeEditorField showLabel="1" index="24" name="MIT_CAB_ID"/>
    <attributeEditorField showLabel="1" index="-1" name="ID_LIST"/>
    <attributeEditorField showLabel="1" index="-1" name="MIT_CAB__1"/>
  </attributeEditorForm>
  <editable>
    <field editable="1" name="ANZAHL_F_A"/>
    <field editable="1" name="ANZAHL_VER"/>
    <field editable="1" name="A_E_MAIL"/>
    <field editable="1" name="A_TEL"/>
    <field editable="1" name="A_VNAME"/>
    <field editable="1" name="A_ZNAME"/>
    <field editable="1" name="Anzahl_F_A"/>
    <field editable="1" name="Anzahl_Ver"/>
    <field editable="1" name="E_E_MAIL"/>
    <field editable="1" name="E_FNAME"/>
    <field editable="1" name="E_ORT"/>
    <field editable="1" name="E_TEL"/>
    <field editable="1" name="F_A_RESERV"/>
    <field editable="1" name="F_A_Reserv"/>
    <field editable="1" name="GID"/>
    <field editable="1" name="ID"/>
    <field editable="1" name="ID_ENDE"/>
    <field editable="1" name="ID_LIST"/>
    <field editable="1" name="ID_LR"/>
    <field editable="1" name="ID_START"/>
    <field editable="1" name="ID_TRASSEN"/>
    <field editable="1" name="LAE_KABEL"/>
    <field editable="1" name="LFD_M_F_A"/>
    <field editable="1" name="Lae_Kabel"/>
    <field editable="1" name="MIT_CAB_ID"/>
    <field editable="1" name="MIT_CAB_ID_LIST"/>
    <field editable="1" name="MP_DB_ID"/>
    <field editable="1" name="MP_ID"/>
    <field editable="1" name="MP_MBFD_CO"/>
    <field editable="1" name="SM_AUFTRAG"/>
    <field editable="1" name="VERB_ART"/>
    <field editable="1" name="V_A_SONST"/>
    <field editable="1" name="V_A_Sonst"/>
    <field editable="1" name="Verb_Art"/>
    <field editable="1" name="ZUSTAND"/>
    <field editable="1" name="Zustand"/>
    <field editable="1" name="bezeichnung"/>
    <field editable="1" name="debug_errors"/>
    <field editable="1" name="fid"/>
    <field editable="1" name="laenge_gemessen"/>
    <field editable="1" name="loeschen"/>
    <field editable="1" name="material_nummer"/>
    <field editable="1" name="material_spezifikation"/>
    <field editable="1" name="quelle"/>
  </editable>
  <labelOnTop>
    <field name="ANZAHL_F_A" labelOnTop="0"/>
    <field name="ANZAHL_VER" labelOnTop="0"/>
    <field name="A_E_MAIL" labelOnTop="0"/>
    <field name="A_TEL" labelOnTop="0"/>
    <field name="A_VNAME" labelOnTop="0"/>
    <field name="A_ZNAME" labelOnTop="0"/>
    <field name="Anzahl_F_A" labelOnTop="0"/>
    <field name="Anzahl_Ver" labelOnTop="0"/>
    <field name="E_E_MAIL" labelOnTop="0"/>
    <field name="E_FNAME" labelOnTop="0"/>
    <field name="E_ORT" labelOnTop="0"/>
    <field name="E_TEL" labelOnTop="0"/>
    <field name="F_A_RESERV" labelOnTop="0"/>
    <field name="F_A_Reserv" labelOnTop="0"/>
    <field name="GID" labelOnTop="0"/>
    <field name="ID" labelOnTop="0"/>
    <field name="ID_ENDE" labelOnTop="0"/>
    <field name="ID_LIST" labelOnTop="0"/>
    <field name="ID_LR" labelOnTop="0"/>
    <field name="ID_START" labelOnTop="0"/>
    <field name="ID_TRASSEN" labelOnTop="0"/>
    <field name="LAE_KABEL" labelOnTop="0"/>
    <field name="LFD_M_F_A" labelOnTop="0"/>
    <field name="Lae_Kabel" labelOnTop="0"/>
    <field name="MIT_CAB_ID" labelOnTop="0"/>
    <field name="MIT_CAB_ID_LIST" labelOnTop="0"/>
    <field name="MP_DB_ID" labelOnTop="0"/>
    <field name="MP_ID" labelOnTop="0"/>
    <field name="MP_MBFD_CO" labelOnTop="0"/>
    <field name="SM_AUFTRAG" labelOnTop="0"/>
    <field name="VERB_ART" labelOnTop="0"/>
    <field name="V_A_SONST" labelOnTop="0"/>
    <field name="V_A_Sonst" labelOnTop="0"/>
    <field name="Verb_Art" labelOnTop="0"/>
    <field name="ZUSTAND" labelOnTop="0"/>
    <field name="Zustand" labelOnTop="0"/>
    <field name="bezeichnung" labelOnTop="0"/>
    <field name="debug_errors" labelOnTop="0"/>
    <field name="fid" labelOnTop="0"/>
    <field name="laenge_gemessen" labelOnTop="0"/>
    <field name="loeschen" labelOnTop="0"/>
    <field name="material_nummer" labelOnTop="0"/>
    <field name="material_spezifikation" labelOnTop="0"/>
    <field name="quelle" labelOnTop="0"/>
  </labelOnTop>
  <reuseLastValue>
    <field reuseLastValue="0" name="ANZAHL_F_A"/>
    <field reuseLastValue="0" name="ANZAHL_VER"/>
    <field reuseLastValue="0" name="A_E_MAIL"/>
    <field reuseLastValue="0" name="A_TEL"/>
    <field reuseLastValue="0" name="A_VNAME"/>
    <field reuseLastValue="0" name="A_ZNAME"/>
    <field reuseLastValue="0" name="Anzahl_F_A"/>
    <field reuseLastValue="0" name="E_E_MAIL"/>
    <field reuseLastValue="0" name="E_FNAME"/>
    <field reuseLastValue="0" name="E_ORT"/>
    <field reuseLastValue="0" name="E_TEL"/>
    <field reuseLastValue="0" name="F_A_RESERV"/>
    <field reuseLastValue="0" name="F_A_Reserv"/>
    <field reuseLastValue="0" name="ID"/>
    <field reuseLastValue="0" name="ID_ENDE"/>
    <field reuseLastValue="0" name="ID_LIST"/>
    <field reuseLastValue="0" name="ID_LR"/>
    <field reuseLastValue="0" name="ID_START"/>
    <field reuseLastValue="0" name="ID_TRASSEN"/>
    <field reuseLastValue="0" name="LAE_KABEL"/>
    <field reuseLastValue="0" name="LFD_M_F_A"/>
    <field reuseLastValue="0" name="Lae_Kabel"/>
    <field reuseLastValue="0" name="MIT_CAB_ID"/>
    <field reuseLastValue="0" name="MIT_CAB_ID_LIST"/>
    <field reuseLastValue="0" name="MP_DB_ID"/>
    <field reuseLastValue="0" name="MP_ID"/>
    <field reuseLastValue="0" name="MP_MBFD_CO"/>
    <field reuseLastValue="0" name="SM_AUFTRAG"/>
    <field reuseLastValue="0" name="VERB_ART"/>
    <field reuseLastValue="0" name="V_A_SONST"/>
    <field reuseLastValue="0" name="V_A_Sonst"/>
    <field reuseLastValue="0" name="Verb_Art"/>
    <field reuseLastValue="0" name="ZUSTAND"/>
    <field reuseLastValue="0" name="Zustand"/>
    <field reuseLastValue="0" name="fid"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>"VERB_ART"</previewExpression>
  <mapTip></mapTip>
  <layerGeometryType>1</layerGeometryType>
</qgis>

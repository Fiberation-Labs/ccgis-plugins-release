<!DOCTYPE qgis PUBLIC 'http://mrcc.com/qgis.dtd' 'SYSTEM'>
<qgis hasScaleBasedVisibilityFlag="0" simplifyAlgorithm="0" readOnly="0" version="3.34.8-Prizren" styleCategories="AllStyleCategories" labelsEnabled="1" simplifyDrawingTol="1" simplifyMaxScale="1" simplifyDrawingHints="0" minScale="100000000" maxScale="0" symbologyReferenceScale="-1" simplifyLocal="1">
  <flags>
    <Identifiable>1</Identifiable>
    <Removable>1</Removable>
    <Searchable>1</Searchable>
    <Private>0</Private>
  </flags>
  <temporal fixedDuration="0" enabled="0" mode="0" startExpression="" limitMode="0" endExpression="" startField="" durationUnit="min" endField="" durationField="fid" accumulate="0">
    <fixedRange>
      <start></start>
      <end></end>
    </fixedRange>
  </temporal>
  <elevation zscale="1" symbology="Line" showMarkerSymbolInSurfacePlots="0" clamping="Terrain" respectLayerSymbol="1" binding="Centroid" type="IndividualFeatures" extrusion="0" extrusionEnabled="0" zoffset="0">
    <data-defined-properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </data-defined-properties>
    <profileLineSymbol>
      <symbol frame_rate="10" name="" is_animated="0" type="line" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleLine" id="{522523f9-6ee1-417b-9e89-0bdfb1582bdf}">
          <Option type="Map">
            <Option value="0" name="align_dash_pattern" type="QString"/>
            <Option value="square" name="capstyle" type="QString"/>
            <Option value="5;2" name="customdash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
            <Option value="MM" name="customdash_unit" type="QString"/>
            <Option value="0" name="dash_pattern_offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
            <Option value="0" name="draw_inside_polygon" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="225,89,137,255" name="line_color" type="QString"/>
            <Option value="solid" name="line_style" type="QString"/>
            <Option value="0.6" name="line_width" type="QString"/>
            <Option value="MM" name="line_width_unit" type="QString"/>
            <Option value="0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0" name="ring_filter" type="QString"/>
            <Option value="0" name="trim_distance_end" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_end_unit" type="QString"/>
            <Option value="0" name="trim_distance_start" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
            <Option value="MM" name="trim_distance_start_unit" type="QString"/>
            <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
            <Option value="0" name="use_custom_dash" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileLineSymbol>
    <profileFillSymbol>
      <symbol frame_rate="10" name="" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="{dfb92679-42e4-4b5b-b657-6a8fd562ca16}">
          <Option type="Map">
            <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
            <Option value="225,89,137,255" name="color" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="161,64,98,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="solid" name="style" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileFillSymbol>
    <profileMarkerSymbol>
      <symbol frame_rate="10" name="" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{f4c12a11-ab3e-4500-82ac-1fe23850e784}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="225,89,137,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="161,64,98,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </profileMarkerSymbol>
  </elevation>
  <renderer-v2 enableorderby="0" type="RuleRenderer" referencescale="-1" symbollevels="1" forceraster="0">
    <rules key="{d1b4f60d-aa42-4ede-b402-2c0298d36840}">
      <rule label="Struktur" key="{0e393531-34d1-4620-98e1-d405ff689830}">
        <rule label="Netztechnik (Schaltpunkte)" key="{9de2e5a2-9152-4e15-be0d-f7f4f81c6296}">
          <rule label="(11) HVt Kupfer" filter=" &quot;ART&quot;  = 11" key="{66ddebde-6317-4c75-96d0-be207d43d311}" symbol="0"/>
          <rule label="(12) HVt Glas" filter=" &quot;ART&quot;  = 12" key="{b9262338-af70-4d92-8b98-b5d410d87b61}" symbol="1"/>
          <rule label="(14) NVt Netztechnik neu" filter=" &quot;ART&quot;  = 14 AND &quot;ZUSTAND&quot; = 1" key="{123c3d20-8a51-4838-9022-497e2fe26a8c}" symbol="2"/>
          <rule label="(14) NVt Netztechnik Bestand " filter=" &quot;ART&quot;  = 14 AND &quot;ZUSTAND&quot; = 2" key="{5b2193f8-0b8e-4ddd-a054-b5da01b374be}" symbol="3"/>
          <rule label="(17) Übergabepunkt Backbone" filter="&quot;Art&quot; = 17" key="{1039d1af-3b6f-45ac-be55-5019cb91b388}" symbol="4"/>
          <rule label="(99) NVt neu (in Muffe)" filter="&quot;Art&quot;  = 99 AND &quot;ZUSTAND&quot; = 1 AND  &quot;Art_Sonst&quot; Like '%NVt in Muffe%'" key="{f54d9717-06e9-403c-a4eb-91ee46940b89}" symbol="5"/>
          <rule label="(99) NVt Bestand (in Muffe)" filter="&quot;Art&quot;  = 99 AND &quot;ZUSTAND&quot; = 2 AND  &quot;Art_Sonst&quot; Like '%NVt in Muffe%'" key="{0201f7da-8527-4b08-bec0-5a901f71fee5}" symbol="6"/>
          <rule label="(13) DSLAM/MSAN neu" filter=" &quot;ART&quot;  = 13 AND &quot;ZUSTAND&quot; = 1" key="{4936407b-6e1a-42b2-abd6-144856414b82}" symbol="7"/>
          <rule label="(13) DSLAM/MSAN Bestand" filter=" &quot;ART&quot;  = 13 AND &quot;ZUSTAND&quot; = 2" key="{a0cd05ea-3ad5-40da-a52b-854b44801597}" symbol="8"/>
          <rule label="(99) Cu-Schaltpunkt neu" filter=" &quot;ART&quot;  = 99 AND &quot;ZUSTAND&quot; = 1 AND  &quot;Art_Sonst&quot; = 'KVz'" key="{930e9d58-dff1-4dc1-b041-f4ac8c02a29c}" symbol="9"/>
          <rule label="(99) Sonstige" filter=" &quot;Art&quot;  = 99" key="{449289f9-3e41-4178-bbbe-2f208890393b}" symbol="10"/>
          <rule label="(99) Cu-Schaltpunkt Bestand" filter=" &quot;ART&quot;  = 99 AND &quot;ZUSTAND&quot; = 2 AND  &quot;Art_Sonst&quot; = 'KVz'" key="{7da92be5-c785-496d-a3d7-20b93a127191}" symbol="11"/>
          <rule label="(15) Muffe neu" filter="&quot;ART&quot; = 15 AND  &quot;Zustand&quot; = 1" key="{d1d71b10-5815-4209-a0a0-358791261cd0}" symbol="12"/>
          <rule label="(15) Muffe Bestand" filter="&quot;ART&quot; = 15 AND  &quot;Zustand&quot; = 2" key="{3d658904-ed00-4670-81b1-7dcc32ac6803}" symbol="13"/>
          <rule label="(16) HÜP/ApL (Gf-AP)" filter=" &quot;ART&quot;  = 16" key="{2466dd07-335a-4198-a183-4e4516191983}" symbol="14"/>
        </rule>
        <rule label="Bauten (Gehäuse)" key="{ef213ad0-e57d-460c-9f1a-594af0c1ebea}">
          <rule label="(30) Gehäuse (MFG/KVz) neu" filter=" &quot;ART&quot;  = 30 AND &quot;ZUSTAND&quot; = 1" key="{49ff907a-f07b-4dc1-806c-e1430a2c69d2}" symbol="15"/>
          <rule label="(30) Gehäuse (MFG/KVz) Bestand" filter=" &quot;ART&quot;  = 30 AND &quot;ZUSTAND&quot; = 2" key="{fda07790-e236-4d71-a598-0694d257545f}" symbol="16"/>
          <rule label="(31) Kabelschacht neu" filter="&quot;ART&quot; = 31 AND  &quot;Zustand&quot; = 1" key="{d163fbee-8b2e-43ea-b57d-40622560e52b}" symbol="17"/>
          <rule label="(31) Kabelschacht Bestand" filter="&quot;ART&quot; = 31 AND  &quot;Zustand&quot; = 2" key="{309f611d-f4ff-49c3-8f6b-5484c9338353}" symbol="18"/>
          <rule label="(33) Holzmast" filter="&quot;ART&quot; = 33" key="{9f0b64ee-017a-42a9-895c-33bb607edcc8}" symbol="19"/>
          <rule label="(99) Mastboxen" filter="&quot;ART&quot; = 99 AND  &quot;Art_Sonst&quot; = 'Mastbox'" key="{d1df5151-5824-490f-8521-5310f92723de}" symbol="20"/>
        </rule>
      </rule>
      <rule checkstate="0" label="alle Netztechnik" key="{023ab43a-2be4-4741-9b7b-2dbe609ad285}" symbol="21"/>
      <rule checkstate="0" label="Prüfung" key="{05dff690-8c53-424c-8fb5-851bb1bcbab3}">
        <rule checkstate="0" label="(99) Mastboxen und nicht ART_NT = 99" filter=" &quot;ART&quot;  != 99 AND &quot;ART_SONST&quot;  = 'Mastbox'" key="{ed7c216d-4054-45bb-880e-f974de3256e0}" symbol="22"/>
        <rule checkstate="0" label="ART nicht plausibel" filter=" &quot;ART&quot;  NOT IN (11,12,13,14,15,16,30,31,33,99)" key="{93207aae-bfbd-4482-8297-3da3c91c58c4}" symbol="23"/>
        <rule checkstate="0" label="ID_Tech unplausibel" filter="&quot;ART&quot; IN (12,15,30,33,99) AND  &quot;ID_TECH&quot; IS NOT '-1'" key="{141223d2-1aaf-497c-9f74-cde2444e967d}" symbol="24"/>
        <rule checkstate="0" label="Fehlende Attribute" filter=" &quot;ID&quot; IS NULL OR &quot;Art&quot; IS NULL OR &quot;Zustand&quot; IS NULL OR &quot;ID_Tech&quot; IS NULL" key="{e15406bc-02c5-48ab-b891-7393e21fa31e}" symbol="25"/>
        <rule checkstate="0" label="Prüfen: Wirklich NVt in Bestand?" filter=" &quot;ART&quot;  = 14 AND &quot;ZUSTAND&quot; = 2" key="{5d3b8ddf-9bcf-4e03-b25d-a1e9b4d8c8d5}" symbol="26"/>
        <rule checkstate="0" label="Prüfen: Wirklich MSAN in Bestand?" filter=" &quot;ART&quot;  = 13 AND &quot;ZUSTAND&quot; = 2" key="{41d05701-8ef3-4776-84c3-982be66d5fc3}" symbol="27"/>
        <rule checkstate="0" label="Prüfen: Wirklich Cu-Schaltpunkt in Bestand?" filter=" &quot;ART&quot;  = 99 AND &quot;Zustand&quot; = 2 AND  &quot;Art_Sonst&quot; = 'KVz'" key="{93ec6493-288f-4df5-860a-6dedf2f2dfda}" symbol="28"/>
        <rule checkstate="0" label="Prüfen: Wirklich Gehäuse in Bestand?" filter=" &quot;ART&quot;  = 30 AND &quot;ZUSTAND&quot; = 2" key="{5f8e2d04-4741-48ea-b5a0-d2eefb153e0e}" symbol="29"/>
        <rule checkstate="0" label="Prüfen: Wirklich Gf-AP in Bestand?" filter=" &quot;ART&quot;  = 16 AND &quot;ZUSTAND&quot; = 2" key="{77cae36f-eca7-46a4-bbf2-c40a74c37f42}" symbol="30"/>
      </rule>
    </rules>
    <symbols>
      <symbol frame_rate="10" name="0" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="2" class="SimpleMarker" id="{b55eb154-b680-4629-ad87-9c6cce0d602f}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,255,255,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.6" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="5" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="2" class="SimpleMarker" id="{18ea9e7a-6ae9-4003-bbe7-546c8c038daa}">
          <Option type="Map">
            <Option value="90" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,127,0,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="line" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="211,162,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.6" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="5" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="1" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="2" class="SimpleMarker" id="{4d9ee5ca-9b52-465f-bd4f-f7e43e149abc}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,255,255,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.6" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="5" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="2" class="SimpleMarker" id="{2c6b51c9-dd08-4323-a6aa-2b68a41b75ea}">
          <Option type="Map">
            <Option value="90" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,127,0,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="line" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,168,252,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.6" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="5" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="10" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{dc8914ed-9bb1-424a-b7f0-409f5e946077}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="184,8,8,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="star" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="184,8,8,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="6.6" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <effect enabled="1" type="effectStack">
            <effect type="dropShadow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{e0a31e16-542c-4995-88d4-6b48b859e5d6}">
          <Option type="Map">
            <Option value="34" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,0,0,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="star" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="7.2" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <effect enabled="0" type="effectStack">
            <effect type="drawSource">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="11" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="1" class="SimpleMarker" id="{6bf9ef61-e80f-4acc-9033-19de8461124e}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,255,255,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.5" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="1" class="SimpleMarker" id="{2992f797-6b6c-419c-b9d7-60dc1609bedf}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="0,0,0,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="1.5" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="12" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{61531c11-8e1a-486a-bd5c-354e1b6de928}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="239,0,4,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="1.6" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="13" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{8b7aa0f5-d66b-47b8-b060-1e8020d76445}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="0,0,0,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="1.6" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="14" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{7f0ed47b-734d-4320-b50b-e18e9af14d90}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="1,255,30,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="1" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="15" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{373647a7-9a03-4afb-8e5b-f1a5620f5a15}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="248,248,248,0" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="square" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="5.6" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="16" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{619be64d-5784-40d0-8ebc-9bdc81de80ed}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="248,248,248,0" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="square" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="5.6" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="17" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{a01093fa-52bf-42df-9a74-a964c419fffc}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="239,239,239,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="square" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="2" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="18" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{d0835806-3c39-46f5-a97b-2aac6badfc66}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="239,239,239,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="square" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="2" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="19" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{08fdbb0f-df43-43a7-84bd-2735c1ec5a22}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="236,129,239,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="1.4" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="2" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="2" class="SimpleMarker" id="{e3285e75-0659-4cb9-b4d2-7a562bd6443f}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="32,168,11,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="239,0,4,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.4" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="20" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{e33ff508-ac36-47cf-9fba-40940c5aca09}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="73,190,253,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="2" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="21" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="FilledMarker" id="{451787fe-c16c-467f-afe8-f9e6b317e037}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="0,0,0,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="asterisk_fill" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="2.8" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
          <symbol frame_rate="10" name="@21@0" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
            <data_defined_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </data_defined_properties>
            <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="{37f855a7-cf7b-4f6f-a68e-5ca762779507}">
              <Option type="Map">
                <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="bevel" name="joinstyle" type="QString"/>
                <Option value="0,0" name="offset" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="255,0,0,255" name="outline_color" type="QString"/>
                <Option value="solid" name="outline_style" type="QString"/>
                <Option value="0.4" name="outline_width" type="QString"/>
                <Option value="MM" name="outline_width_unit" type="QString"/>
                <Option value="solid" name="style" type="QString"/>
              </Option>
              <data_defined_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </data_defined_properties>
            </layer>
          </symbol>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="22" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{5eea5023-4638-4a92-bbe0-a4eaa8946a2c}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="73,190,253,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="2" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <effect enabled="1" type="effectStack">
            <effect type="dropShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="0" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,0,0,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="2" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="0.5" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,255,255,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="2" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="23" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{b7e6bf6b-378b-415d-9d63-6794ab88a475}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,165,47,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <effect enabled="1" type="effectStack">
            <effect type="dropShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="0" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,0,0,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="2" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="0.5" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,255,255,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="2" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="24" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{ed5683de-5cac-448e-87f7-4297040f4d21}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,165,47,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <effect enabled="1" type="effectStack">
            <effect type="dropShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="0" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,0,0,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="2" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="0.5" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,255,255,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="2" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="25" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{cdd2ec9d-1580-4430-ab00-2c55c901b1aa}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,165,47,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <effect enabled="1" type="effectStack">
            <effect type="dropShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="0" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,0,0,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="2" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="0.5" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,255,255,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="2" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="26" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="2" class="SimpleMarker" id="{53a7ee96-cd9a-4668-9427-9a85614152b2}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="32,168,11,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,1.39999999999999991" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.4" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="2" name="vertical_anchor_point" type="QString"/>
          </Option>
          <effect enabled="1" type="effectStack">
            <effect type="dropShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="0" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="0.741" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,0,0,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="4" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="0.5" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,255,255,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="2" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="27" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="2" class="SimpleMarker" id="{1e793a68-e6d2-4643-868b-39a0cec101ee}">
          <Option type="Map">
            <Option value="90" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="0,0,0,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="triangle" name="name" type="QString"/>
            <Option value="0,-0.352941" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,0" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <effect enabled="1" type="effectStack">
            <effect type="dropShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="0" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="0.65" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,0,0,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="4" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="0.5" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,255,255,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="2" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="28" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="1" class="SimpleMarker" id="{7d701f41-05bd-4ad3-8256-315da7134c6c}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,255,255,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.5" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <effect enabled="1" type="effectStack">
            <effect type="dropShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="0" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="0.659" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,0,0,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="4" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="0.5" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,255,255,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="2" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="1" class="SimpleMarker" id="{915ee557-c26d-4080-ba10-b6c11f098582}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="0,0,0,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="1.5" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="29" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{a4fca60f-4826-4b22-a76a-7413bc5f8286}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="236,180,239,0" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="square" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="5.6" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <effect enabled="1" type="effectStack">
            <effect type="dropShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="0" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="0.751" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,0,0,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="4" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="0" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="0.439" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,0,0,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="4" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="3" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="2" class="SimpleMarker" id="{e77109f9-174e-4eea-82ff-bea5f33ff937}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="32,168,11,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.4" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="30" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{4dfb6f09-dbc9-487e-81a7-62bb6896bea9}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="1,255,30,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="1" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <effect enabled="1" type="effectStack">
            <effect type="dropShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="outerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="0" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="0.5" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,0,0,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="7" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
            <effect type="drawSource">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="1" name="enabled" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerShadow">
              <Option type="Map">
                <Option value="13" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,0,255" name="color" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="135" name="offset_angle" type="QString"/>
                <Option value="2" name="offset_distance" type="QString"/>
                <Option value="MM" name="offset_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="offset_unit_scale" type="QString"/>
                <Option value="1" name="opacity" type="QString"/>
              </Option>
            </effect>
            <effect type="innerGlow">
              <Option type="Map">
                <Option value="0" name="blend_mode" type="QString"/>
                <Option value="2.645" name="blur_level" type="QString"/>
                <Option value="MM" name="blur_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="blur_unit_scale" type="QString"/>
                <Option value="0,0,255,255" name="color1" type="QString"/>
                <Option value="0,255,0,255" name="color2" type="QString"/>
                <Option value="0" name="color_type" type="QString"/>
                <Option value="ccw" name="direction" type="QString"/>
                <Option value="0" name="discrete" type="QString"/>
                <Option value="2" name="draw_mode" type="QString"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="0.5" name="opacity" type="QString"/>
                <Option value="gradient" name="rampType" type="QString"/>
                <Option value="255,255,255,255" name="single_color" type="QString"/>
                <Option value="rgb" name="spec" type="QString"/>
                <Option value="2" name="spread" type="QString"/>
                <Option value="MM" name="spread_unit" type="QString"/>
                <Option value="3x:0,0,0,0,0,0" name="spread_unit_scale" type="QString"/>
              </Option>
            </effect>
          </effect>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="4" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="2" class="SimpleMarker" id="{e77109f9-174e-4eea-82ff-bea5f33ff937}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="11,139,168,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="triangle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.4" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="5" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="2" class="SimpleMarker" id="{64879cc4-0379-4243-b567-233ec484d22e}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="32,168,11,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="239,0,4,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.4" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{30a229e6-a376-4de7-9e4b-2c4846412d99}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,0,0,0" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="square" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="5.6" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="6" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="2" class="SimpleMarker" id="{d1a9f4cd-21b4-4af6-81d6-1fea1517bea2}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="32,168,11,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="diamond" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.4" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{7e555bcd-0bb0-4241-9fbf-a1faf866996c}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,0,0,0" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="square" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="35,35,35,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.2" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="5.6" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="7" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="2" class="SimpleMarker" id="{58f7a48d-7a41-4343-a87d-569e051ef77a}">
          <Option type="Map">
            <Option value="90" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,0,0,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="triangle" name="name" type="QString"/>
            <Option value="0,-0.352941" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,0,0,255" name="outline_color" type="QString"/>
            <Option value="no" name="outline_style" type="QString"/>
            <Option value="0.6" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="8" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="2" class="SimpleMarker" id="{3e1d59bf-39be-438c-9dc7-c3227f90f0d9}">
          <Option type="Map">
            <Option value="90" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="0,0,0,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="triangle" name="name" type="QString"/>
            <Option value="0,-0.352941" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="0,0,0,255" name="outline_color" type="QString"/>
            <Option value="no" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
      <symbol frame_rate="10" name="9" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="1" class="SimpleMarker" id="{33ced3ce-fef8-4f76-ab50-e20780dfe62a}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="248,248,248,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0.5" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="area" name="scale_method" type="QString"/>
            <Option value="3" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
        <layer enabled="1" locked="0" pass="1" class="SimpleMarker" id="{54353aab-a393-4e02-8526-d427f01b2704}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,0,0,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="255,0,0,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="1.5" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </symbols>
  </renderer-v2>
  <selection mode="Default">
    <selectionColor invalid="1"/>
    <selectionSymbol>
      <symbol frame_rate="10" name="" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
        <data_defined_properties>
          <Option type="Map">
            <Option value="" name="name" type="QString"/>
            <Option name="properties"/>
            <Option value="collection" name="type" type="QString"/>
          </Option>
        </data_defined_properties>
        <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="{9fffbb28-57ea-41b1-b58e-92698429704c}">
          <Option type="Map">
            <Option value="0" name="angle" type="QString"/>
            <Option value="square" name="cap_style" type="QString"/>
            <Option value="255,0,0,255" name="color" type="QString"/>
            <Option value="1" name="horizontal_anchor_point" type="QString"/>
            <Option value="bevel" name="joinstyle" type="QString"/>
            <Option value="circle" name="name" type="QString"/>
            <Option value="0,0" name="offset" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
            <Option value="MM" name="offset_unit" type="QString"/>
            <Option value="35,35,35,255" name="outline_color" type="QString"/>
            <Option value="solid" name="outline_style" type="QString"/>
            <Option value="0" name="outline_width" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
            <Option value="MM" name="outline_width_unit" type="QString"/>
            <Option value="diameter" name="scale_method" type="QString"/>
            <Option value="2" name="size" type="QString"/>
            <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
            <Option value="MM" name="size_unit" type="QString"/>
            <Option value="1" name="vertical_anchor_point" type="QString"/>
          </Option>
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
        </layer>
      </symbol>
    </selectionSymbol>
  </selection>
  <labeling type="rule-based">
    <rules key="{e2242ab7-a8a6-45bf-9d3a-b0928533d3a3}">
      <rule filter="1" key="{1b5de820-1f04-473a-987d-d860a9b00e90}" description="Struktur">
        <rule filter="&quot;ART&quot;  = 11 OR &quot;ART&quot;  = 12" key="{5bc88a1b-14e5-468b-b176-c7f7faf2e207}" description="HVt">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontWeight="75" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,255,255,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="7" namedStyle="Bold" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="0.71700000000000008" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="0,0,0,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="0,0,0,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="9" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{e8e268e7-2cce-4dbe-8263-b975be1b1367}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 13 AND  &quot;Zustand&quot; = 1" key="{7506b2d0-9794-45f4-aefb-9666b944de7a}" description="MFG neu">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontWeight="50" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,0,0,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="8" namedStyle="Standard" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="1" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="255,255,255,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="255,255,255,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="9" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{c2ec5964-307f-4078-9c3e-e72d4fd013c4}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 13 AND  &quot;Zustand&quot; = 2" key="{71b5b172-1d50-4f53-91ee-6e9bcde8c9a3}" description="MFG Bestand">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontWeight="75" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,255,255,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="7" namedStyle="Bold" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="0.69999999999999996" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="0,0,0,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="0,0,0,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="9" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{200ba101-4012-4400-ad50-28aae8247f7d}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 99 AND &quot;Zustand&quot; = 1 AND  &quot;Art_Sonst&quot; = 'KVz'" key="{724cb6ac-cea8-4919-bc26-d0a62e79c993}" description="KVz neu">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontWeight="50" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,0,0,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="8" namedStyle="Standard" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="1" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="255,255,255,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="255,255,255,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="9" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{3133b110-631c-45f4-bb6e-2521c22f7f98}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 99 AND &quot;Zustand&quot; = 2 AND  &quot;Art_Sonst&quot; = 'KVz'" key="{d2d465fa-5ca7-4024-b79c-2809823f2257}" description="KVz Bestand">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontWeight="75" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,255,255,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="7" namedStyle="Bold" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="0.69999999999999996" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="0,0,0,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="0,0,0,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="9" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{0a1f51cd-b112-43cf-8260-6d7511259ad1}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 30 AND &quot;Zustand&quot; = 1" key="{f8d4f319-4d7f-4cd4-80e6-b8af3727ad4b}" description="Gehäuse neu">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="'Gehäuse'" fontWeight="50" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,0,0,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="8" namedStyle="Standard" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="1" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="255,255,255,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="255,255,255,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="9" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{4baa001c-95d5-49ce-bef9-cda4cdc84c33}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 30 AND &quot;Zustand&quot; = 2" key="{452b0464-419b-4eae-9bd4-11ccb7c3dca3}" description="Gehäuse Bestand">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="'Gehäuse'" fontWeight="75" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,255,255,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="7" namedStyle="Bold" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="0.69999999999999996" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="0,0,0,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="0,0,0,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="9" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{e2c9a602-b75f-450f-bf8f-f1c1243f7cd7}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 14 AND &quot;ZUSTAND&quot; = 1" key="{439998c3-3e7e-4df3-89a2-9fc27b0ac096}" description="NVt neu">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontWeight="50" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,0,0,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="8" namedStyle="Standard" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="1" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="255,255,255,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="255,255,255,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="10" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{22f087d7-3f02-47ef-828c-bc9e0b6ced71}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 14 AND &quot;ZUSTAND&quot; = 2" key="{ff0c0d47-ba57-4295-a342-f43e959c2053}" description="NVt Bestand">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot;" fontWeight="75" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,255,255,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="7" namedStyle="Bold" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="0.69999999999999996" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="0,0,0,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="0,0,0,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="9" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{b2e24d56-94a8-488c-99d9-deac154345f1}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter="&quot;Art&quot;  = 99 AND &quot;ZUSTAND&quot; = 1 AND  &quot;Art_Sonst&quot; Like '%NVt in Muffe%'" key="{5022b6fa-f4c7-4788-88ea-9154232fe87b}" description="NVt neu (in Muffe)">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot; || ' (in Muffe)'" fontWeight="50" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,0,0,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="8" namedStyle="Standard" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="1" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="255,255,255,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="255,255,255,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="10" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{397b209f-5a5d-4707-a060-67400959efd4}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter="&quot;Art&quot;  = 99 AND &quot;ZUSTAND&quot; = 2 AND  &quot;Art_Sonst&quot; Like '%NVt in Muffe%'" key="{da61a3cd-65bb-43e9-8232-dbe7b4cdb9f9}" description="NVt Bestand (in Muffe)">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName=" &quot;ID&quot;  || ': ' || &quot;Bezeichner&quot; || ' (in Muffe)'" fontWeight="75" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,255,255,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="7" namedStyle="Bold" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="0.69999999999999996" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="0,0,0,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="0,0,0,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="9" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{db1350fc-c309-44fa-ade9-65b4f3e8b917}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule scalemindenom="1" filter="&quot;ART&quot;  = 16" key="{f6b1dbe8-3f5c-43c0-b887-c2f8a84bb968}" scalemaxdenom="5500" description="Gf-AP">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="Bezeichner" fontWeight="50" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="0,0,0,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="0" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="8" namedStyle="Standard" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="0,0,0,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="1" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="177,255,130,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="177,255,130,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="0,0,0,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="5" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{23015240-9d52-4d01-b773-49aefffcd8b4}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter="&quot;ART&quot;  = 99 AND &quot;NT_SONST&quot;  = 'Mastbox'" key="{2869e9c8-d190-44a1-b4e3-9d7b3cbf6860}" description="Mastboxen">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="'Mastbox'" fontWeight="50" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="0,0,0,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="8.1999999999999993" namedStyle="Standard" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="0.317" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="236,82,239,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="236,82,239,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="no" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="5" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{f2fa0226-6761-4d80-a182-56ced64f0930}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
      </rule>
      <rule filter="0" key="{6b795808-3b06-455f-9f2a-d3f43d40fde2}" description="Detail">
        <rule filter="&quot;ART&quot;  = 11 OR &quot;ART&quot;  = 12" key="{178adb39-1a48-4a43-96b4-ee95045d979d}" description="HVt">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="'HVt-ID: ' ||  &quot;ID&quot;  || '>   ' || &quot;BEZEICHNER&quot;  " fontWeight="75" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,255,255,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="7" namedStyle="Bold" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="0.71700000000000008" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="0,0,0,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="0,0,0,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="5" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{0fa4ca71-1f7c-4827-8de2-398ca75f3880}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 13 AND  &quot;Zustand&quot; = 1" key="{10d5d44a-9bbf-4037-93f2-e008725939c3}" description="MFG neu">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="'MFG-ID: '||&quot;ID&quot;||'   ID_Tech: '||&quot;ID_Tech&quot; ||'>'||&quot;BEZEICHNER&quot;" fontWeight="50" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,0,0,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="8" namedStyle="Standard" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="1" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="255,255,255,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="255,255,255,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="5" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{04225efd-7cc0-4677-84df-a843086afe4f}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 13 AND  &quot;Zustand&quot; = 2" key="{172aad1d-3319-451d-a01f-5e2ea0da410f}" description="MFG Bestand">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="'MFG-ID: '||&quot;ID&quot;||'   ID_Tech: '||&quot;ID_Tech&quot; ||'>'||&quot;BEZEICHNER&quot;" fontWeight="75" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,255,255,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="7" namedStyle="Bold" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="0.69999999999999996" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="0,0,0,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="0,0,0,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="5" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{b5b8dfcf-797a-4379-81ed-c6c30fee377a}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 99 AND &quot;Zustand&quot; = 1 AND  &quot;Art_Sonst&quot; = 'KVz'" key="{bd14f55a-654c-4315-b00e-c88e32557a79}" description="KVz neu">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="'KVz-ID: '||&quot;ID&quot;||'   ID_Tech: '||&quot;ID_Tech&quot; ||'>'||&quot;BEZEICHNER&quot;" fontWeight="50" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,0,0,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="8" namedStyle="Standard" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="1" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="255,255,255,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="255,255,255,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="5" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{524322c7-e483-4f1d-8020-4a5428dacff5}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 99 AND &quot;Zustand&quot; = 2 AND  &quot;Art_Sonst&quot; = 'KVz'" key="{298901d1-968b-40a6-8461-1314a492e928}" description="KVz Bestand">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="'KVz-ID: '||&quot;ID&quot;||'   ID_Tech: '||&quot;ID_Tech&quot; ||'>'||&quot;BEZEICHNER&quot;" fontWeight="75" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,255,255,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="7" namedStyle="Bold" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="0.69999999999999996" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="0,0,0,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="0,0,0,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="5" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{da0bfa3a-0aa8-4c06-87a8-abb6582937f8}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 30 AND &quot;Zustand&quot; = 1" key="{70cccaf8-0447-4350-9869-16203e707fc1}" description="Gehäuse neu">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="'Gehäuse' ||'   ID_Tech: '||&quot;ID_Tech&quot; " fontWeight="50" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,0,0,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="8" namedStyle="Standard" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="1" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="255,255,255,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="255,255,255,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="5" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{515e4d29-4fc0-40e2-bd45-bb7e303607c9}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 30 AND &quot;Zustand&quot; = 2" key="{f27a5ea8-1eda-428a-bd60-f15ce23da0ab}" description="Gehäuse Bestand">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="'Gehäuse' ||'   ID_Tech: '||&quot;ID_Tech&quot; " fontWeight="75" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,255,255,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="7" namedStyle="Bold" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="0.69999999999999996" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="0,0,0,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="0,0,0,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="5" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{f4d565f6-1ecb-4487-8b27-a5e044a602c8}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 14 AND &quot;Zustand&quot; = 1" key="{fa255b40-0805-442b-9f25-e2de67adf891}" description="NVt neu">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="'NVt-ID: '|| &quot;ID&quot; || '   ID_Tech: ' || &quot;ID_Tech&quot; || '>' ||&quot;BEZEICHNER&quot;" fontWeight="50" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,0,0,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="8" namedStyle="Standard" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="1" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="255,255,255,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="255,255,255,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="5" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{e771f9b5-b513-4130-b4f3-dcb3fba4d3cb}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter=" &quot;ART&quot;  = 14 AND &quot;Zustand&quot; = 2" key="{87e0a771-b503-4fe0-81a7-ac3b5b7dd4b4}" description="NVt Bestand">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="'NVt-ID: '|| &quot;ID&quot; || '   ID_Tech: ' || &quot;ID_Tech&quot; || '>' ||&quot;BEZEICHNER&quot;" fontWeight="75" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="255,255,255,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="7" namedStyle="Bold" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="0.69999999999999996" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="0,0,0,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="0,0,0,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="5" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{b757d8e1-296a-4118-9898-58e0af7ded36}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter="&quot;ART&quot;  = 16" key="{18f7d68b-c3ba-4341-a3d8-c167ecc397d3}" description="Gf-AP">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="&quot;BEZEICHNER&quot;||'>'||'ID_Tech: '||&quot;ID_Tech&quot; " fontWeight="50" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="0,0,0,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="8" namedStyle="Standard" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="0,0,0,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="1" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="177,255,130,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0.10000000000000001">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="177,255,130,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="0,0,0,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0.1" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="5" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{243bd7b1-5c0b-4c06-932e-56912cecacc3}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
        <rule filter="&quot;ART&quot;  = 99 AND &quot;NT_SONST&quot;  = 'Mastbox'" key="{b3091ace-6a9e-4e33-9796-d60e48d2dec6}" description="Mastboxen">
          <settings calloutType="simple">
            <text-style forcedItalic="0" capitalization="0" fontUnderline="0" textOrientation="horizontal" forcedBold="0" multilineHeightUnit="Percentage" useSubstitutions="0" fontWordSpacing="0" fieldName="'Mastbox'" fontWeight="50" textOpacity="1" multilineHeight="1" fontFamily="MS Shell Dlg 2" fontSizeMapUnitScale="3x:0,0,0,0,0,0" textColor="0,0,0,255" previewBkgrdColor="255,255,255,255" blendMode="0" isExpression="1" legendString="Aa" fontLetterSpacing="0" fontStrikeout="0" fontKerning="1" fontItalic="0" fontSize="8.1999999999999993" namedStyle="Standard" fontSizeUnit="Point" allowHtml="0">
              <families/>
              <text-buffer bufferNoFill="1" bufferOpacity="1" bufferSizeUnits="MM" bufferSizeMapUnitScale="3x:0,0,0,0,0,0" bufferJoinStyle="128" bufferDraw="0" bufferBlendMode="0" bufferSize="1" bufferColor="255,255,255,255"/>
              <text-mask maskType="0" maskOpacity="1" maskSizeUnits="MM" maskJoinStyle="128" maskSize="1.5" maskSizeMapUnitScale="3x:0,0,0,0,0,0" maskEnabled="0" maskedSymbolLayers=""/>
              <background shapeSizeType="0" shapeBorderColor="128,128,128,255" shapeOffsetMapUnitScale="3x:0,0,0,0,0,0" shapeSizeUnit="MM" shapeSizeY="0" shapeSizeX="0" shapeRadiiX="0" shapeBlendMode="0" shapeRotation="0" shapeSVGFile="" shapeType="0" shapeRadiiUnit="MM" shapeJoinStyle="64" shapeOpacity="0.317" shapeOffsetX="0" shapeBorderWidthUnit="MM" shapeRadiiMapUnitScale="3x:0,0,0,0,0,0" shapeOffsetY="0" shapeFillColor="236,82,239,255" shapeOffsetUnit="MM" shapeBorderWidthMapUnitScale="3x:0,0,0,0,0,0" shapeDraw="1" shapeRadiiY="0" shapeRotationType="0" shapeSizeMapUnitScale="3x:0,0,0,0,0,0" shapeBorderWidth="0">
                <symbol frame_rate="10" name="markerSymbol" is_animated="0" type="marker" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleMarker" id="">
                    <Option type="Map">
                      <Option value="0" name="angle" type="QString"/>
                      <Option value="square" name="cap_style" type="QString"/>
                      <Option value="145,82,45,255" name="color" type="QString"/>
                      <Option value="1" name="horizontal_anchor_point" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="circle" name="name" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="35,35,35,255" name="outline_color" type="QString"/>
                      <Option value="solid" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="outline_width_map_unit_scale" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="diameter" name="scale_method" type="QString"/>
                      <Option value="2" name="size" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="size_map_unit_scale" type="QString"/>
                      <Option value="MM" name="size_unit" type="QString"/>
                      <Option value="1" name="vertical_anchor_point" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
                <symbol frame_rate="10" name="fillSymbol" is_animated="0" type="fill" clip_to_extent="1" alpha="1" force_rhr="0">
                  <data_defined_properties>
                    <Option type="Map">
                      <Option value="" name="name" type="QString"/>
                      <Option name="properties"/>
                      <Option value="collection" name="type" type="QString"/>
                    </Option>
                  </data_defined_properties>
                  <layer enabled="1" locked="0" pass="0" class="SimpleFill" id="">
                    <Option type="Map">
                      <Option value="3x:0,0,0,0,0,0" name="border_width_map_unit_scale" type="QString"/>
                      <Option value="236,82,239,255" name="color" type="QString"/>
                      <Option value="bevel" name="joinstyle" type="QString"/>
                      <Option value="0,0" name="offset" type="QString"/>
                      <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
                      <Option value="MM" name="offset_unit" type="QString"/>
                      <Option value="128,128,128,255" name="outline_color" type="QString"/>
                      <Option value="no" name="outline_style" type="QString"/>
                      <Option value="0" name="outline_width" type="QString"/>
                      <Option value="MM" name="outline_width_unit" type="QString"/>
                      <Option value="solid" name="style" type="QString"/>
                    </Option>
                    <data_defined_properties>
                      <Option type="Map">
                        <Option value="" name="name" type="QString"/>
                        <Option name="properties"/>
                        <Option value="collection" name="type" type="QString"/>
                      </Option>
                    </data_defined_properties>
                  </layer>
                </symbol>
              </background>
              <shadow shadowDraw="0" shadowOffsetMapUnitScale="3x:0,0,0,0,0,0" shadowScale="100" shadowBlendMode="6" shadowOffsetAngle="135" shadowRadiusMapUnitScale="3x:0,0,0,0,0,0" shadowRadiusUnit="MM" shadowOpacity="0.69999999999999996" shadowRadiusAlphaOnly="0" shadowOffsetUnit="MM" shadowRadius="1.5" shadowColor="0,0,0,255" shadowOffsetDist="1" shadowUnder="0" shadowOffsetGlobal="1"/>
              <dd_properties>
                <Option type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
              </dd_properties>
              <substitutions/>
            </text-style>
            <text-format leftDirectionSymbol="&lt;" multilineAlign="3" decimals="3" addDirectionSymbol="0" reverseDirectionSymbol="0" wrapChar=">" placeDirectionSymbol="0" useMaxLineLengthForAutoWrap="1" autoWrapLength="0" rightDirectionSymbol=">" plussign="0" formatNumbers="0"/>
            <placement preserveRotation="1" overrunDistanceUnit="MM" lineAnchorType="0" labelOffsetMapUnitScale="3x:0,0,0,0,0,0" dist="10" repeatDistance="0" rotationAngle="0" maxCurvedCharAngleIn="25" distMapUnitScale="3x:0,0,0,0,0,0" predefinedPositionOrder="TR,TL,BR,BL,R,L,TSR,BSR" lineAnchorPercent="0.5" maxCurvedCharAngleOut="-25" allowDegraded="0" yOffset="0" offsetUnits="MM" polygonPlacementFlags="2" offsetType="0" overlapHandling="PreventOverlap" centroidWhole="0" repeatDistanceUnits="MM" repeatDistanceMapUnitScale="3x:0,0,0,0,0,0" layerType="PointGeometry" priority="5" overrunDistance="0" geometryGeneratorType="PointGeometry" distUnits="Pixel" lineAnchorTextPoint="CenterOfText" quadOffset="4" lineAnchorClipping="0" xOffset="0" geometryGenerator="" placement="0" placementFlags="10" centroidInside="0" rotationUnit="AngleDegrees" fitInPolygonOnly="0" geometryGeneratorEnabled="0" overrunDistanceMapUnitScale="3x:0,0,0,0,0,0"/>
            <rendering drawLabels="1" limitNumLabels="0" zIndex="0" unplacedVisibility="0" minFeatureSize="0" obstacleFactor="1" fontLimitPixelSize="0" maxNumLabels="2000" fontMaxPixelSize="10000" scaleMax="0" fontMinPixelSize="3" obstacleType="0" obstacle="1" scaleMin="0" mergeLines="0" scaleVisibility="0" upsidedownLabels="0" labelPerPart="0"/>
            <dd_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </dd_properties>
            <callout type="simple">
              <Option type="Map">
                <Option value="pole_of_inaccessibility" name="anchorPoint" type="QString"/>
                <Option value="0" name="blendMode" type="int"/>
                <Option name="ddProperties" type="Map">
                  <Option value="" name="name" type="QString"/>
                  <Option name="properties"/>
                  <Option value="collection" name="type" type="QString"/>
                </Option>
                <Option value="false" name="drawToAllParts" type="bool"/>
                <Option value="0" name="enabled" type="QString"/>
                <Option value="point_on_exterior" name="labelAnchorPoint" type="QString"/>
                <Option value="&lt;symbol frame_rate=&quot;10&quot; name=&quot;symbol&quot; is_animated=&quot;0&quot; type=&quot;line&quot; clip_to_extent=&quot;1&quot; alpha=&quot;1&quot; force_rhr=&quot;0&quot;>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;layer enabled=&quot;1&quot; locked=&quot;0&quot; pass=&quot;0&quot; class=&quot;SimpleLine&quot; id=&quot;{413fb126-aefb-406c-ad79-691cf2c68246}&quot;>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;0&quot; name=&quot;align_dash_pattern&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;square&quot; name=&quot;capstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;5;2&quot; name=&quot;customdash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;customdash_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;customdash_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;dash_pattern_offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;dash_pattern_offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;dash_pattern_offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;draw_inside_polygon&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;bevel&quot; name=&quot;joinstyle&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;60,60,60,255&quot; name=&quot;line_color&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;solid&quot; name=&quot;line_style&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0.3&quot; name=&quot;line_width&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;line_width_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;offset&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;offset_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;offset_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;ring_filter&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_end&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_end_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_end_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;trim_distance_start&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;trim_distance_start_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;MM&quot; name=&quot;trim_distance_start_unit&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;tweak_dash_pattern_on_corners&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;0&quot; name=&quot;use_custom_dash&quot; type=&quot;QString&quot;/>&lt;Option value=&quot;3x:0,0,0,0,0,0&quot; name=&quot;width_map_unit_scale&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;data_defined_properties>&lt;Option type=&quot;Map&quot;>&lt;Option value=&quot;&quot; name=&quot;name&quot; type=&quot;QString&quot;/>&lt;Option name=&quot;properties&quot;/>&lt;Option value=&quot;collection&quot; name=&quot;type&quot; type=&quot;QString&quot;/>&lt;/Option>&lt;/data_defined_properties>&lt;/layer>&lt;/symbol>" name="lineSymbol" type="QString"/>
                <Option value="0" name="minLength" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="minLengthMapUnitScale" type="QString"/>
                <Option value="MM" name="minLengthUnit" type="QString"/>
                <Option value="0" name="offsetFromAnchor" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromAnchorMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromAnchorUnit" type="QString"/>
                <Option value="0" name="offsetFromLabel" type="double"/>
                <Option value="3x:0,0,0,0,0,0" name="offsetFromLabelMapUnitScale" type="QString"/>
                <Option value="MM" name="offsetFromLabelUnit" type="QString"/>
              </Option>
            </callout>
          </settings>
        </rule>
      </rule>
    </rules>
  </labeling>
  <customproperties>
    <Option type="Map">
      <Option name="dualview/previewExpressions" type="List">
        <Option value="COALESCE( &quot;E_FNAME&quot;, '&lt;NULL>' )" type="QString"/>
      </Option>
      <Option value="0" name="embeddedWidgets/count" type="QString"/>
      <Option name="variableNames"/>
      <Option name="variableValues"/>
    </Option>
  </customproperties>
  <blendMode>0</blendMode>
  <featureBlendMode>0</featureBlendMode>
  <layerOpacity>1</layerOpacity>
  <SingleCategoryDiagramRenderer attributeLegend="1" diagramType="Histogram">
    <DiagramCategory rotationOffset="270" spacing="0" backgroundColor="#ffffff" width="15" lineSizeType="MM" minScaleDenominator="0" enabled="0" maxScaleDenominator="1e+08" spacingUnit="MM" lineSizeScale="3x:0,0,0,0,0,0" penAlpha="255" barWidth="5" labelPlacementMethod="XHeight" spacingUnitScale="3x:0,0,0,0,0,0" direction="1" sizeType="MM" backgroundAlpha="255" minimumSize="0" penColor="#000000" scaleBasedVisibility="0" showAxis="0" height="15" opacity="1" penWidth="0" scaleDependency="Area" diagramOrientation="Up" sizeScale="3x:0,0,0,0,0,0">
      <fontProperties italic="0" style="" strikethrough="0" description="MS Shell Dlg 2,8.25,-1,5,50,0,0,0,0,0" bold="0" underline="0"/>
      <attribute colorOpacity="1" label="" field="" color="#000000"/>
      <axisSymbol>
        <symbol frame_rate="10" name="" is_animated="0" type="line" clip_to_extent="1" alpha="1" force_rhr="0">
          <data_defined_properties>
            <Option type="Map">
              <Option value="" name="name" type="QString"/>
              <Option name="properties"/>
              <Option value="collection" name="type" type="QString"/>
            </Option>
          </data_defined_properties>
          <layer enabled="1" locked="0" pass="0" class="SimpleLine" id="{1099f535-e851-4ce7-b92a-6dbe225ac513}">
            <Option type="Map">
              <Option value="0" name="align_dash_pattern" type="QString"/>
              <Option value="square" name="capstyle" type="QString"/>
              <Option value="5;2" name="customdash" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="customdash_map_unit_scale" type="QString"/>
              <Option value="MM" name="customdash_unit" type="QString"/>
              <Option value="0" name="dash_pattern_offset" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="dash_pattern_offset_map_unit_scale" type="QString"/>
              <Option value="MM" name="dash_pattern_offset_unit" type="QString"/>
              <Option value="0" name="draw_inside_polygon" type="QString"/>
              <Option value="bevel" name="joinstyle" type="QString"/>
              <Option value="35,35,35,255" name="line_color" type="QString"/>
              <Option value="solid" name="line_style" type="QString"/>
              <Option value="0.26" name="line_width" type="QString"/>
              <Option value="MM" name="line_width_unit" type="QString"/>
              <Option value="0" name="offset" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="offset_map_unit_scale" type="QString"/>
              <Option value="MM" name="offset_unit" type="QString"/>
              <Option value="0" name="ring_filter" type="QString"/>
              <Option value="0" name="trim_distance_end" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="trim_distance_end_map_unit_scale" type="QString"/>
              <Option value="MM" name="trim_distance_end_unit" type="QString"/>
              <Option value="0" name="trim_distance_start" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="trim_distance_start_map_unit_scale" type="QString"/>
              <Option value="MM" name="trim_distance_start_unit" type="QString"/>
              <Option value="0" name="tweak_dash_pattern_on_corners" type="QString"/>
              <Option value="0" name="use_custom_dash" type="QString"/>
              <Option value="3x:0,0,0,0,0,0" name="width_map_unit_scale" type="QString"/>
            </Option>
            <data_defined_properties>
              <Option type="Map">
                <Option value="" name="name" type="QString"/>
                <Option name="properties"/>
                <Option value="collection" name="type" type="QString"/>
              </Option>
            </data_defined_properties>
          </layer>
        </symbol>
      </axisSymbol>
    </DiagramCategory>
  </SingleCategoryDiagramRenderer>
  <DiagramLayerSettings obstacle="0" priority="0" placement="0" dist="0" linePlacementFlags="18" zIndex="0" showAll="1">
    <properties>
      <Option type="Map">
        <Option value="" name="name" type="QString"/>
        <Option name="properties"/>
        <Option value="collection" name="type" type="QString"/>
      </Option>
    </properties>
  </DiagramLayerSettings>
  <geometryOptions geometryPrecision="0" removeDuplicateNodes="0">
    <activeChecks/>
    <checkConfiguration/>
  </geometryOptions>
  <legend type="default-vector" showLabelLegend="0"/>
  <referencedLayers/>
  <fieldConfiguration>
    <field configurationFlags="NoFlag" name="fid">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Art">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Art_Sonst">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Zustand">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="Bezeichner">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ID_Tech">
      <editWidget type="Range">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="TE_ART_VOR">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="TE_V_SONST">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="KD_ANB_V">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ANZ_ANS_V">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="KD_ANB_G">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="ANZ_ANS_G">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="SENDE_GEOM">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="SENDE_BB">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="SI_ABST_XY">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="SI_ABST_Z">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="MONT_Z">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="MP_MBFD_CO">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="STRUCTURE_">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="MP_DB_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="MP_ID">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="SM_AUFTRAG">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
    <field configurationFlags="NoFlag" name="BEZ_OLD">
      <editWidget type="TextEdit">
        <config>
          <Option/>
        </config>
      </editWidget>
    </field>
  </fieldConfiguration>
  <aliases>
    <alias name="" index="0" field="fid"/>
    <alias name="" index="1" field="Art"/>
    <alias name="" index="2" field="Art_Sonst"/>
    <alias name="" index="3" field="Zustand"/>
    <alias name="" index="4" field="Bezeichner"/>
    <alias name="" index="5" field="ID"/>
    <alias name="" index="6" field="ID_Tech"/>
    <alias name="" index="7" field="TE_ART_VOR"/>
    <alias name="" index="8" field="TE_V_SONST"/>
    <alias name="" index="9" field="KD_ANB_V"/>
    <alias name="" index="10" field="ANZ_ANS_V"/>
    <alias name="" index="11" field="KD_ANB_G"/>
    <alias name="" index="12" field="ANZ_ANS_G"/>
    <alias name="" index="13" field="SENDE_GEOM"/>
    <alias name="" index="14" field="SENDE_BB"/>
    <alias name="" index="15" field="SI_ABST_XY"/>
    <alias name="" index="16" field="SI_ABST_Z"/>
    <alias name="" index="17" field="MONT_Z"/>
    <alias name="" index="18" field="MP_MBFD_CO"/>
    <alias name="" index="19" field="STRUCTURE_"/>
    <alias name="" index="20" field="MP_DB_ID"/>
    <alias name="" index="21" field="MP_ID"/>
    <alias name="" index="22" field="SM_AUFTRAG"/>
    <alias name="" index="23" field="BEZ_OLD"/>
  </aliases>
  <splitPolicies>
    <policy policy="Duplicate" field="fid"/>
    <policy policy="Duplicate" field="Art"/>
    <policy policy="Duplicate" field="Art_Sonst"/>
    <policy policy="Duplicate" field="Zustand"/>
    <policy policy="Duplicate" field="Bezeichner"/>
    <policy policy="Duplicate" field="ID"/>
    <policy policy="Duplicate" field="ID_Tech"/>
    <policy policy="Duplicate" field="TE_ART_VOR"/>
    <policy policy="Duplicate" field="TE_V_SONST"/>
    <policy policy="Duplicate" field="KD_ANB_V"/>
    <policy policy="Duplicate" field="ANZ_ANS_V"/>
    <policy policy="Duplicate" field="KD_ANB_G"/>
    <policy policy="Duplicate" field="ANZ_ANS_G"/>
    <policy policy="Duplicate" field="SENDE_GEOM"/>
    <policy policy="Duplicate" field="SENDE_BB"/>
    <policy policy="Duplicate" field="SI_ABST_XY"/>
    <policy policy="Duplicate" field="SI_ABST_Z"/>
    <policy policy="Duplicate" field="MONT_Z"/>
    <policy policy="Duplicate" field="MP_MBFD_CO"/>
    <policy policy="Duplicate" field="STRUCTURE_"/>
    <policy policy="Duplicate" field="MP_DB_ID"/>
    <policy policy="Duplicate" field="MP_ID"/>
    <policy policy="Duplicate" field="SM_AUFTRAG"/>
    <policy policy="Duplicate" field="BEZ_OLD"/>
  </splitPolicies>
  <defaults>
    <default expression="" applyOnUpdate="0" field="fid"/>
    <default expression="" applyOnUpdate="0" field="Art"/>
    <default expression="" applyOnUpdate="0" field="Art_Sonst"/>
    <default expression="" applyOnUpdate="0" field="Zustand"/>
    <default expression="" applyOnUpdate="0" field="Bezeichner"/>
    <default expression="" applyOnUpdate="0" field="ID"/>
    <default expression="" applyOnUpdate="0" field="ID_Tech"/>
    <default expression="" applyOnUpdate="0" field="TE_ART_VOR"/>
    <default expression="" applyOnUpdate="0" field="TE_V_SONST"/>
    <default expression="" applyOnUpdate="0" field="KD_ANB_V"/>
    <default expression="" applyOnUpdate="0" field="ANZ_ANS_V"/>
    <default expression="" applyOnUpdate="0" field="KD_ANB_G"/>
    <default expression="" applyOnUpdate="0" field="ANZ_ANS_G"/>
    <default expression="" applyOnUpdate="0" field="SENDE_GEOM"/>
    <default expression="" applyOnUpdate="0" field="SENDE_BB"/>
    <default expression="" applyOnUpdate="0" field="SI_ABST_XY"/>
    <default expression="" applyOnUpdate="0" field="SI_ABST_Z"/>
    <default expression="" applyOnUpdate="0" field="MONT_Z"/>
    <default expression="" applyOnUpdate="0" field="MP_MBFD_CO"/>
    <default expression="" applyOnUpdate="0" field="STRUCTURE_"/>
    <default expression="" applyOnUpdate="0" field="MP_DB_ID"/>
    <default expression="" applyOnUpdate="0" field="MP_ID"/>
    <default expression="" applyOnUpdate="0" field="SM_AUFTRAG"/>
    <default expression="" applyOnUpdate="0" field="BEZ_OLD"/>
  </defaults>
  <constraints>
    <constraint constraints="3" exp_strength="0" field="fid" notnull_strength="1" unique_strength="1"/>
    <constraint constraints="0" exp_strength="0" field="Art" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Art_Sonst" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Zustand" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="Bezeichner" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="ID" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="ID_Tech" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="TE_ART_VOR" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="TE_V_SONST" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="KD_ANB_V" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="ANZ_ANS_V" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="KD_ANB_G" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="ANZ_ANS_G" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="SENDE_GEOM" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="SENDE_BB" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="SI_ABST_XY" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="SI_ABST_Z" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="MONT_Z" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="MP_MBFD_CO" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="STRUCTURE_" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="MP_DB_ID" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="MP_ID" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="SM_AUFTRAG" notnull_strength="0" unique_strength="0"/>
    <constraint constraints="0" exp_strength="0" field="BEZ_OLD" notnull_strength="0" unique_strength="0"/>
  </constraints>
  <constraintExpressions>
    <constraint exp="" desc="" field="fid"/>
    <constraint exp="" desc="" field="Art"/>
    <constraint exp="" desc="" field="Art_Sonst"/>
    <constraint exp="" desc="" field="Zustand"/>
    <constraint exp="" desc="" field="Bezeichner"/>
    <constraint exp="" desc="" field="ID"/>
    <constraint exp="" desc="" field="ID_Tech"/>
    <constraint exp="" desc="" field="TE_ART_VOR"/>
    <constraint exp="" desc="" field="TE_V_SONST"/>
    <constraint exp="" desc="" field="KD_ANB_V"/>
    <constraint exp="" desc="" field="ANZ_ANS_V"/>
    <constraint exp="" desc="" field="KD_ANB_G"/>
    <constraint exp="" desc="" field="ANZ_ANS_G"/>
    <constraint exp="" desc="" field="SENDE_GEOM"/>
    <constraint exp="" desc="" field="SENDE_BB"/>
    <constraint exp="" desc="" field="SI_ABST_XY"/>
    <constraint exp="" desc="" field="SI_ABST_Z"/>
    <constraint exp="" desc="" field="MONT_Z"/>
    <constraint exp="" desc="" field="MP_MBFD_CO"/>
    <constraint exp="" desc="" field="STRUCTURE_"/>
    <constraint exp="" desc="" field="MP_DB_ID"/>
    <constraint exp="" desc="" field="MP_ID"/>
    <constraint exp="" desc="" field="SM_AUFTRAG"/>
    <constraint exp="" desc="" field="BEZ_OLD"/>
  </constraintExpressions>
  <expressionfields/>
  <attributeactions>
    <defaultAction value="{00000000-0000-0000-0000-000000000000}" key="Canvas"/>
  </attributeactions>
  <attributetableconfig sortExpression="&quot;ID&quot;" actionWidgetStyle="dropDown" sortOrder="0">
    <columns>
      <column hidden="0" name="fid" type="field" width="-1"/>
      <column hidden="0" name="ID" type="field" width="100"/>
      <column hidden="0" name="Art" type="field" width="-1"/>
      <column hidden="0" name="Art_Sonst" type="field" width="186"/>
      <column hidden="0" name="Zustand" type="field" width="-1"/>
      <column hidden="0" name="Bezeichner" type="field" width="-1"/>
      <column hidden="0" name="ID_Tech" type="field" width="-1"/>
      <column hidden="1" name="TE_ART_VOR" type="field" width="-1"/>
      <column hidden="1" name="TE_V_SONST" type="field" width="-1"/>
      <column hidden="1" name="KD_ANB_V" type="field" width="-1"/>
      <column hidden="1" name="ANZ_ANS_V" type="field" width="-1"/>
      <column hidden="1" name="KD_ANB_G" type="field" width="-1"/>
      <column hidden="1" name="ANZ_ANS_G" type="field" width="-1"/>
      <column hidden="1" name="SENDE_GEOM" type="field" width="-1"/>
      <column hidden="1" name="SENDE_BB" type="field" width="-1"/>
      <column hidden="1" name="SI_ABST_XY" type="field" width="-1"/>
      <column hidden="1" name="SI_ABST_Z" type="field" width="-1"/>
      <column hidden="1" name="MONT_Z" type="field" width="-1"/>
      <column hidden="1" name="MP_MBFD_CO" type="field" width="-1"/>
      <column hidden="1" name="STRUCTURE_" type="field" width="-1"/>
      <column hidden="1" name="MP_DB_ID" type="field" width="-1"/>
      <column hidden="1" name="MP_ID" type="field" width="-1"/>
      <column hidden="1" name="SM_AUFTRAG" type="field" width="-1"/>
      <column hidden="1" name="BEZ_OLD" type="field" width="-1"/>
      <column hidden="1" type="actions" width="-1"/>
    </columns>
  </attributetableconfig>
  <conditionalstyles>
    <rowstyles/>
    <fieldstyles/>
  </conditionalstyles>
  <storedexpressions/>
  <editform tolerant="1">C:/Users/A754221/OneDrive - Deutsche Telekom AG/Desktop/QGIS 3.10/bin</editform>
  <editforminit/>
  <editforminitcodesource>0</editforminitcodesource>
  <editforminitfilepath>C:/Users/A754221/OneDrive - Deutsche Telekom AG/Desktop/QGIS 3.10/bin</editforminitfilepath>
  <editforminitcode><![CDATA[# -*- coding: utf-8 -*-
"""
QGIS forms can have a Python function that is called when the form is
opened.

Use this function to add extra logic to your forms.

Enter the name of the function in the "Python Init function"
field.
An example follows:
"""
from qgis.PyQt.QtWidgets import QWidget

def my_form_open(dialog, layer, feature):
	geom = feature.geometry()
	control = dialog.findChild(QWidget, "MyLineEdit")
]]></editforminitcode>
  <featformsuppress>0</featformsuppress>
  <editorlayout>generatedlayout</editorlayout>
  <attributeEditorForm>
    <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="0">
      <labelFont italic="0" style="" strikethrough="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" bold="0" underline="0"/>
    </labelStyle>
    <attributeEditorField horizontalStretch="0" name="ID" showLabel="1" index="5" verticalStretch="0">
      <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="0">
        <labelFont italic="0" style="" strikethrough="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" bold="0" underline="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField horizontalStretch="0" name="ID_Tech" showLabel="1" index="6" verticalStretch="0">
      <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="0">
        <labelFont italic="0" style="" strikethrough="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" bold="0" underline="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField horizontalStretch="0" name="Art" showLabel="1" index="1" verticalStretch="0">
      <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="0">
        <labelFont italic="0" style="" strikethrough="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" bold="0" underline="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField horizontalStretch="0" name="Art_Sonst" showLabel="1" index="2" verticalStretch="0">
      <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="0">
        <labelFont italic="0" style="" strikethrough="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" bold="0" underline="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField horizontalStretch="0" name="Zustand" showLabel="1" index="3" verticalStretch="0">
      <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="0">
        <labelFont italic="0" style="" strikethrough="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" bold="0" underline="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField horizontalStretch="0" name="Bezeichner" showLabel="1" index="4" verticalStretch="0">
      <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="0">
        <labelFont italic="0" style="" strikethrough="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" bold="0" underline="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField horizontalStretch="0" name="Te_Art_Gep" showLabel="1" index="-1" verticalStretch="0">
      <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="0">
        <labelFont italic="0" style="" strikethrough="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" bold="0" underline="0"/>
      </labelStyle>
    </attributeEditorField>
    <attributeEditorField horizontalStretch="0" name="Te_G_Sonst" showLabel="1" index="-1" verticalStretch="0">
      <labelStyle labelColor="0,0,0,255" overrideLabelColor="0" overrideLabelFont="0">
        <labelFont italic="0" style="" strikethrough="0" description="MS Shell Dlg 2,8.3,-1,5,50,0,0,0,0,0" bold="0" underline="0"/>
      </labelStyle>
    </attributeEditorField>
  </attributeEditorForm>
  <editable>
    <field name="ANZ_ANS_G" editable="1"/>
    <field name="ANZ_ANS_V" editable="1"/>
    <field name="ART_NT" editable="1"/>
    <field name="A_E_MAIL" editable="1"/>
    <field name="A_TEL" editable="1"/>
    <field name="A_VNAME" editable="1"/>
    <field name="A_ZNAME" editable="1"/>
    <field name="Art" editable="1"/>
    <field name="Art_Sonst" editable="1"/>
    <field name="BEZEICHNER" editable="1"/>
    <field name="BEZ_OLD" editable="1"/>
    <field name="Bezeichner" editable="1"/>
    <field name="E_E_MAIL" editable="1"/>
    <field name="E_FNAME" editable="1"/>
    <field name="E_ORT" editable="1"/>
    <field name="E_TEL" editable="1"/>
    <field name="GID" editable="1"/>
    <field name="ID" editable="1"/>
    <field name="ID_BAU" editable="1"/>
    <field name="ID_TECH" editable="1"/>
    <field name="ID_Tech" editable="1"/>
    <field name="KD_ANB_G" editable="1"/>
    <field name="KD_ANB_V" editable="1"/>
    <field name="MONT_Z" editable="1"/>
    <field name="MP_DB_ID" editable="1"/>
    <field name="MP_ID" editable="1"/>
    <field name="MP_MBFD_CO" editable="1"/>
    <field name="NT_SONST" editable="1"/>
    <field name="SENDE_BB" editable="1"/>
    <field name="SENDE_GEOM" editable="1"/>
    <field name="SI_ABST_XY" editable="1"/>
    <field name="SI_ABST_Z" editable="1"/>
    <field name="SM_AUFTRAG" editable="1"/>
    <field name="STRUCTURE_" editable="1"/>
    <field name="TE_ART_GEP" editable="1"/>
    <field name="TE_ART_VOR" editable="1"/>
    <field name="TE_G_SONST" editable="1"/>
    <field name="TE_V_SONST" editable="1"/>
    <field name="Te_Art_Gep" editable="1"/>
    <field name="Te_G_Sonst" editable="1"/>
    <field name="ZUSTAND" editable="1"/>
    <field name="Zustand" editable="1"/>
    <field name="fid" editable="1"/>
    <field name="id_0" editable="1"/>
  </editable>
  <labelOnTop>
    <field labelOnTop="0" name="ANZ_ANS_G"/>
    <field labelOnTop="0" name="ANZ_ANS_V"/>
    <field labelOnTop="0" name="ART_NT"/>
    <field labelOnTop="0" name="A_E_MAIL"/>
    <field labelOnTop="0" name="A_TEL"/>
    <field labelOnTop="0" name="A_VNAME"/>
    <field labelOnTop="0" name="A_ZNAME"/>
    <field labelOnTop="0" name="Art"/>
    <field labelOnTop="0" name="Art_Sonst"/>
    <field labelOnTop="0" name="BEZEICHNER"/>
    <field labelOnTop="0" name="BEZ_OLD"/>
    <field labelOnTop="0" name="Bezeichner"/>
    <field labelOnTop="0" name="E_E_MAIL"/>
    <field labelOnTop="0" name="E_FNAME"/>
    <field labelOnTop="0" name="E_ORT"/>
    <field labelOnTop="0" name="E_TEL"/>
    <field labelOnTop="0" name="GID"/>
    <field labelOnTop="0" name="ID"/>
    <field labelOnTop="0" name="ID_BAU"/>
    <field labelOnTop="0" name="ID_TECH"/>
    <field labelOnTop="0" name="ID_Tech"/>
    <field labelOnTop="0" name="KD_ANB_G"/>
    <field labelOnTop="0" name="KD_ANB_V"/>
    <field labelOnTop="0" name="MONT_Z"/>
    <field labelOnTop="0" name="MP_DB_ID"/>
    <field labelOnTop="0" name="MP_ID"/>
    <field labelOnTop="0" name="MP_MBFD_CO"/>
    <field labelOnTop="0" name="NT_SONST"/>
    <field labelOnTop="0" name="SENDE_BB"/>
    <field labelOnTop="0" name="SENDE_GEOM"/>
    <field labelOnTop="0" name="SI_ABST_XY"/>
    <field labelOnTop="0" name="SI_ABST_Z"/>
    <field labelOnTop="0" name="SM_AUFTRAG"/>
    <field labelOnTop="0" name="STRUCTURE_"/>
    <field labelOnTop="0" name="TE_ART_GEP"/>
    <field labelOnTop="0" name="TE_ART_VOR"/>
    <field labelOnTop="0" name="TE_G_SONST"/>
    <field labelOnTop="0" name="TE_V_SONST"/>
    <field labelOnTop="0" name="Te_Art_Gep"/>
    <field labelOnTop="0" name="Te_G_Sonst"/>
    <field labelOnTop="0" name="ZUSTAND"/>
    <field labelOnTop="0" name="Zustand"/>
    <field labelOnTop="0" name="fid"/>
    <field labelOnTop="0" name="id_0"/>
  </labelOnTop>
  <reuseLastValue>
    <field name="ANZ_ANS_G" reuseLastValue="0"/>
    <field name="ANZ_ANS_V" reuseLastValue="0"/>
    <field name="Art" reuseLastValue="0"/>
    <field name="Art_Sonst" reuseLastValue="0"/>
    <field name="BEZ_OLD" reuseLastValue="0"/>
    <field name="Bezeichner" reuseLastValue="0"/>
    <field name="ID" reuseLastValue="0"/>
    <field name="ID_BAU" reuseLastValue="0"/>
    <field name="ID_Tech" reuseLastValue="0"/>
    <field name="KD_ANB_G" reuseLastValue="0"/>
    <field name="KD_ANB_V" reuseLastValue="0"/>
    <field name="MONT_Z" reuseLastValue="0"/>
    <field name="MP_DB_ID" reuseLastValue="0"/>
    <field name="MP_ID" reuseLastValue="0"/>
    <field name="MP_MBFD_CO" reuseLastValue="0"/>
    <field name="SENDE_BB" reuseLastValue="0"/>
    <field name="SENDE_GEOM" reuseLastValue="0"/>
    <field name="SI_ABST_XY" reuseLastValue="0"/>
    <field name="SI_ABST_Z" reuseLastValue="0"/>
    <field name="SM_AUFTRAG" reuseLastValue="0"/>
    <field name="STRUCTURE_" reuseLastValue="0"/>
    <field name="TE_ART_VOR" reuseLastValue="0"/>
    <field name="TE_V_SONST" reuseLastValue="0"/>
    <field name="Te_Art_Gep" reuseLastValue="0"/>
    <field name="Te_G_Sonst" reuseLastValue="0"/>
    <field name="Zustand" reuseLastValue="0"/>
    <field name="fid" reuseLastValue="0"/>
    <field name="id_0" reuseLastValue="0"/>
  </reuseLastValue>
  <dataDefinedFieldProperties/>
  <widgets/>
  <previewExpression>COALESCE( "E_FNAME", '&lt;NULL>' )</previewExpression>
  <mapTip enabled="1"></mapTip>
  <layerGeometryType>0</layerGeometryType>
</qgis>

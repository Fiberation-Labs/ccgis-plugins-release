# -*- coding: utf-8 -*-
"""Dock-Panel des GIS-NB Check: Import (Megaplan-Export mit CCGIS-Styles), Pruefung mit
Ergebnisliste (Zoom auf das Feature, Abhaken = Loeschen) und Export der Abgabe."""
import os
import traceback

from collections import Counter

from qgis.core import (
    Qgis, QgsCategorizedSymbolRenderer, QgsCoordinateTransform, QgsGeometry, QgsLayerTreeGroup,
    QgsMapLayer, QgsMapLayerProxyModel, QgsMessageLog, QgsProcessingContext, QgsProcessingFeedback,
    QgsProcessingUtils, QgsProject, QgsRectangle, QgsRendererCategory, QgsSymbol, QgsVectorLayer,
    QgsWkbTypes,
)
from qgis.gui import QgsCollapsibleGroupBox, QgsFileWidget, QgsMapLayerComboBox
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QColor, QKeySequence
from qgis.PyQt.QtWidgets import (
    QAbstractItemView, QApplication, QComboBox, QDockWidget, QFormLayout, QGroupBox, QHBoxLayout,
    QHeaderView, QLabel, QLineEdit, QListWidget, QListWidgetItem, QMessageBox, QPushButton,
    QScrollArea, QShortcut, QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from . import io_tools
from .algorithm import CheckGisNb

LOG_TAG = 'GIS-NB Check'

# Layer-Erkennung ueber den Layernamen (lowercase). "netztechnik_bauten" ist Netztechnik.
_KEYWORDS = [
    ('nt', 'netztechnik'),
    ('mv', 'mitverleg'),
    ('vb', 'verbindung'),
    ('lr', 'leerrohr'),
    ('tr', 'trassenbau'),
    ('ba', 'bauten'),
]

# Optionale Layer und die Versionen, in denen es sie gibt
_OPTIONAL = {'ba': ('3.1',), 'mv': ('3.1', '4.1')}

_FARBEN = {'FEHLER': '#e31a1c', 'HINWEIS': '#ff9900'}

RESULT_GROUP = 'GIS-NB Check {}'
ZOOM_MIN_M   = 30.0      # kleinste Kartenausdehnung beim Zoom auf eine Meldung
COLS = ['', 'Schwere', 'Pruefung', 'Layer', 'ID', 'Meldung']
COL_OK, COL_SCHWERE, COL_CODE, COL_LAYER, COL_ID, COL_MELDUNG = range(len(COLS))


def match_layers(layers):
    """{rolle: layer} fuer eine Liste von Layern anhand der Layernamen."""
    out = {}
    for lyr in layers:
        name = lyr.name().lower()
        for role, kw in _KEYWORDS:
            if kw in name:
                out.setdefault(role, lyr)
                break
    return out


def detect_version(layers):
    """'3.1', '4.1', '4.0' oder None anhand der Felder bzw. Netztechnik-Codes."""
    nt = layers.get('nt')
    lr = layers.get('lr')
    names = {f.name().lower() for lyr in (nt, lr) if lyr is not None for f in lyr.fields()}
    if not names:
        return None
    if 'art_nt' in names:
        return '3.1'
    if nt is not None and 'art' in names:
        idx = nt.fields().lookupField('Art')
        if idx >= 0:
            arten = {v for v in nt.uniqueValues(idx) if isinstance(v, int)}
            if arten & set(range(11, 20)):
                return '4.1'
    return '4.0'


class _LogFeedback(QgsProcessingFeedback):
    """Protokoll in das Log-Fenster (Reiter "GIS-NB Check")."""

    def pushInfo(self, info):
        super().pushInfo(info)
        QgsMessageLog.logMessage(info, LOG_TAG, Qgis.Info)

    def reportError(self, error, fatalError=False):
        super().reportError(error, fatalError)
        QgsMessageLog.logMessage(error, LOG_TAG, Qgis.Critical)


class GisNbCheckPanel(QDockWidget):

    def __init__(self, iface, parent=None):
        super().__init__('GIS-NB Check', parent)
        self.iface = iface
        self.setObjectName('GisNbCheckPanel')
        self.setFeatures(QDockWidget.DockWidgetMovable | QDockWidget.DockWidgetFloatable |
                         QDockWidget.DockWidgetClosable)
        self._group_data = {}
        self._group_nodes = {}
        self._export_auto = ''        # zuletzt automatisch vorgeschlagener Exportordner
        self._result_layers = []      # Layer-IDs der angezeigten Ergebnis-Layer
        self._undo = []               # abgehakte Meldungen: (Layer-ID, QgsFeature)
        self._cols_sized = False
        self._build_ui()
        QgsProject.instance().layersWillBeRemoved.connect(self._on_layers_removed)

    # ── UI ───────────────────────────────────────────────────────────────────

    def _build_ui(self):
        container = QWidget()
        outer = QVBoxLayout(container)
        outer.setContentsMargins(6, 6, 6, 6)
        outer.setSpacing(8)

        outer.addWidget(self._build_import())

        grp_proj = QGroupBox('Projekt (GIS-NB Vertragsnummer)')
        proj = QHBoxLayout()
        proj.setSpacing(4)
        self.combo_group = QComboBox()
        self.combo_group.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLength)
        self.combo_group.setMinimumContentsLength(18)
        self.combo_group.currentIndexChanged.connect(self._on_group_selected)
        proj.addWidget(self.combo_group, 1)
        btn_refresh = QPushButton('↺')
        btn_refresh.setFixedWidth(28)
        btn_refresh.setToolTip('Gruppen neu laden')
        btn_refresh.clicked.connect(self._refresh_groups)
        proj.addWidget(btn_refresh)
        grp_proj.setLayout(proj)
        outer.addWidget(grp_proj)

        grp_layer = QgsCollapsibleGroupBox('Pruefung')
        self.grp_check = grp_layer
        self.form = QFormLayout()
        self.form.setSpacing(5)
        self.combo_version = QComboBox()
        for k in CheckGisNb.VERSION_KEYS:
            self.combo_version.addItem('GIS-NB ' + k, k)
        self.combo_version.setCurrentIndex(CheckGisNb.VERSION_DEFAULT)
        self.combo_version.currentIndexChanged.connect(self._on_version_changed)
        self.form.addRow('Version:', self.combo_version)

        # Reihenfolge wie in der Layergruppe
        self.combos = {}
        for role, label, filt in [
            ('nt', 'Netztechnik / Bauten:', QgsMapLayerProxyModel.PointLayer),
            ('ba', 'Bauten:',               QgsMapLayerProxyModel.VectorLayer),
            ('mv', 'Mitverlegung:',         QgsMapLayerProxyModel.VectorLayer),
            ('vb', 'Verbindungen:',         QgsMapLayerProxyModel.LineLayer),
            ('lr', 'Leerrohre:',            QgsMapLayerProxyModel.LineLayer),
            ('tr', 'Trassenbau:',           QgsMapLayerProxyModel.LineLayer),
        ]:
            cb = QgsMapLayerComboBox()
            cb.setFilters(filt)
            cb.setAllowEmptyLayer(role in _OPTIONAL)
            if role in _OPTIONAL:
                cb.setLayer(None)
            lbl = QLabel(label)
            self.form.addRow(lbl, cb)
            self.combos[role] = (lbl, cb)
        btn_run = QPushButton('Pruefung starten')
        btn_run.setMinimumHeight(30)
        btn_run.clicked.connect(self._on_run)
        self.form.addRow(btn_run)
        grp_layer.setLayout(self.form)
        outer.addWidget(grp_layer)

        # Ergebnisliste: Klick zoomt auf das Feature, Haken = geprueft -> Meldung loeschen
        grp_res = QgsCollapsibleGroupBox('Fehler / Hinweise')
        self.grp_res = grp_res
        res = QVBoxLayout()
        res.setSpacing(4)
        bar = QHBoxLayout()
        bar.setSpacing(4)
        self.combo_filter = QComboBox()
        self.combo_filter.currentIndexChanged.connect(self._apply_filter)
        bar.addWidget(self.combo_filter, 1)
        self.btn_undo = QPushButton('↶ Rueckgaengig')
        self.btn_undo.setToolTip('Zuletzt abgehakte Meldung wiederherstellen (Strg+Z im Panel)')
        self.btn_undo.setEnabled(False)
        self.btn_undo.clicked.connect(self.undo)
        bar.addWidget(self.btn_undo)
        res.addLayout(bar)
        btn_fertig = QPushButton('Pruefung abschliessen -> Export')
        btn_fertig.setToolTip('Liste einklappen und den Export oeffnen (offene Hinweise bleiben im Ergebnis-Layer)')
        btn_fertig.clicked.connect(self.pruefung_abschliessen)
        res.addWidget(btn_fertig)
        QShortcut(QKeySequence.Undo, container, self.undo, context=Qt.WidgetWithChildrenShortcut)
        self.table = QTableWidget(0, len(COLS))
        self.table.setHorizontalHeaderLabels(COLS)
        self.table.horizontalHeaderItem(COL_OK).setToolTip('Haken = geprueft, Meldung wird geloescht')
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SingleSelection)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.verticalHeader().setVisible(False)
        self.table.setWordWrap(False)
        # Spaltenbreiten verschiebbar, Sortieren per Klick auf den Spaltenkopf (wie Attributtabelle)
        hdr = self.table.horizontalHeader()
        hdr.setSectionResizeMode(QHeaderView.Interactive)
        hdr.setStretchLastSection(True)
        hdr.setSortIndicator(-1, Qt.AscendingOrder)
        self.table.setSortingEnabled(True)
        self.table.itemChanged.connect(self._on_item_changed)
        self.table.currentCellChanged.connect(self._on_current_changed)
        self.table.cellClicked.connect(lambda row, col: self._zoom_row(row))
        self.table.setMinimumHeight(220)
        res.addWidget(self.table, 1)
        grp_res.setLayout(res)
        outer.addWidget(grp_res, 1)

        outer.addWidget(self._build_export())

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(container)
        self.setWidget(scroll)
        self.setMinimumWidth(260)
        self._on_version_changed()
        self._refresh_groups()

    def showEvent(self, event):
        super().showEvent(event)
        self._refresh_groups()

    def version(self):
        return self.combo_version.currentData()

    def _on_version_changed(self, *_):
        version = self.version()
        for role, versionen in _OPTIONAL.items():
            lbl, cb = self.combos[role]
            lbl.setVisible(version in versionen)
            cb.setVisible(version in versionen)
        # 3.1: Bauten ist ein eigener Layer, in 4.x steckt er in "Bauten und Netztechnik"
        self.combos['nt'][0].setText('Netztechnik:' if version == '3.1' else 'Netztechnik / Bauten:')

    # ── Gruppen ──────────────────────────────────────────────────────────────

    def _scan_groups(self):
        """{Anzeigename: {rolle: layer}} fuer alle Gruppen (auch verschachtelt) mit GIS-NB-Layern."""
        result = {}
        self._group_nodes = {}

        def walk(group, prefix):
            for child in group.children():
                if not isinstance(child, QgsLayerTreeGroup):
                    continue
                if child.name() == io_tools.ABGABE_GROUP:
                    continue
                name = f'{prefix}{child.name()}'
                layers = [n.layer() for n in child.children() if hasattr(n, 'layer') and n.layer() is not None]
                matched = match_layers(layers)
                if len(set(matched) & {'lr', 'tr', 'vb', 'nt'}) >= 2:
                    result[name] = matched
                    self._group_nodes[name] = child
                walk(child, name + ' / ')

        walk(QgsProject.instance().layerTreeRoot(), '')
        return result

    def _refresh_groups(self):
        prev = self.combo_group.currentText()
        self.combo_group.blockSignals(True)
        self.combo_group.clear()
        self.combo_group.addItem('— Gruppe waehlen —', None)
        self._group_data = self._scan_groups()
        for name in sorted(self._group_data):
            self.combo_group.addItem(name, name)
        idx = self.combo_group.findText(prev)
        self.combo_group.setCurrentIndex(idx if idx >= 0 else 0)
        self.combo_group.blockSignals(False)
        if self.combo_group.currentIndex() > 0:
            self._on_group_selected(self.combo_group.currentIndex())

    def _on_group_selected(self, index):
        name = self.combo_group.itemData(index)
        if not name or name not in self._group_data:
            return
        layers = self._group_data[name]
        for role, (_, cb) in self.combos.items():
            if role in layers:
                cb.setLayer(layers[role])
            elif role in _OPTIONAL:
                cb.setLayer(None)
        v = detect_version(layers)
        if v is not None:
            self.combo_version.setCurrentIndex(CheckGisNb.VERSION_KEYS.index(v))
        # Ergebnis eines frueheren Laufs fuer dieses Projekt wieder anzeigen
        group = QgsProject.instance().layerTreeRoot().findGroup(RESULT_GROUP.format(name))
        self.load_results([n.layer() for n in group.findLayers()] if group is not None else [])
        self._fill_export_list()

    # ── Lauf ─────────────────────────────────────────────────────────────────

    def _on_run(self):
        version = self.version()
        lyr = {role: cb.currentLayer() for role, (_, cb) in self.combos.items()}
        missing = [r for r in ('lr', 'tr', 'vb', 'nt') if lyr[r] is None]
        if missing:
            names = {'lr': 'Leerrohre', 'tr': 'Trassenbau', 'vb': 'Verbindungen', 'nt': 'Netztechnik'}
            QMessageBox.warning(self, 'GIS-NB Check', 'Bitte Layer auswaehlen: ' + ', '.join(names[m] for m in missing))
            return
        projekt = self.combo_group.currentText() if self.combo_group.currentIndex() > 0 else lyr['lr'].name()

        alg = CheckGisNb
        params = {
            alg.LR: lyr['lr'], alg.TR: lyr['tr'], alg.VB: lyr['vb'], alg.NT: lyr['nt'],
            alg.BA: lyr['ba'] if version in _OPTIONAL['ba'] else None,
            alg.MV: lyr['mv'] if version in _OPTIONAL['mv'] else None,
            alg.VERSION: alg.VERSION_KEYS.index(version),
            alg.OUT_L: 'TEMPORARY_OUTPUT', alg.OUT_P: 'TEMPORARY_OUTPUT',
        }
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            from qgis import processing
            context = QgsProcessingContext()
            context.setProject(QgsProject.instance())
            QgsMessageLog.logMessage(f'--- {projekt} (GIS-NB {version}) ---', LOG_TAG, Qgis.Info)
            res = processing.run('gisnbcheck:check_gis_nb', params, context=context, feedback=_LogFeedback())
            outputs = [(alg.OUT_L, 'Fehler/Hinweise (Linien)'), (alg.OUT_P, 'Fehler/Hinweise (Punkte)')]
            layers = []
            for key, title in outputs:
                out = res.get(key)
                layer = out if isinstance(out, QgsMapLayer) else QgsProcessingUtils.mapLayerFromString(out, context)
                if layer is None:
                    continue
                layer.setName(title)
                self._style(layer)
                layers.append(layer)
            self._add_to_group(RESULT_GROUP.format(projekt), layers)
            self.load_results(layers)
        except Exception as ex:
            QMessageBox.critical(self, 'GIS-NB Check - Fehler',
                                 f'Unerwarteter Fehler:\n{ex}\n\n{traceback.format_exc()[:1500]}')
        finally:
            QApplication.restoreOverrideCursor()

    # ── Ergebnisliste ────────────────────────────────────────────────────────

    def load_results(self, layers):
        """Meldungen der Ergebnis-Layer in die Tabelle (FEHLER zuerst, dann nach Pruefcode)."""
        rows = []
        self._result_layers = []
        for layer in layers:
            if not isinstance(layer, QgsVectorLayer) or layer.fields().lookupField('pruefung') < 0:
                continue
            self._result_layers.append(layer.id())
            for f in layer.getFeatures():
                rows.append((f['schwere'] != 'FEHLER', str(f['pruefung']), str(f['layer']),
                             f['feat_id'], str(f['meldung']), str(f['hinweis'] or ''),
                             str(f['schwere']), layer.id(), f.id()))
        rows.sort(key=lambda r: (r[0], r[1], r[2], str(r[3])))

        self._undo = []
        self.btn_undo.setEnabled(False)
        self.table.setSortingEnabled(False)
        self.table.blockSignals(True)
        self.table.setRowCount(0)
        for _, code, lyr, fid_attr, meldung, hinweis, schwere, layer_id, fid in rows:
            self._append_row(code, lyr, fid_attr, meldung, hinweis, schwere, layer_id, fid)
        self.table.blockSignals(False)
        self.table.setSortingEnabled(True)   # sortiert nur, wenn der Nutzer eine Spalte gewaehlt hat
        if rows and not self._cols_sized:
            self.table.resizeColumnsToContents()
            self._cols_sized = True
        self._update_filter()

    def _append_row(self, code, lyr, fid_attr, meldung, hinweis, schwere, layer_id, fid):
        """Zeile anhaengen (Sortierung muss dabei aus sein)."""
        i = self.table.rowCount()
        self.table.insertRow(i)
        ok = QTableWidgetItem()
        ok.setFlags(Qt.ItemIsUserCheckable | Qt.ItemIsEnabled | Qt.ItemIsSelectable)
        ok.setCheckState(Qt.Unchecked)
        ok.setToolTip('Geprueft -> Meldung loeschen')
        ok.setData(Qt.UserRole, (layer_id, fid))
        self.table.setItem(i, COL_OK, ok)
        tip = meldung + (f'\n\nKorrektur: {hinweis}' if hinweis else '')
        for col, text in ((COL_SCHWERE, schwere), (COL_CODE, code), (COL_LAYER, lyr), (COL_MELDUNG, meldung)):
            it = QTableWidgetItem(text)
            it.setToolTip(tip)
            if col == COL_SCHWERE:
                it.setForeground(QColor(_FARBEN.get(schwere, '#000000')))
            self.table.setItem(i, col, it)
        it = QTableWidgetItem()
        try:
            it.setData(Qt.DisplayRole, int(fid_attr))     # numerisch sortieren
        except (TypeError, ValueError):
            it.setData(Qt.DisplayRole, '')
        it.setToolTip(tip)
        self.table.setItem(i, COL_ID, it)

    def _update_filter(self):
        """Filterliste mit der Anzahl offener Meldungen je Pruefcode."""
        prev = self.combo_filter.currentData()
        codes = Counter(self.table.item(r, COL_CODE).text() for r in range(self.table.rowCount()))
        fehler = sum(1 for r in range(self.table.rowCount()) if self.table.item(r, COL_SCHWERE).text() == 'FEHLER')
        self.combo_filter.blockSignals(True)
        self.combo_filter.clear()
        self.combo_filter.addItem(f'Alle ({self.table.rowCount()})', None)
        self.combo_filter.addItem(f'Nur Fehler ({fehler})', '__FEHLER__')
        for code in sorted(codes):
            self.combo_filter.addItem(f'{code} ({codes[code]})', code)
        idx = self.combo_filter.findData(prev)
        self.combo_filter.setCurrentIndex(idx if idx >= 0 else 0)
        self.combo_filter.blockSignals(False)
        self._apply_filter()

    def _apply_filter(self, *_):
        sel = self.combo_filter.currentData()
        for r in range(self.table.rowCount()):
            if sel is None:
                show = True
            elif sel == '__FEHLER__':
                show = self.table.item(r, COL_SCHWERE).text() == 'FEHLER'
            else:
                show = self.table.item(r, COL_CODE).text() == sel
            self.table.setRowHidden(r, not show)

    def _row_feature(self, row):
        item = self.table.item(row, COL_OK)
        if item is None:
            return None, None
        layer_id, fid = item.data(Qt.UserRole)
        return QgsProject.instance().mapLayer(layer_id), fid

    def _on_current_changed(self, row, col, prev_row, prev_col):
        if row >= 0 and row != prev_row:
            self._zoom_row(row)

    def _zoom_row(self, row):
        layer, fid = self._row_feature(row)
        if layer is None:
            return
        f = layer.getFeature(fid)
        if not f.isValid() or not f.hasGeometry():
            return
        layer.selectByIds([fid])
        canvas = self.iface.mapCanvas() if self.iface is not None else None
        if canvas is None:
            return
        dest = canvas.mapSettings().destinationCrs()
        geom = QgsGeometry(f.geometry())
        if layer.crs() != dest:
            geom.transform(QgsCoordinateTransform(layer.crs(), dest, QgsProject.instance()))
        canvas.setExtent(self.zoom_extent(geom, dest.isGeographic()))
        canvas.refresh()
        canvas.flashGeometries([geom], dest)

    @staticmethod
    def zoom_extent(geom, geographic):
        """Ausdehnung um die Geometrie, mindestens ZOOM_MIN_M gross."""
        bb = QgsRectangle(geom.boundingBox())
        min_size = ZOOM_MIN_M / 111_320.0 if geographic else ZOOM_MIN_M
        if bb.width() < min_size and bb.height() < min_size:
            c = bb.center()
            return QgsRectangle(c.x() - min_size / 2, c.y() - min_size / 2,
                                c.x() + min_size / 2, c.y() + min_size / 2)
        bb.scale(1.2)
        return bb

    def _on_item_changed(self, item):
        """Haken gesetzt: Meldung ist geprueft -> Feature im Ergebnis-Layer und Zeile loeschen."""
        if item.column() != COL_OK or item.checkState() != Qt.Checked:
            return
        layer, fid = self._row_feature(item.row())
        if layer is not None:
            f = layer.getFeature(fid)
            if f.isValid():
                self._undo.append((layer.id(), f))
            layer.dataProvider().deleteFeatures([fid])
            layer.removeSelection()
            layer.triggerRepaint()
        self.table.removeRow(item.row())
        self.btn_undo.setEnabled(bool(self._undo))
        self._update_filter()
        if self.table.rowCount() == 0:
            self.pruefung_abschliessen()

    def undo(self):
        """Zuletzt abgehakte Meldung wieder in Ergebnis-Layer und Liste einfuegen."""
        while self._undo:
            layer_id, f = self._undo.pop()
            layer = QgsProject.instance().mapLayer(layer_id)
            if layer is None:
                continue                    # Ergebnis-Layer inzwischen entfernt
            ok, added = layer.dataProvider().addFeatures([f])
            if not ok or not added:
                continue
            layer.triggerRepaint()
            g = added[0]
            self.table.setSortingEnabled(False)
            self.table.blockSignals(True)
            self._append_row(str(g['pruefung']), str(g['layer']), g['feat_id'], str(g['meldung']),
                             str(g['hinweis'] or ''), str(g['schwere']), layer_id, g.id())
            self.table.blockSignals(False)
            self.table.setSortingEnabled(True)
            self._update_filter()
            for r in range(self.table.rowCount()):
                if self.table.item(r, COL_OK).data(Qt.UserRole) == (layer_id, g.id()):
                    self.table.selectRow(r)
                    self.table.scrollToItem(self.table.item(r, COL_OK))
                    break
            break
        self.btn_undo.setEnabled(bool(self._undo))

    def pruefung_abschliessen(self):
        """Ergebnisliste einklappen, Export oeffnen."""
        self.grp_res.setCollapsed(True)
        self.grp_check.setCollapsed(True)
        self.grp_export.setCollapsed(False)
        self._fill_export_list()

    # ── Import ───────────────────────────────────────────────────────────────

    def _build_import(self):
        grp = QgsCollapsibleGroupBox('Import (Megaplan-Export)')
        self.grp_import = grp
        form = QFormLayout()
        form.setSpacing(5)
        self.imp_ordner = QgsFileWidget()
        self.imp_ordner.setStorageMode(QgsFileWidget.GetDirectory)
        self.imp_ordner.setToolTip('Ordner, der nur die Quelldateien (gpkg/shp/geojson) enthaelt')
        self.imp_ordner.fileChanged.connect(self._on_import_ordner)
        form.addRow('Quellordner:', self.imp_ordner)
        self.imp_vnr = QLineEdit()
        self.imp_vnr.setToolTip('Wird aus dem Pfad gelesen; Name der Layergruppe und Praefix der Layernamen')
        form.addRow('MBfD-Vertragsnr.:', self.imp_vnr)
        self.imp_version = QComboBox()
        for v in io_tools.style_versionen():
            self.imp_version.addItem('GIS-NB ' + v, v)
        self.imp_version.currentIndexChanged.connect(self._import_vorschau)
        form.addRow('Style:', self.imp_version)
        self.imp_hinweis = QgsFileWidget()
        self.imp_hinweis.setStorageMode(QgsFileWidget.GetFile)
        self.imp_hinweis.setFilter('Vektordaten (*.gpkg *.shp *.geojson *.json)')
        self.imp_hinweis.setToolTip('Optional: Hinweiselayer (Hinweise an CC GIS oder Firma)')
        self.imp_hinweis.fileChanged.connect(self._import_vorschau)
        form.addRow('Hinweiselayer:', self.imp_hinweis)
        self.imp_info = QLabel()
        self.imp_info.setWordWrap(True)
        form.addRow(self.imp_info)
        btn = QPushButton('Importieren')
        btn.setMinimumHeight(28)
        btn.clicked.connect(self._on_import)
        form.addRow(btn)
        grp.setLayout(form)
        grp.setCollapsed(True)
        return grp

    def _on_import_ordner(self, ordner):
        if not ordner or not os.path.isdir(ordner):
            self.imp_info.setText('')
            return
        vnr = io_tools.vertragsnummer_aus_pfad(ordner)
        if vnr:
            self.imp_vnr.setText(vnr)
        namen = [b for _, b in io_tools.quell_dateien(ordner)]
        v = io_tools.version_aus_namen(ordner, *namen)
        idx = self.imp_version.findData(v)
        if idx >= 0:
            self.imp_version.setCurrentIndex(idx)
        hw = io_tools.hinweis_vorschlag(ordner)
        self.imp_hinweis.setFilePath(hw or '')
        self._import_vorschau()

    def _import_vorschau(self, *_):
        """Zuordnung Datei -> Style anzeigen."""
        ordner = self.imp_ordner.filePath()
        if not ordner or not os.path.isdir(ordner):
            return
        st = io_tools.styles(self.imp_version.currentData() or '')
        zeilen = []
        for pfad, basis in io_tools.quell_dateien(ordner):
            r = io_tools.rolle(basis)
            if r == 'hw':
                continue
            qml = st.get(r)
            zeilen.append(f'{os.path.basename(pfad)} -> {os.path.splitext(os.path.basename(qml))[0] if qml else "kein Style"}')
        if self.imp_hinweis.filePath():
            zeilen.append(f'{os.path.basename(self.imp_hinweis.filePath())} -> Hinweiselayer')
        self.imp_info.setText('\n'.join(zeilen) if zeilen else 'Keine Quelldateien im Ordner.')

    def _on_import(self):
        ordner = self.imp_ordner.filePath()
        vnr = self.imp_vnr.text().strip()
        if not ordner or not os.path.isdir(ordner):
            QMessageBox.warning(self, 'GIS-NB Check', 'Bitte den Quellordner waehlen.')
            return
        if not vnr:
            QMessageBox.warning(self, 'GIS-NB Check', 'Bitte die MBfD-Vertragsnummer eintragen.')
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            _, neu, meldungen = io_tools.importieren(ordner, vnr, self.imp_version.currentData(),
                                                    self.imp_hinweis.filePath() or None)
        except Exception as ex:
            QMessageBox.critical(self, 'GIS-NB Check - Fehler',
                                 f'Import fehlgeschlagen:\n{ex}\n\n{traceback.format_exc()[:1500]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        for m in meldungen:
            QgsMessageLog.logMessage(m, LOG_TAG, Qgis.Warning)
        self.imp_info.setText(f'{len(neu)} Layer importiert in Gruppe {vnr}.'
                              + ('\n' + '\n'.join(meldungen) if meldungen else ''))
        self._refresh_groups()
        idx = self.combo_group.findText(vnr)
        if idx >= 0:
            self.combo_group.setCurrentIndex(idx)
        self._message(f'{len(neu)} Layer importiert (Gruppe {vnr})', Qgis.Success)

    # ── Export ───────────────────────────────────────────────────────────────

    def _build_export(self):
        grp = QgsCollapsibleGroupBox('Export (Abgabe)')
        self.grp_export = grp
        form = QFormLayout()
        form.setSpacing(5)
        self.exp_ordner = QgsFileWidget()
        self.exp_ordner.setStorageMode(QgsFileWidget.GetDirectory)
        form.addRow('Zielordner:', self.exp_ordner)
        self.exp_list = QListWidget()
        self.exp_list.setMaximumHeight(170)
        self.exp_list.setToolTip('GeoJSON in EPSG:4258, Mitverlegung als Shapefile; ohne fid-Feld')
        form.addRow(self.exp_list)
        btn = QPushButton('Exportieren')
        btn.setMinimumHeight(28)
        btn.clicked.connect(self._on_export)
        form.addRow(btn)
        self.exp_laenge = QLabel('Gesamtlaenge (dissolved): -')
        self.exp_laenge.setTextInteractionFlags(Qt.TextSelectableByMouse)
        form.addRow(self.exp_laenge)
        grp.setLayout(form)
        grp.setCollapsed(True)
        return grp

    def _projekt_gruppe(self):
        return self._group_nodes.get(self.combo_group.currentData())

    def _fill_export_list(self):
        self.exp_list.clear()
        group = self._projekt_gruppe()
        layers = io_tools.abgabe_layer(group)
        for lyr in layers:
            r = io_tools.rolle(lyr.name())
            it = QListWidgetItem(f'{lyr.name()}{".shp" if r == "mv" else ".geojson"}')
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked)
            it.setData(Qt.UserRole, lyr.id())
            self.exp_list.addItem(it)
        # Zielordner vorschlagen: <Ordner der Vertragsnummer>/fertiger Netzplan
        if group is not None and layers and (not self.exp_ordner.filePath() or self.exp_ordner.filePath() == self._export_auto):
            vorschlag = self.export_vorschlag(group.name(), layers)
            if vorschlag:
                self.exp_ordner.setFilePath(vorschlag)
                self._export_auto = vorschlag

    @staticmethod
    def export_vorschlag(vnr, layers):
        for lyr in layers:
            pfad = lyr.source().split('|')[0]
            teile = os.path.normpath(pfad).split(os.sep)
            if vnr in teile:
                return os.sep.join(teile[:len(teile) - teile[::-1].index(vnr)] + ['fertiger Netzplan'])
        return ''

    def _bestaetigen(self, text):
        return QMessageBox.question(self, 'GIS-NB Check', text) == QMessageBox.Yes

    def _on_export(self):
        group = self._projekt_gruppe()
        ordner = self.exp_ordner.filePath()
        if group is None:
            QMessageBox.warning(self, 'GIS-NB Check', 'Bitte oben ein Projekt waehlen.')
            return
        if not ordner:
            QMessageBox.warning(self, 'GIS-NB Check', 'Bitte den Zielordner waehlen.')
            return
        ids = [self.exp_list.item(i).data(Qt.UserRole) for i in range(self.exp_list.count())
               if self.exp_list.item(i).checkState() == Qt.Checked]
        layers = [QgsProject.instance().mapLayer(i) for i in ids]
        layers = [lyr for lyr in layers if lyr is not None]
        if not layers:
            QMessageBox.warning(self, 'GIS-NB Check', 'Keine Layer zum Export ausgewaehlt.')
            return
        vorhanden = [f for f in (io_tools.abgabe_dateiname(lyr, io_tools.rolle(lyr.name())) for lyr in layers)
                     if os.path.exists(os.path.join(ordner, f))]
        if vorhanden and not self._bestaetigen(f'{len(vorhanden)} Datei(en) im Zielordner existieren schon und '
                                               f'werden ueberschrieben:\n' + '\n'.join(vorhanden[:10])):
            return
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            neu, fehler = io_tools.exportieren(layers, ordner, group.name())
            # Laenge aus den Projektlayern (gleiche Geometrie wie die Abgabe); die
            # exportierten Dateien nicht lesen, damit ein erneuter Export sie ueberschreiben kann
            rollen = {io_tools.rolle(lyr.name()): lyr for lyr in layers}
            laenge = io_tools.gesamtlaenge(rollen.get('lr'), rollen.get('vb'))
        except Exception as ex:
            QMessageBox.critical(self, 'GIS-NB Check - Fehler',
                                 f'Export fehlgeschlagen:\n{ex}\n\n{traceback.format_exc()[:1500]}')
            return
        finally:
            QApplication.restoreOverrideCursor()
        text = f'{laenge:.1f}'.replace('.', ',')
        self.exp_laenge.setText(f'Gesamtlaenge (dissolved): <b>{text} m</b>')
        QgsMessageLog.logMessage(f'{group.name()}: {len(neu)} Layer exportiert nach {ordner}, '
                                 f'Gesamtlaenge (dissolved) {text} m', LOG_TAG, Qgis.Info)
        for f in fehler:
            QgsMessageLog.logMessage(f, LOG_TAG, Qgis.Critical)
        if fehler:
            QMessageBox.warning(self, 'GIS-NB Check', 'Export mit Fehlern:\n' + '\n'.join(fehler))
        self._message(f'{len(neu)} Layer exportiert, Gesamtlaenge (dissolved) {text} m',
                      Qgis.Warning if fehler else Qgis.Success)

    def _message(self, text, level):
        if self.iface is not None and hasattr(self.iface, 'messageBar'):
            self.iface.messageBar().pushMessage('GIS-NB Check', text, level=level, duration=8)

    def _on_layers_removed(self, layer_ids):
        if set(layer_ids) & set(self._result_layers):
            remaining = [QgsProject.instance().mapLayer(i) for i in self._result_layers if i not in layer_ids]
            self.load_results([lyr for lyr in remaining if lyr is not None])

    @staticmethod
    def _style(layer):
        cats = []
        for sev, color in _FARBEN.items():
            sym = QgsSymbol.defaultSymbol(layer.geometryType())
            sym.setColor(QColor(color))
            if layer.geometryType() == QgsWkbTypes.LineGeometry:
                sym.setWidth(1.2)
            else:
                sym.setSize(3.0)
            cats.append(QgsRendererCategory(sev, sym, sev))
        layer.setRenderer(QgsCategorizedSymbolRenderer('schwere', cats))

    @staticmethod
    def _add_to_group(name, layers):
        """Ergebnis-Layer in eine Gruppe oben im Layerbaum; ein frueheres Ergebnis gleichen Namens wird ersetzt."""
        project = QgsProject.instance()
        root = project.layerTreeRoot()
        old = root.findGroup(name)
        if old is not None:
            project.removeMapLayers([lyr.layerId() for lyr in old.findLayers()])
            root.removeChildNode(old)
        group = root.insertGroup(0, name)
        for layer in layers:
            project.addMapLayer(layer, False)
            group.addLayer(layer)
